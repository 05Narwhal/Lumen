/**
 * @file
 * @ingroup unit_tests
 * @brief Unit tests for the bitrates that a caller can request for a free
 *        format stream (libmp3lame/lame.c).
 *
 * A free format bitrate is the caller's own number. It is not one of the
 * values in the tables of the standard. So it can describe a frame that is
 * too small for its own side information. An example is MPEG-1 at 48 kHz and
 * 8 kbit/s, with two channels and CRC. The frame is 24 bytes, but the side
 * information is 38 bytes. Nothing can be encoded in that case. So
 * \c lame_init_params() rejects these settings. The encoder does not fail
 * later, partway through the first frame.
 *
 * Most tests call only \c lame_init_params(), because that function makes the
 * decision. They encode no audio, and take a few microseconds each. The test
 * of a bitrate above the limit also encodes a few frames.
 *
 * Some of the tests check that the rejection is narrow. The bound is eight
 * bits (one byte) of room per granule. The tightest configuration that the
 * bitrate tables allow is exactly on this bound. So a check that is even
 * slightly stricter rejects an ordinary MPEG-2 stream that encodes correctly.
 * One test checks this case on its own.
 *
 * These are library-level tests. They link libmp3lame and call the exported
 * API directly.
 */

#ifdef HAVE_CONFIG_H
# include <config.h>
#endif

#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <limits.h>

#include <cmocka.h>

#include "test_unused.h"
#include "test_report.h"
#include "test_encode.h"

#include "lame.h"

/**
 * @brief Creates an encoder instance with the settings that the cases below
 *        share, and runs \c lame_init_params() on it.
 * @param samplerate the output sample rate, in Hz.
 * @param channels 1 or 2.
 * @param kbps the bitrate to ask for.
 * @param free_format 1 for a free format stream, 0 for a tabulated bitrate.
 * @param crc 1 to add the CRC, which is two more bytes of side information.
 * @return the result of \c lame_init_params() for those settings. The
 *         function closes the instance in both cases.
 */
static int
try_settings(int samplerate, int channels, int kbps, int free_format, int crc)
{
    lame_t  gfp = lame_init();
    int     rc;

    assert_non_null(gfp);
    report_reset();
    assert_int_equal(lame_set_errorf(gfp, report_capture), 0);
    assert_int_equal(lame_set_num_channels(gfp, channels), 0);
    assert_int_equal(lame_set_mode(gfp, channels == 1 ? MONO : STEREO), 0);
    assert_int_equal(lame_set_in_samplerate(gfp, samplerate), 0);
    assert_int_equal(lame_set_out_samplerate(gfp, samplerate), 0);
    assert_int_equal(lame_set_brate(gfp, kbps), 0);
    assert_int_equal(lame_set_free_format(gfp, free_format), 0);
    assert_int_equal(lame_set_error_protection(gfp, crc), 0);
    rc = lame_init_params(gfp);
    /* The instance stays valid after a failed initialization and is still the
       caller's to close, which this exercises on both paths. */
    (void) lame_close(gfp);
    return rc;
}

/**
 * @brief Checks that a free format bitrate is rejected if its frame has no
 *        room for audio.
 *
 * MPEG-1 side information for two channels with CRC is 38 bytes. A frame at
 * 8 kbit/s and 48 kHz is 24 bytes. Without the check, a build with
 * assertions aborts partway through the first frame. A build without
 * assertions returns success and writes several megabytes of data that is
 * not an MP3.
 */
static void
test_bitrate_below_the_floor_is_refused(LAME_UNUSED void **state)
{
    assert_int_not_equal(try_settings(48000, 2, 8, 1, 1), 0);
    /* Refusing in silence would be its own defect - a caller that does not
       check the return value would be no better off than before. */
    assert_true(report_calls > 0);
}

/**
 * @brief Checks that the floor depends on the channel count. Mono has its own
 *        floor.
 *
 * Mono side information is 15 bytes shorter. So 8 kbit/s is 1 kbit/s below
 * the mono floor of 9 kbit/s. It is 6 kbit/s below the stereo floor of
 * 14 kbit/s. Without this case, the tests would also pass with a check that
 * only knows about stereo.
 */
static void
test_the_floor_follows_the_channel_count(LAME_UNUSED void **state)
{
    assert_int_not_equal(try_settings(48000, 1, 8, 1, 1), 0);
    assert_true(report_calls > 0);
    /* and one step up is enough for mono, where stereo would still be refused */
    assert_int_equal(try_settings(48000, 1, 9, 1, 1), 0);
}

/**
 * @brief Checks that a free format bitrate that fits is accepted.
 *
 * This is the control for the two tests above. It shows that the rejection
 * depends on the bitrate, not on free format itself.
 */
static void
test_a_workable_free_format_bitrate_is_accepted(LAME_UNUSED void **state)
{
    assert_int_equal(try_settings(48000, 2, 14, 1, 1), 0);
    assert_int_equal(report_calls, 0);
}

/**
 * @brief Checks that free format at 8 kbit/s is accepted where a frame has
 *        room for it.
 *
 * An MPEG-2 frame has one granule, not two, and its side information is
 * shorter. So the same bitrate that fails at 48 kHz is ordinary at 24 kHz. A
 * check that rejects free format below a fixed bitrate fails here.
 */
static void
test_the_floor_follows_the_sample_rate(LAME_UNUSED void **state)
{
    assert_int_equal(try_settings(24000, 2, 8, 1, 1), 0);
    assert_int_equal(report_calls, 0);
}

/**
 * @brief Checks that the tightest stream that the bitrate tables allow still
 *        initializes.
 *
 * The settings are MPEG-2 at 24 kHz and 8 kbit/s, two channels with CRC. The
 * frame is 24 bytes, and 23 bytes of it are side information. So it has
 * exactly the bound: one byte of room for its one granule. The rejection
 * comes closest to this case. The case is legal, it is in the tables, and it
 * encodes correctly.
 */
static void
test_the_tightest_tabulated_stream_is_accepted(LAME_UNUSED void **state)
{
    assert_int_equal(try_settings(24000, 2, 8, 0, 1), 0);
    assert_int_equal(report_calls, 0);
}

/**
 * @brief Returns the lowpass frequency that \c lame_init_params() chooses for
 *        a free format stream at 44.1 kHz in stereo.
 * @param kbps the bitrate to ask for.
 * @return the lowpass frequency in Hz, after a successful initialization.
 */
static int
default_lowpass(int kbps)
{
    lame_t  gfp = lame_init();
    int     lowpass;

    assert_non_null(gfp);
    assert_int_equal(lame_set_num_channels(gfp, 2), 0);
    assert_int_equal(lame_set_in_samplerate(gfp, 44100), 0);
    assert_int_equal(lame_set_out_samplerate(gfp, 44100), 0);
    assert_int_equal(lame_set_brate(gfp, kbps), 0);
    assert_int_equal(lame_set_free_format(gfp, 1), 0);
    assert_int_equal(lame_init_params(gfp), 0);
    lowpass = lame_get_lowpassfreq(gfp);
    (void) lame_close(gfp);
    return lowpass;
}

/**
 * @brief Checks that a free format bitrate above 65535 kbit/s gets the
 *        lowpass of the highest bitrate.
 *
 * 65544 kbit/s is 8 more than 65536. A bitrate stored in 16 bits becomes
 * 8 kbit/s, and the lowpass for 8 kbit/s is 2 kHz.
 * @param state cmocka fixture state (unused).
 */
static void
test_a_huge_bitrate_gets_the_top_lowpass(LAME_UNUSED void **state)
{
    int const top = default_lowpass(320);

    assert_true(top > 15000);
    assert_int_equal(default_lowpass(65544), top);
}

/** @brief The samples per channel of the encode in check_encoded_at_the_limit(). */
#define LIMIT_SAMPLES 4608
/** @brief The size of the stream buffer of check_encoded_at_the_limit(), in bytes. */
#define LIMIT_STREAM_BYTES 65536

/**
 * @brief Prepares a stereo stream at 44.1 kHz and @p kbps, then asks for
 *        success, 640 kbit/s from lame_get_brate(), and encoded frames.
 * @param kbps the bitrate to ask for, above 640.
 */
static void
check_encoded_at_the_limit(int kbps)
{
    static short left[LIMIT_SAMPLES], right[LIMIT_SAMPLES];
    static unsigned char stream[LIMIT_STREAM_BYTES];
    lame_t  gfp = lame_init();
    int     i;

    for (i = 0; i < LIMIT_SAMPLES; i++)
        left[i] = right[i] = (short) ((i * 37) % 2000 - 1000);
    assert_non_null(gfp);
    assert_int_equal(lame_set_num_channels(gfp, 2), 0);
    assert_int_equal(lame_set_in_samplerate(gfp, 44100), 0);
    assert_int_equal(lame_set_out_samplerate(gfp, 44100), 0);
    assert_int_equal(lame_set_brate(gfp, kbps), 0);
    assert_int_equal(lame_set_free_format(gfp, 1), 0);
    assert_int_equal(lame_init_params(gfp), 0);
    assert_int_equal(lame_get_brate(gfp), 640);
    assert_true(encode_collect(gfp, left, right, LIMIT_SAMPLES, 1, 0, stream,
                               (int) sizeof stream) > 0);
    (void) lame_close(gfp);
}

/**
 * @brief Checks that a free format bitrate above 640 kbit/s is encoded at 640.
 *
 * 641 is one above the limit. 65544 kbit/s makes the frame size larger than an
 * int holds.
 * @param state cmocka fixture state (unused).
 */
static void
test_a_bitrate_above_the_limit_is_encoded_at_it(LAME_UNUSED void **state)
{
    check_encoded_at_the_limit(641);
    check_encoded_at_the_limit(65544);
}

/**
 * @brief Checks that a negative free format bitrate is refused, with a
 *        message.
 * @param state cmocka fixture state (unused).
 */
static void
test_a_negative_bitrate_is_refused(LAME_UNUSED void **state)
{
    assert_int_not_equal(try_settings(44100, 2, -1, 1, 0), 0);
    assert_true(report_calls > 0);
    assert_int_not_equal(try_settings(44100, 2, INT_MIN, 1, 0), 0);
    assert_true(report_calls > 0);
}

int
main(void)
{
    const struct CMUnitTest tests[] = {
        cmocka_unit_test(test_bitrate_below_the_floor_is_refused),
        cmocka_unit_test(test_the_floor_follows_the_channel_count),
        cmocka_unit_test(test_a_workable_free_format_bitrate_is_accepted),
        cmocka_unit_test(test_the_floor_follows_the_sample_rate),
        cmocka_unit_test(test_the_tightest_tabulated_stream_is_accepted),
        cmocka_unit_test(test_a_huge_bitrate_gets_the_top_lowpass),
        cmocka_unit_test(test_a_bitrate_above_the_limit_is_encoded_at_it),
        cmocka_unit_test(test_a_negative_bitrate_is_refused),
    };
    return cmocka_run_group_tests(tests, NULL, NULL);
}
