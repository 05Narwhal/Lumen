/**
 *
 * Lame ACM wrapper, encode MP3 based RIFF/AVI files in MS Windows
 *
 *  Copyright (c) 2002 Steve Lhomme <steve.lhomme at free.fr>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */
 
/*!
	\author Steve Lhomme
	\version \$Id$
*/

#if !defined(LAME_ACM_ACM_H)
#define LAME_ACM_ACM_H

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include <vector>

#include <windows.h>
#include <mmsystem.h>
#include <mmreg.h>
#include <msacm.h>
#include <msacmdrv.h>


#include <lame.h>

#include "ADbg/ADbg.h"
#include "AEncodeProperties.h"

class bitrate_item {
	public:
		unsigned int frequency;
		unsigned int bitrate;
		unsigned int channels;
		vbr_mode     mode;
		/** \brief The VBR quality level of a VBR format, 0 to 9; 0 for the others. */
		unsigned int quality;

		bool operator<(const bitrate_item & bitrate) const;
};

class ACM  
{
public:
	ACM( HMODULE hModule );
	virtual ~ACM();

	LONG DriverProcedure(const HDRVR hdrvr, const UINT msg, LONG lParam1, LONG lParam2);

	static const char * GetVersionString(void) {return VersionString;}

	/** \brief The families of formats, for BuildFormatList(); any of them
	    together. */
	enum { FAMILY_CBR = 1, FAMILY_ABR = 2, FAMILY_VBR = 4, FAMILY_ALL = 7 };
	static void BuildFormatList(const FormatListSettings & the_Settings, unsigned int the_Families,
	                            std::vector<bitrate_item> & the_List);
	/** \brief The size of the buffer that GetVersionString() returns, terminator included. */
	static const unsigned int VERSION_STRING_CHARS = 120;

protected:
	inline DWORD About( HWND hParentWindow );

	inline DWORD OnDriverDetails(LPACMDRIVERDETAILS a_DriverDetail);
	inline DWORD OnFormatTagDetails(LPACMFORMATTAGDETAILS a_FormatTagDetails, const LPARAM a_Query);
	inline DWORD OnFormatDetails(LPACMFORMATDETAILS a_FormatDetails, const LPARAM a_Query);
	inline DWORD OnFormatSuggest(LPACMDRVFORMATSUGGEST a_FormatSuggest);
	DWORD SuggestEncode(LPACMDRVFORMATSUGGEST a_FormatSuggest, const DWORD fdwSuggest) const;
	void LogFormat(const char * a_What, const WAVEFORMATEX * a_Format) const;
	inline DWORD OnStreamOpen(LPACMDRVSTREAMINSTANCE a_StreamInstance);
	inline DWORD OnStreamClose(LPACMDRVSTREAMINSTANCE a_StreamInstance);
	inline DWORD OnStreamSize(LPACMDRVSTREAMINSTANCE a_StreamInstance, LPACMDRVSTREAMSIZE the_StreamSize);
	inline DWORD OnStreamPrepareHeader(LPACMSTREAMHEADER a_StreamHeader);
	inline DWORD OnStreamUnPrepareHeader(LPACMSTREAMHEADER a_StreamHeader);
	inline DWORD OnStreamConvert(LPACMDRVSTREAMINSTANCE a_StreamInstance, LPACMDRVSTREAMHEADER a_StreamHeader);

	void GetMP3FormatForIndex(const DWORD the_Index, WAVEFORMATEX & the_Format, WCHAR the_String[ACMFORMATDETAILS_FORMAT_CHARS]) const;
	void GetPCMFormatForIndex(const DWORD the_Index, WAVEFORMATEX & the_Format, WCHAR the_String[ACMFORMATDETAILS_FORMAT_CHARS]) const;
	void FillMP3Format(WAVEFORMATEX & the_Format, const unsigned int the_Frequency, const unsigned int the_Bitrate, const unsigned int the_Channels, const vbr_mode the_Mode, const unsigned int the_Quality = 0) const;
	void DescribeMP3Format(const WAVEFORMATEX & the_Format, WCHAR the_String[ACMFORMATDETAILS_FORMAT_CHARS]) const;
	static bool IsABRFormatFlags(const DWORD the_Flags);
	static bool IsVBRFormatFlags(const DWORD the_Flags);
	static unsigned int VBRQualityOfFormatFlags(const DWORD the_Flags);
	static void AddVbrFormats(const FormatListSettings & the_Settings, const unsigned int * freqs, unsigned int nfreqs,
	                          unsigned int channels, std::vector<bitrate_item> & the_List);
	DWORD GetNumberEncodingFormats() const;
	static bool IsSmartOutput(const FormatListSettings & the_Settings, const int frequency, const int bitrate,
	                          const int channels);
	void BuildBitrateTable();
	static void AddFormats(const FormatListSettings & the_Settings, const unsigned int * freqs, unsigned int nfreqs,
	                       const unsigned int * bitrates, unsigned int nbitrates, unsigned int channels,
	                       vbr_mode mode, std::vector<bitrate_item> & the_List);
	static std::vector<unsigned int> AbrBitrates(const FormatListSettings & the_Settings, unsigned int lowest);
	static std::vector<unsigned int> CbrBitrates(const FormatListSettings & the_Settings, const unsigned int * bitrates,
	                                             unsigned int nbitrates);

	HMODULE my_hModule;
	HICON   my_hIcon;
	ADbg    my_debug;
	AEncodeProperties my_EncodingProperties;
	std::vector<bitrate_item> bitrate_table;

	static char VersionString[VERSION_STRING_CHARS];
};

#endif // !defined(LAME_ACM_ACM_H)

