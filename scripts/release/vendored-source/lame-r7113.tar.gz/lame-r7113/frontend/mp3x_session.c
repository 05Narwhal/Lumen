/**
 *  \file mp3x_session.c
 *  \brief mp3x analyzer session - implementation.
 *  \internal
 *
 *  Opening and closing input files in the GTK4 mp3x frame analyzer. Each open
 *  input file has its own Mp3xSession. Closing or replacing the file closes and
 *  frees the whole session: the idle source, the analyzer engine, the input
 *  decoder and the \c lame_t. So the next open starts from the documented
 *  defaults, and not from the state of earlier files.
 *
 *  There are two ways to open a file: mp3x_session_open_prevalidated() for the
 *  GUI, and mp3x_session_open_cli_initial() for the first file named on the
 *  command line. Both use the same close and install steps. Only the call of
 *  \c parse_args differs.
 *
 *  This file has no GTK widgets, and no GLib main-loop code except what open
 *  and close need for the file paths. The GTK frontend in mp3x_ui.c uses it.
 */

#ifdef HAVE_CONFIG_H
# include <config.h>
#endif

#include <string.h>

#include <glib.h>
#include <gio/gio.h>

#include "lame.h"
#include "main.h"
#include "get_audio.h"
#include "parse.h"
#include "console.h"           /* frontend_errorf/debugf/msgf, error_printf */
#include "mp3x_session.h"


/* --------------------------------------------------------------------------
 * Driver accessors
 *
 * The full Mp3xDriver struct is defined in mp3x_ui.c; here we only need two
 * accessors that touch driver-owned state. Declared here (not in the shared
 * mp3x_session.h) because they are internal to the mp3x frontend and the
 * GTK layer is their natural owner.
 * -------------------------------------------------------------------------- */
extern guint64                  mp3x_driver_next_generation(Mp3xDriver *d);
extern FrontendConfig *mp3x_driver_baseline(Mp3xDriver *d);


/* ==========================================================================
 * Frontend-global baseline
 *
 * frontend_config is a process-wide
 * singleton. Because mp3x holds at most one open input at a time, we treat
 * them as current-session state: every mp3x_session_open restores the
 * baseline captured at startup, so options from a prior file or
 * from raw-input CLI flags on the initial file cannot leak into a later
 * GUI-opened self-describing file.
 *
 * The input is not part of it: each session opens its own reader with
 * init_infile() and closes it with close_infile().
 * ========================================================================== */

void
mp3x_apply_documented_defaults(void)
{
    frontend_config = frontend_config_defaults;
}

void
mp3x_globals_capture(FrontendConfig *b)
{
    *b = frontend_config;
}

void
mp3x_globals_restore(const FrontendConfig *b)
{
    frontend_config = *b;
}


/* ==========================================================================
 * Prevalidation
 *
 * Runs BEFORE the current session is retired. On any failure here the
 * previous session is left intact (per the prevalidated
 * close-then-open replacement policy). The check accepts only regular
 * files (no FIFOs, sockets, devices, mountables) so the readability probe
 * cannot block indefinitely.
 * ========================================================================== */

gboolean
mp3x_prevalidate(GFile *gfile, Mp3xPrevalidateResult *out, GError **err)
{
    /* Initialize output to all-NULL before any work; on every failure path
       the caller will see NULL fields. */
    *out = (Mp3xPrevalidateResult) {0};

    /* Every cleanup pointer is initialized before any goto. */
    gchar            *fs_path = NULL;
    GFileInfo        *info    = NULL;
    GFileInputStream *stream  = NULL;
    gchar            *disp    = NULL;
    gchar            *ctype   = NULL;
    gboolean          ok      = FALSE;

    g_return_val_if_fail(G_IS_FILE(gfile), FALSE);

    /* 1. A real filesystem path is required (LAME takes paths, not URIs). */
    fs_path = g_file_get_path(gfile);
    if (fs_path == NULL) {
        g_set_error(err, MP3X_OPEN_ERROR, MP3X_OPEN_ERR_NO_FS_PATH,
                    "mp3x requires a resource with a filesystem path");
        goto out;
    }

    /* 2. Query standard::type, size, display-name, content-type, access::can-read. */
    {
        GError *q_err = NULL;
        info = g_file_query_info(gfile,
                G_FILE_ATTRIBUTE_STANDARD_TYPE ","
                G_FILE_ATTRIBUTE_STANDARD_SIZE ","
                G_FILE_ATTRIBUTE_STANDARD_DISPLAY_NAME ","
                G_FILE_ATTRIBUTE_STANDARD_CONTENT_TYPE ","
                G_FILE_ATTRIBUTE_ACCESS_CAN_READ,
                G_FILE_QUERY_INFO_NONE, NULL, &q_err);
        if (info == NULL) {
            g_propagate_error(err, q_err);
            goto out;
        }
    }

    /* 3. Reject directories with the specific message before the general
          nonregular-file branch. */
    if (g_file_info_get_file_type(info) == G_FILE_TYPE_DIRECTORY) {
        g_set_error(err, MP3X_OPEN_ERROR, MP3X_OPEN_ERR_IS_DIRECTORY,
                    "mp3x cannot open a directory");
        goto out;
    }

    /* 4. Accept only regular files. This rules out FIFOs/sockets/devices
          (where a read would block) and shortcuts/mountables (which do not
          resolve to a usable path). Symlinks to regular files show as
          REGULAR here because g_file_query_info follows symlinks by default. */
    if (g_file_info_get_file_type(info) != G_FILE_TYPE_REGULAR) {
        g_set_error(err, MP3X_OPEN_ERROR, MP3X_OPEN_ERR_NOT_REGULAR,
                    "mp3x can only open regular files");
        goto out;
    }

    /* 5. Reject confirmed-empty files. A missing size attribute is NOT a
          rejection - the backend may simply not know. */
    if (g_file_info_has_attribute(info, G_FILE_ATTRIBUTE_STANDARD_SIZE) &&
        g_file_info_get_size(info) == 0) {
        g_set_error(err, MP3X_OPEN_ERROR, MP3X_OPEN_ERR_EMPTY,
                    "mp3x cannot open an empty file");
        goto out;
    }

    /* 6. access::can-read: missing attribute is treated as unknown (NOT
          false). Only an explicit FALSE is a rejection. */
    if (g_file_info_has_attribute(info, G_FILE_ATTRIBUTE_ACCESS_CAN_READ) &&
        !g_file_info_get_attribute_boolean(info, G_FILE_ATTRIBUTE_ACCESS_CAN_READ)) {
        g_set_error(err, MP3X_OPEN_ERROR, MP3X_OPEN_ERR_UNREADABLE,
                    "mp3x cannot read '%s' (permission denied)", fs_path);
        goto out;
    }

    /* 7. Real readability probe: open then close. Safe now because we have
          already verified G_FILE_TYPE_REGULAR - no FIFO to block on, no
          character device to hang the read. */
    {
        GError *read_err = NULL;
        stream = g_file_read(gfile, NULL, &read_err);
        if (stream == NULL) {
            g_propagate_error(err, read_err);
            goto out;
        }
        if (!g_input_stream_close(G_INPUT_STREAM(stream), NULL, &read_err)) {
            g_propagate_error(err, read_err);
            goto out;
        }
    }

    /* 8. Capture display-name and content-type if present. */
    if (g_file_info_has_attribute(info, G_FILE_ATTRIBUTE_STANDARD_DISPLAY_NAME)) {
        disp = g_strdup(g_file_info_get_attribute_string(info,
                    G_FILE_ATTRIBUTE_STANDARD_DISPLAY_NAME));
    }
    if (disp == NULL)
        disp = g_path_get_basename(fs_path);
    if (g_file_info_has_attribute(info, G_FILE_ATTRIBUTE_STANDARD_CONTENT_TYPE)) {
        ctype = g_strdup(g_file_info_get_attribute_string(info,
                    G_FILE_ATTRIBUTE_STANDARD_CONTENT_TYPE));
    }

    ok = TRUE;

out:
    /* Single cleanup path - runs on success and every failure. */
    g_clear_object(&stream);
    g_clear_object(&info);

    if (ok) {
        out->fs_path      = fs_path;     /* non-NULL by construction */
        out->display_name = disp;        /* may be NULL */
        out->content_type = ctype;       /* may be NULL */
        return TRUE;
    }
    g_free(disp);
    g_free(ctype);
    g_free(fs_path);
    return FALSE;
}

void
mp3x_prevalidate_result_clear(Mp3xPrevalidateResult *result)
{
    if (result == NULL)
        return;

    g_clear_pointer(&result->fs_path, g_free);
    g_clear_pointer(&result->display_name, g_free);
    g_clear_pointer(&result->content_type, g_free);
}


/* ==========================================================================
 * Filename sanitization
 *
 * Used for save-dialog default filenames. Strips directory components and
 * one trailing extension, replaces filesystem-unsafe and control chars
 * with underscore, replaces leading dots in place (without advancing the
 * allocation pointer - that would make g_free invalid).
 * ========================================================================== */

gchar *
mp3x_sanitize_stem(const gchar *display_name)
{
    gchar *base;
    gchar *dot;
    gchar *p;

    if (display_name == NULL || *display_name == '\0')
        return g_strdup("audio");

    /* Strip directory components defensively. */
    base = g_path_get_basename(display_name);

    /* Strip a single trailing extension. */
    dot = strrchr(base, '.');
    if (dot != NULL && dot != base)
        *dot = '\0';

    /* Replace filesystem-unsafe chars in place. NEVER advance the base
       pointer - the original allocation must survive for g_free. */
    for (p = base; *p; p++) {
        const guchar c = (guchar) *p;
        if (c < 0x20 ||
            c == '/' || c == '\\' || c == ':' ||
            c == '*'  || c == '?'  || c == '"' ||
            c == '<'  || c == '>'  || c == '|') {
            *p = '_';
        }
    }

    /* Replace leading dots in place; preserves the allocation pointer. */
    for (p = base; *p == '.'; p++)
        *p = '_';

    /* If everything was stripped (e.g. filename was only dots), fall back. */
    if (*base == '\0') {
        g_free(base);
        return g_strdup("audio");
    }
    return base;
}


/* ==========================================================================
 * Session lifecycle
 * ========================================================================== */

Mp3xSession *
mp3x_session_new(Mp3xDriver *d)
{
    Mp3xSession *s = g_new0(Mp3xSession, 1);

    /* generation is driver-owned and process-monotonic; never 0 (we
       pre-increment, and the driver starts its counter at 0). */
    s->generation = mp3x_driver_next_generation(d);

    /* sensible defaults for an unopened session */
    s->source   = 0;         /* LAME encoder side; recomputed on open */

    return s;
}


/* Internal: the per-file reset applied at the top of every open route.
   Clears the analyzer engine, the driver-visible transport state, and the
   per-file display options. Display options are then reset by the caller
   (the GUI layer may re-apply preserved preferences) before the session
   is installed. */
static void
mp3x_session_reset_fields(Mp3xSession *s)
{
    s->running         = FALSE;
    s->input_exhausted = FALSE;
    s->completed       = FALSE;
    s->failed          = FALSE;
    s->drain_remaining = 0;
    s->frames_done     = 0;
    s->advance_left    = 0;
    s->idle_id         = 0;
}


/**
 * \internal
 * \brief Opens the input file of a session, initializes its encoder and
 *        brings the analyzer up.
 *
 * Calls init_infile(), then lame_init_params() through
 * frontend_init_params(), then mp3x_core_init(), which closes any decoder
 * handle that it may still hold.
 *
 * \param s     the session, with its encoder set up.
 * \param path  the input file.
 * \param err   receives the error of the step that failed.
 * \return TRUE on success. FALSE when a step fails; the caller then closes
 *         the input file.
 */
static gboolean
mp3x_session_open_input(Mp3xSession *s, const char *path, GError **err)
{
    if ((s->reader = init_infile(s->gf, path)) == NULL) {
        g_set_error(err, MP3X_OPEN_ERROR, MP3X_OPEN_ERR_INIT_INFILE,
                    "mp3x: unable to initialize input file '%s'", path);
        return FALSE;
    }
    if (frontend_init_params(s->gf) < 0) {
        g_set_error(err, MP3X_OPEN_ERROR, MP3X_OPEN_ERR_INIT_PARAMS,
                    "mp3x: fatal error during initialization");
        return FALSE;
    }
    mp3x_core_init(s->reader);
    return TRUE;
}


/* Internal: the post-prevalidation common path. Assumes path is heap-owned
   and transferable. Takes ownership of `path` on success; frees it on
   failure. */
static gboolean
mp3x_session_install(Mp3xSession *s,
                     gchar *path, gchar *display_name, GError **err)
{
    /* 1. lame_init() + NULL check before any lame_set_* */
    s->gf = lame_init();
    if (s->gf == NULL) {
        g_set_error(err, MP3X_OPEN_ERROR, MP3X_OPEN_ERR_LAME_INIT,
                    "mp3x: lame_init() failed; out of memory");
        g_free(path);
        g_free(display_name);
        return FALSE;
    }

    /* Standard reporting hooks so LAME's diagnostics reach the frontend. */
    frontend_attach_reporting(s->gf);

    /* 2. Turn on the analyzer hooks. */
    (void) lame_set_analysis(s->gf, 1);

    /* 3. init_infile makes the format decision. The
          pre-classified extension hint is set first; if our classifier
          did not recognize the extension, we let init_infile's own header
          parser decide. */
    s->input_format = frontend_classify_suffix(path);
    if (s->input_format != sf_unknown)
        frontend_config.reader.input_format = s->input_format;

    /* 4. Open the input, initialize the encoder and the analyzer. */
    if (!mp3x_session_open_input(s, path, err))
        goto fail_with_infile;

    /* 5. Install the path. */
    s->in_path      = path;
    s->display_name = display_name;
    s->is_open      = TRUE;

    /* 6. Recompute the source default from the actual format. MP3 input
          defaults to mpg123-side analysis; PCM (WAV/AIFF) to LAME-side. */
    s->source = is_mpeg_file_format(frontend_config.reader.input_format) ? 1 : 0;

    mp3x_session_reset_fields(s);
    return TRUE;

fail_with_infile:
    close_infile(s->reader);
    s->reader = NULL;
    lame_close(s->gf);
    s->gf = NULL;
    g_free(path);
    g_free(display_name);
    return FALSE;
}


/* The GUI-open route: consume the driver's successful prevalidation,
   restore documented defaults, and do not replay CLI options. */
gboolean
mp3x_session_open_prevalidated(Mp3xSession *s, Mp3xDriver *d,
                               Mp3xPrevalidateResult *pre, GError **err)
{
    gchar *path;
    gchar *display_name;

    g_return_val_if_fail(s != NULL, FALSE);
    g_return_val_if_fail(pre != NULL, FALSE);
    g_return_val_if_fail(pre->fs_path != NULL, FALSE);

    /* The GTK layer retires the current session only after its preflight
       succeeds. Restore the startup baseline before opening the replacement. */
    mp3x_globals_restore(mp3x_driver_baseline(d));

    path = g_steal_pointer(&pre->fs_path);
    display_name = g_steal_pointer(&pre->display_name);
    mp3x_prevalidate_result_clear(pre);
    return mp3x_session_install(s, path, display_name, err);
}


/* The initial-CLI-file route: the full original argv is honored for this
   one file. It runs before GtkApplication is created, so parser information
   requests can exit successfully without realizing a window. */
Mp3xCliOpenResult
mp3x_session_open_cli_initial(Mp3xSession *s, Mp3xDriver *d,
                              int argc, char **argv,
                              GError **err)
{
    char  in_path[PATH_MAX + 1]  = {0};
    char  out_path[PATH_MAX + 1] = {0};
    char  out_dir[PATH_MAX + 1]  = {0};
    int   pa_ret;
    GFile *gfile = NULL;
    Mp3xPrevalidateResult pre = {0};

    g_return_val_if_fail(s != NULL, MP3X_CLI_OPEN_ERROR);
    g_return_val_if_fail(argv != NULL, MP3X_CLI_OPEN_ERROR);

    /* Restore the startup baseline so any prior file's state is gone. */
    mp3x_globals_restore(mp3x_driver_baseline(d));

    /* lame_init + NULL check before any lame_set_*. */
    s->gf = lame_init();
    if (s->gf == NULL) {
        g_set_error(err, MP3X_OPEN_ERROR, MP3X_OPEN_ERR_LAME_INIT,
                    "mp3x: lame_init() failed; out of memory");
        return MP3X_CLI_OPEN_ERROR;
    }
    frontend_attach_reporting(s->gf);

    /* parse_args runs against the FULL original argv. It sets Cat-1
       encoder/analyzer options, applies any input-specific options
       (raw forcing, format forcing, byte swap), and copies the first
       positional argument to in_path and the second to out_path.
       parse_args' own error reporting is preserved. */
    pa_ret = parse_args(s->gf, argc, argv, in_path, out_path, out_dir, NULL, NULL);
    if (pa_ret == -2) {
        lame_close(s->gf);
        s->gf = NULL;
        return MP3X_CLI_OPEN_EXIT_SUCCESS;
    }
    if (pa_ret < 0) {
        g_set_error(err, MP3X_OPEN_ERROR, MP3X_OPEN_ERR_PARSE_ARGS,
                    "mp3x: command-line parse rejected (code %d)", pa_ret);
        goto fail_with_lame;
    }

    /* If parse_args found no positional input file, this is an
       option-only invocation (e.g., 'mp3x -b 320'). Return a specific
       error so the caller can treat it as "stay empty" without showing
       an error dialog. */
    if (in_path[0] == '\0') {
        g_set_error(err, MP3X_OPEN_ERROR, MP3X_OPEN_ERR_NO_INPUT_FILE,
                    "no input file specified");
        goto fail_with_lame;
    }

    /* A parser-selected "-" is LAME's stdin sentinel, not a filesystem path.
       Keep it intact for init_infile and supply session-owned display
       metadata without constructing a GFile. All other CLI inputs follow the
       same regular-file prevalidation used by GUI opens. */
    if (strcmp(in_path, "-") == 0) {
        pre.fs_path = g_strdup("-");
        pre.display_name = g_strdup("standard input");
    }
    else {
        gfile = g_file_new_for_path(in_path);
        if (!mp3x_prevalidate(gfile, &pre, err))
            goto fail_with_lame;
        g_clear_object(&gfile);
    }

    /* Turn on the analyzer hooks (parse_args may not have). */
    (void) lame_set_analysis(s->gf, 1);

    if (!mp3x_session_open_input(s, pre.fs_path, err))
        goto fail_with_infile;

    /* Take ownership of the prepared path and display metadata. */
    s->in_path      = g_steal_pointer(&pre.fs_path);
    s->display_name = g_steal_pointer(&pre.display_name);
    mp3x_prevalidate_result_clear(&pre);
    s->input_format = frontend_config.reader.input_format;
    s->is_open      = TRUE;
    s->source       = is_mpeg_file_format(frontend_config.reader.input_format) ? 1 : 0;
    mp3x_session_reset_fields(s);
    return MP3X_CLI_OPENED;

fail_with_infile:
    close_infile(s->reader);
    s->reader = NULL;
fail_with_lame:
    g_clear_object(&gfile);
    mp3x_prevalidate_result_clear(&pre);
    lame_close(s->gf);
    s->gf = NULL;
    return MP3X_CLI_OPEN_ERROR;
}


void
mp3x_session_close(Mp3xSession *s)
{
    if (s == NULL || !s->is_open)
        return;

    /* Cancel the idle source first. The GTK layer's source-remove also
       bumps state_epoch on the driver, so any in-flight IdleContext
       fails its generation check; we still drop our local source ID
       defensively. */
    if (s->idle_id != 0) {
        g_source_remove(s->idle_id);
        s->idle_id = 0;
    }

    /* Analyzer engine teardown: releases the PCM-input re-synthesis
       decoder (core_state.hip). No-op for MP3 input. */
    mp3x_core_shutdown();

    /* Reader teardown: releases the MP3 input decoder (which wraps mpg123),
       the open FILE, libsndfile handle, ID3 buffer and PCM buffers, and
       the reader. */
    close_infile(s->reader);
    s->reader = NULL;

    /* Encoder handle teardown. On normal PCM completion the core has already
       called lame_encode_flush once and fed its bytes to the re-synthesis
       decoder; on early Close there is no need to synthesize an unseen tail.
       Encoded bytes are never written. lame_close releases the encoder,
       internal flags, and encoder-side analyzer slots. */
    if (s->gf != NULL) {
        lame_close(s->gf);
        s->gf = NULL;
    }

    g_free(s->in_path);
    g_free(s->display_name);
    s->in_path      = NULL;
    s->display_name = NULL;
    s->is_open      = FALSE;
}


void
mp3x_session_free(Mp3xSession *s)
{
    if (s == NULL)
        return;

    /* Defensive: if the caller forgot to close, do it now. _close is
       idempotent so a second call from the caller is safe. */
    if (s->is_open)
        mp3x_session_close(s);

    g_free(s);
}
