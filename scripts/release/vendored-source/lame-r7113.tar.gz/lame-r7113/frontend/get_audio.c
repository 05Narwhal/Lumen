/*
 *      Get Audio routines source file
 *
 *      Copyright (c) 1999 Albert L Faber
 *                    2008-2017 Robert Hegemann
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 */

/* $Id$ */


#ifdef HAVE_CONFIG_H
# include <config.h>
#endif

#include <assert.h>

#ifdef HAVE_LIMITS_H
# include <limits.h>
#endif

#include <stdarg.h>
#include <stdio.h>

#ifdef STDC_HEADERS
# include <stdlib.h>
# include <string.h>
#else
# ifndef HAVE_STRCHR
#  define strchr index
#  define strrchr rindex
# endif
char   *strchr(), *strrchr();
# ifndef HAVE_MEMCPY
#  define memcpy(d, s, n) bcopy ((s), (d), (n))
#  define memmove(d, s, n) bcopy ((s), (d), (n))
# endif
#endif

#ifdef HAVE_INTTYPES_H
# include <inttypes.h>
#else
# ifdef HAVE_STDINT_H
#  include <stdint.h>
# endif
#endif

#ifdef HAVE_MPG123
/**
 * @internal
 * The reader uses the decoder struct of libmp3lame (mpstr_tag from
 * mpglib/mpglib.h) as the hip_t of lame.h. That struct is not part of the
 * interface of libmp3lame. The lame program therefore needs the libmp3lame
 * of the same build.
 */
#define hip_global_struct mpstr_tag
#endif
#ifdef HAVE_MPG123
#include <mpg123.h>
/* for mpstr_tag */
#include "mpglib/mpglib.h"

#endif


#include <math.h>

#if defined(__riscos__)
# include <kernel.h>
# include <sys/swis.h>
#elif defined(_WIN32)
# include <io.h>
# include <sys/types.h>
# include <sys/stat.h>
# include <windows.h>
#else
# include <sys/stat.h>
#endif

#ifdef __sun__
/* woraround for SunOS 4.x, it has SEEK_* defined here */
#include <unistd.h>
#endif

#include "lame.h"
#include "main.h"
#include "get_audio.h"
#include "lametime.h"
#include "console.h"
#include "machine.h"
#include "encoder.h"
#include "lame-analysis.h"

#ifdef WITH_DMALLOC
#include <dmalloc.h>
#endif

/** The delay of the layer III decoder of libmpg123, in samples. */
#define MP3_DECODER_DELAY 529

#define UNSIGNED_TO_FLOAT(u) (((double)((long)((u) - 2147483647L - 1))) + 2147483648.0)

static void reader_error(const char *format, ...) CONSOLE_PRINTF(1, 2);

/**
 * @internal
 * @brief Prints an error message of the input reader, unless the user asked
 *        for no messages.
 *
 * @param format  the printf() format of the message.
 * @param ...     the values for @p format.
 */
static void
reader_error(const char *format, ...)
{
    va_list args;

    if (frontend_config.ui_config.silent < 10) {
        va_start(args, format);
        frontend_errorf(format, args);
        va_end(args);
    }
}

static uint32_t uint32_high_low(unsigned char const *bytes)
{
    uint32_t const hh = bytes[0];
    uint32_t const hl = bytes[1];
    uint32_t const lh = bytes[2];
    uint32_t const ll = bytes[3];
    return (hh << 24) | (hl << 16) | (lh << 8) | ll;
}

/**
 * @internal
 * @brief Returns the 32-bit value of 4 bytes, the least significant first.
 * @param bytes  the 4 bytes.
 * @return the value.
 */
static uint32_t uint32_low_high(unsigned char const *bytes)
{
    uint32_t const ll = bytes[0];
    uint32_t const lh = bytes[1];
    uint32_t const hl = bytes[2];
    uint32_t const hh = bytes[3];
    return (hh << 24) | (hl << 16) | (lh << 8) | ll;
}

/**
 * @internal
 * @brief Returns the 16-bit value of 2 bytes, the most significant first.
 * @param bytes  the 2 bytes.
 * @return the value.
 */
static uint16_t uint16_high_low(unsigned char const *bytes)
{
    uint16_t const h = bytes[0];
    uint16_t const l = bytes[1];
    return (uint16_t) ((h << 8) | l);
}

/**
 * @internal
 * @brief Returns the 16-bit value of 2 bytes, the least significant first.
 * @param bytes  the 2 bytes.
 * @return the value.
 */
static uint16_t uint16_low_high(unsigned char const *bytes)
{
    uint16_t const l = bytes[0];
    uint16_t const h = bytes[1];
    return (uint16_t) ((h << 8) | l);
}

/**
 * @internal
 * @brief Returns non-zero for an integer sample width that the readers unpack.
 * @param bits  the width in bits.
 * @return non-zero for 8, 16, 24 and 32, 0 otherwise.
 */
static int
pcm_int_width_supported(int bits)
{
    return bits == 8 || bits == 16 || bits == 24 || bits == 32;
}

/**
 * @internal
 * @brief Returns the bytes in one sample frame: one sample of each channel.
 * @param channels  the number of channels.
 * @param bits      the sample width in bits. A width that is not a whole
 *                  number of bytes takes up the next whole byte.
 * @return the frame size in bytes.
 */
static uint32_t
pcm_bytes_per_frame(unsigned int channels, unsigned int bits)
{
    return channels * ((bits + 7u) / 8u);
}

/* The header readers below return 0 on success and -1 once the input runs
   short, leaving their result untouched. Callers chain them so that the
   first short read stops the rest and rejects the file. */

static int
read_ieee_extended_high_low(FILE * fp, double *out)
{
    unsigned char bytes[10];
    memset(bytes, 0, 10);
    if (fread(bytes, 1, 10, fp) != 10)
        return -1;
    {
        int32_t const s = (bytes[0] & 0x80);
        int32_t const e_h = (bytes[0] & 0x7F);
        int32_t const e_l = bytes[1];
        int32_t e = (e_h << 8) | e_l;
        uint32_t const hm = uint32_high_low(bytes + 2);
        uint32_t const lm = uint32_high_low(bytes + 6);
        double  result = 0;
        if (e != 0 || hm != 0 || lm != 0) {
            if (e == 0x7fff) {
                result = HUGE_VAL;
            }
            else {
                double  mantissa_h = UNSIGNED_TO_FLOAT(hm);
                double  mantissa_l = UNSIGNED_TO_FLOAT(lm);
                e -= 0x3fff;
                e -= 31;
                result = ldexp(mantissa_h, e);
                e -= 32;
                result += ldexp(mantissa_l, e);
            }
        }
        *out = s ? -result : result;
        return 0;
    }
}


static int
read_16_bits_low_high(FILE * fp, uint16_t * out)
{
    unsigned char bytes[2] = { 0, 0 };
    if (fread(bytes, 1, 2, fp) != 2)
        return -1;
    *out = uint16_low_high(bytes);
    return 0;
}


static int
read_32_bits_low_high(FILE * fp, uint32_t * out)
{
    unsigned char bytes[4] = { 0, 0, 0, 0 };
    if (fread(bytes, 1, 4, fp) != 4)
        return -1;
    *out = uint32_low_high(bytes);
    return 0;
}

static int
read_16_bits_high_low(FILE * fp, uint16_t * out)
{
    unsigned char bytes[2] = { 0, 0 };
    if (fread(bytes, 1, 2, fp) != 2)
        return -1;
    *out = uint16_high_low(bytes);
    return 0;
}

static int
read_32_bits_high_low(FILE * fp, uint32_t * out)
{
    unsigned char bytes[4] = { 0, 0, 0, 0 };
    if (fread(bytes, 1, 4, fp) != 4)
        return -1;
    *out = uint32_high_low(bytes);
    return 0;
}

/* The WAV header fields are unsigned; taking an unsigned value keeps the
   byte extraction free of the signed-overflow and right-shift-of-negative that
   a size at/above INT_MAX would otherwise incur (e.g. the 0x7FFFFFFF streaming
   placeholder plus the 44-byte header). */
static void
write_16_bits_low_high(FILE * fp, unsigned int val)
{
    unsigned char bytes[2];
    bytes[0] = (val & 0xff);
    bytes[1] = ((val >> 8) & 0xff);
    fwrite(bytes, 1, 2, fp);
}

static void
write_32_bits_low_high(FILE * fp, unsigned int val)
{
    unsigned char bytes[4];
    bytes[0] = (val & 0xff);
    bytes[1] = ((val >> 8) & 0xff);
    bytes[2] = ((val >> 16) & 0xff);
    bytes[3] = ((val >> 24) & 0xff);
    fwrite(bytes, 1, 4, fp);
}

#ifdef LIBSNDFILE

#include <sndfile.h>


#else

typedef void SNDFILE;

#endif /* ifdef LIBSNDFILE */



typedef struct blockAlign_struct {
    uint32_t offset;
    uint32_t blockSize;
} blockAlign;

typedef struct IFF_AIFF_struct {
    unsigned long numSampleFrames;
    double  sampleRate;
    uint32_t sampleType;
    uint32_t sampleFormat;
    blockAlign blkAlgn;
    short   numChannels;
    short   sampleSize;
} IFF_AIFF;



struct PcmBuffer {
    void   *ch[2];           /* buffer for each channel */
    int     w;               /* sample width */
    int     n;               /* number samples allocated */
    int     u;               /* number samples used */
    int     skip_start;      /* number samples to ignore at the beginning */
    int     skip_end;        /* number samples to ignore at the end */
};

typedef struct PcmBuffer PcmBuffer;

static void
initPcmBuffer(PcmBuffer * b, int w)
{
    b->ch[0] = 0;
    b->ch[1] = 0;
    b->w = w;
    b->n = 0;
    b->u = 0;
    b->skip_start = 0;
    b->skip_end = 0;
}

static void
freePcmBuffer(PcmBuffer * b)
{
    if (b != 0) {
        free(b->ch[0]);
        free(b->ch[1]);
        b->ch[0] = 0;
        b->ch[1] = 0;
        b->n = 0;
        b->u = 0;
    }
}

/**
 * @internal
 * @brief Grows both channels of a sample buffer.
 *
 * @param b      the buffer.
 * @param n      the number of samples per channel it must hold.
 * @param bytes  the size of @p n samples of one channel, in bytes.
 * @return 0, or -1 when memory runs out. The buffer then keeps its samples.
 */
static int
growPcmBuffer(PcmBuffer * b, int n, int bytes)
{
    void   *ch;

    ch = realloc(b->ch[0], bytes);
    if (ch == NULL)
        return -1;
    b->ch[0] = ch;
    ch = realloc(b->ch[1], bytes);
    if (ch == NULL)
        return -1;
    b->ch[1] = ch;
    b->n = n;
    return 0;
}

/**
 * @internal
 * @brief Adds the samples of one read to a sample buffer.
 *
 * The samples to skip at the start are dropped first.
 *
 * @param b     the buffer, or NULL.
 * @param a0    the first channel of the read, or NULL.
 * @param a1    the second channel of the read, or NULL.
 * @param read  the number of samples per channel that were read. Negative
 *              after a read error.
 * @param used  receives the number of samples that the buffer can hand out.
 * @return 0, or -1 when memory runs out.
 */
static int
addPcmBuffer(PcmBuffer * b, void *a0, void *a1, int read, int *used)
{
    int     a_n;

    *used = 0;
    if (b == 0) {
        return 0;
    }
    if (read < 0) {
        *used = b->u - b->skip_end;
        return 0;
    }
    if (b->skip_start >= read) {
        b->skip_start -= read;
        *used = b->u - b->skip_end;
        return 0;
    }
    a_n = read - b->skip_start;

    if (a_n > 0) {
        int const a_skip = b->w * b->skip_start;
        int const a_want = b->w * a_n;
        int const b_used = b->w * b->u;
        int const b_have = b->w * b->n;
        int const b_need = b->w * (b->u + a_n);
        if (b_have < b_need) {
            if (growPcmBuffer(b, b->u + a_n, b_need) < 0)
                return -1;
        }
        b->u += a_n;
        if (b->ch[0] != 0 && a0 != 0) {
            char   *src = a0;
            char   *dst = b->ch[0];
            memcpy(dst + b_used, src + a_skip, a_want);
        }
        if (b->ch[1] != 0 && a1 != 0) {
            char   *src = a1;
            char   *dst = b->ch[1];
            memcpy(dst + b_used, src + a_skip, a_want);
        }
    }
    b->skip_start = 0;
    *used = b->u - b->skip_end;
    return 0;
}

static int
takePcmBuffer(PcmBuffer * b, void *a0, void *a1, int a_n, int mm)
{
    if (a_n > mm) {
        a_n = mm;
    }
    if (b != 0 && a_n > 0) {
        int const a_take = b->w * a_n;
        if (a0 != 0 && b->ch[0] != 0) {
            memcpy(a0, b->ch[0], a_take);
        }
        if (a1 != 0 && b->ch[1] != 0) {
            memcpy(a1, b->ch[1], a_take);
        }
        b->u -= a_n;
        if (b->u < 0) {
            b->u = 0;
            return a_n;
        }
        if (b->ch[0] != 0) {
            memmove(b->ch[0], (char *) b->ch[0] + a_take, b->w * b->u);
        }
        if (b->ch[1] != 0) {
            memmove(b->ch[1], (char *) b->ch[1] + a_take, b->w * b->u);
        }
    }
    return a_n;
}

/** @internal @brief The state of one open input file. */
struct audio_reader {
    int     count_samples_carefully;
    int     pcmbitwidth;
    int     pcmswapbytes;
    int     pcm_is_unsigned_8bit;
    int     pcm_is_ieee_float;
    int     input_ends_inside_a_frame;
    int     input_shorter_than_its_tag;
    unsigned long num_samples_read;
    unsigned long num_samples_above_full_scale;
    FILE   *music_in;
    unsigned char *in_buffer;   /**< the stdio buffer of music_in, or NULL */
    SNDFILE *snd_file;
    hip_t     hip;
    PcmBuffer pcm32;
    PcmBuffer pcm16;
    PcmBuffer pcmf;
    size_t  in_id3v2_size;
    unsigned char* in_id3v2_tag;
};

/**
 * @internal
 * @brief Where the samples of one frame go: two channels of one sample type.
 *
 * Exactly one of the three pairs is set; the other two are NULL.
 */
typedef struct {
    int    *i[2];               /**< int samples, full scale at the int's range */
    short  *s[2];               /**< 16 bit samples, for --decode */
    float  *f[2];               /**< float samples, 1.0 being full scale */
} frame_dest;



#ifdef HAVE_MPG123
int     lame123_decode_initfile(audio_reader * reader, FILE * fd, mp3data_struct * mp3data,
                                int *enc_delay, int *enc_padding);
#endif


static int read_samples_pcm(audio_reader * reader, frame_dest const *dest, int num_channels,
                            int samples_to_read);
static int read_samples_float(audio_reader * reader, FILE * musicin,
                              float sample_buffer[2 * FRAME_BUFFER_SAMPLES],
                              int samples_to_read);
static int read_samples_mp3(audio_reader * reader, frame_dest const *dest);
#ifdef LIBSNDFILE
static SNDFILE *open_snd_file(audio_reader * reader, lame_t gfp, char const *inPath);
#endif
static FILE *open_mpeg_file(audio_reader * reader, lame_t gfp, char const *inPath, int *enc_delay,
                            int *enc_padding);
static FILE *open_wave_file(audio_reader * reader, lame_t gfp, char const *inPath, int *enc_delay,
                            int *enc_padding);
static int close_input_file(FILE * musicin);


static  size_t
min_size_t(size_t a, size_t b)
{
    if (a < b) {
        return a;
    }
    return b;
}

/**
 * @internal
 * @brief Returns the byte order of this machine.
 * @return ::ByteOrderBigEndian or ::ByteOrderLittleEndian.
 */
static enum ByteOrder
machine_byte_order(void)
{
    long    one = 1;
    return !(*((char *) (&one))) ? ByteOrderBigEndian : ByteOrderLittleEndian;
}



/* Replacement for forward fseek(,,SEEK_CUR), because fseek() fails on pipes */


static int
fskip_long(FILE * fp, long offset, int whence)
{
#ifndef PIPE_BUF
    char    buffer[4096];
#else
    char    buffer[PIPE_BUF];
#endif

/* S_ISFIFO macro is defined on newer Linuxes */
#ifndef S_ISFIFO
# ifdef _S_IFIFO
    /* _S_IFIFO is defined on Win32 and Cygwin */
#  define S_ISFIFO(m) (((m)&_S_IFIFO) == _S_IFIFO)
# endif
#endif

#ifdef S_ISFIFO
    /* fseek is known to fail on pipes with several C-Library implementations
       workaround: 1) test for pipe
       2) for pipes, only relatvie seeking is possible
       3)            and only in forward direction!
       else fallback to old code
     */
    {
        int const fd = fileno(fp);
        struct stat file_stat;

        if (fstat(fd, &file_stat) == 0) {
            if (S_ISFIFO(file_stat.st_mode)) {
                if (whence != SEEK_CUR || offset < 0) {
                    return -1;
                }
                while (offset > 0) {
                    size_t const bytes_to_skip = min_size_t(sizeof(buffer), offset);
                    size_t const read = fread(buffer, 1, bytes_to_skip, fp);
                    if (read < 1) {
                        return -1;
                    }
                    assert( read <= LONG_MAX );
                    offset -= (long) read;
                }
                return 0;
            }
        }
    }
#endif
    if (0 == fseek(fp, offset, whence)) {
        return 0;
    }

    if (whence != SEEK_CUR || offset < 0) {
        reader_error("fskip problem: Mostly the return status of functions is not evaluated, "
                     "so it is more secure to pollute <stderr>.\n");
        return -1;
    }

    while (offset > 0) {
        size_t const bytes_to_skip = min_size_t(sizeof(buffer), offset);
        size_t const read = fread(buffer, 1, bytes_to_skip, fp);
        if (read < 1) {
            return -1;
        }
        assert( read <= LONG_MAX );
        offset -= (long) read;
    }

    return 0;
}

static int
fskip_uint32(FILE * fp, uint32_t offset)
{
    int   ret = 0;
    while (offset > INT_MAX && ret == 0) {
        offset -= INT_MAX;
        ret = fskip_long(fp, INT_MAX, SEEK_CUR);
    }
    if (offset > 0 && ret == 0) {
        ret = fskip_long(fp, offset, SEEK_CUR);
    }
    return ret;
}

static  off_t
lame_get_file_size(FILE * fp)
{
    struct stat sb;
    int     fd = fileno(fp);

    if (0 == fstat(fd, &sb))
        return sb.st_size;
    return (off_t) - 1;
}


FILE   *
init_outfile(char const *outPath, LAME_UNUSED int decode)
{
    FILE   *outf;

    /* open the output file */
    if (0 == strcmp(outPath, "-")) {
        outf = stdout;
        lame_set_stream_binary_mode(outf);
    }
    else {
        outf = lame_fopen(outPath, "w+b");
#ifdef __riscos__
        /* Assign correct file type */
        if (outf != NULL) {
            char   *p, *out_path = strdup(outPath);
            if (out_path != NULL) {
                for (p = out_path; *p; p++) { /* ugly, ugly to modify a string */
                    switch (*p) {
                    case '.':
                        *p = '/';
                        break;
                    case '/':
                        *p = '.';
                        break;
                    }
                }
                SetFiletype(out_path, decode ? 0xFB1 /*WAV*/ : 0x1AD /*AMPEG*/);
                free(out_path);
            }
        }
#endif
    }
    return outf;
}


static void
setSkipStartAndEnd(audio_reader * reader, lame_t gfp, int enc_delay, int enc_padding)
{
    int     skip_start = 0, skip_end = 0;

    if (frontend_config.decoder.mp3_delay_set)
        skip_start = frontend_config.decoder.mp3_delay;

    switch (frontend_config.reader.input_format) {
    case sf_mp123:
        break;

    case sf_mp3:
        if (skip_start == 0) {
            if (enc_delay > -1 || enc_padding > -1) {
                if (enc_delay > -1)
                    skip_start = enc_delay + MP3_DECODER_DELAY;
                if (enc_padding > -1)
                    skip_end = enc_padding - MP3_DECODER_DELAY;
            }
            else
                skip_start = lame_get_encoder_delay(gfp) + MP3_DECODER_DELAY;
        }
        else {
            /* user specified a value of skip. just add for decoder */
            skip_start += MP3_DECODER_DELAY;
        }
        break;
    case sf_mp2:
        skip_start += 240 + 1;
        break;
    case sf_mp1:
        skip_start += 240 + 1;
        break;
    default:
        break;
    }
    skip_start = skip_start < 0 ? 0 : skip_start;
    skip_end = skip_end < 0 ? 0 : skip_end;
    reader->pcmf.skip_start = reader->pcm16.skip_start = reader->pcm32.skip_start = skip_start;
    reader->pcmf.skip_end = reader->pcm16.skip_end = reader->pcm32.skip_end = skip_end;
}



/**
 * @internal
 * @brief Opens an input file and reads its header.
 *
 * The header sets the sample rate, the channel count and the number of
 * samples of @p gfp.
 *
 * @param gfp     the encoder.
 * @param inPath  the input file, or "-" for standard input.
 * @return the reader of the file, or NULL if it cannot be read. Close it with
 *         close_infile().
 */
audio_reader *
init_infile(lame_t gfp, char const *inPath)
{
    audio_reader *const reader = calloc(1, sizeof(*reader));
    int     enc_delay = 0, enc_padding = 0;

    if (reader == NULL) {
        reader_error("Error: out of memory\n");
        return NULL;
    }
    reader->pcmbitwidth = frontend_config.raw_pcm.in_bitwidth;
    reader->pcmswapbytes = frontend_config.reader.swapbytes;
    reader->pcm_is_unsigned_8bit = frontend_config.raw_pcm.in_signed == 1 ? 0 : 1;
    if (is_mpeg_file_format(frontend_config.reader.input_format)) {
        reader->music_in = open_mpeg_file(reader, gfp, inPath, &enc_delay, &enc_padding);
    }
    else {
#ifdef LIBSNDFILE
        if (strcmp(inPath, "-") != 0) { /* not for stdin */
            reader->snd_file = open_snd_file(reader, gfp, inPath);
        }
#endif
        if (reader->snd_file == 0) {
            reader->music_in = open_wave_file(reader, gfp, inPath, &enc_delay, &enc_padding);
        }
    }
    initPcmBuffer(&reader->pcm32, sizeof(int));
    initPcmBuffer(&reader->pcm16, sizeof(short));
    initPcmBuffer(&reader->pcmf, sizeof(float));
    setSkipStartAndEnd(reader, gfp, enc_delay, enc_padding);
    {
        unsigned long n = lame_get_num_samples(gfp);
        if (n != NUM_SAMPLES_UNKNOWN) {
            unsigned long const discard = reader->pcm32.skip_start + reader->pcm32.skip_end;
            lame_set_num_samples(gfp, n > discard ? n - discard : 0);
        }
    }
    if (reader->snd_file == NULL && reader->music_in == NULL) {
        close_infile(reader);
        return NULL;
    }
    if (frontend_config.reader.swap_channel && lame_get_num_channels(gfp) != 2) {
        reader_error("Error: --swap-channel needs an input with two channels\n");
        close_infile(reader);
        return NULL;
    }
    return reader;
}

int
samples_to_skip_at_start(audio_reader const * reader)
{
    return reader->pcm32.skip_start;
}

int
samples_to_skip_at_end(audio_reader const * reader)
{
    return reader->pcm32.skip_end;
}

/**
 * @internal
 * @brief Returns how many floating point input samples are above full scale
 *        after the scaling of the encoder.
 *
 * @c get_audio_float() counts them while it reads. So the count covers the
 * part of the file that was read so far. It starts at 0 for each input file. A
 * sample at exactly full scale is not counted.
 *
 * @param reader  the reader of the input file.
 * @return the number of samples. 0 if no sample was above full scale, or if
 *         the input has no floating point samples.
 */
unsigned long
samples_above_full_scale(audio_reader const * reader)
{
    return reader->num_samples_above_full_scale;
}

/**
 * @internal
 * @brief Tells whether the input file ended inside a sample frame.
 *
 * The samples of that last frame are not encoded. The result covers the part
 * of the file that was read so far, and is 0 again for each new input file.
 *
 * @param reader  the reader of the input file.
 * @return 1 if the input ended inside a frame, else 0.
 */
int
input_ends_inside_a_frame(audio_reader const * reader)
{
    return reader->input_ends_inside_a_frame;
}

/**
 * @internal
 * @brief Tells whether the input file holds fewer samples than the encoder
 *        delay and padding in its LAME tag.
 *
 * Such an input gives no samples. The result covers the part of the file that
 * was read so far, and is 0 again for each new input file.
 *
 * @param reader  the reader of the input file.
 * @return 1 if the input is shorter than its tag says, else 0.
 */
int
input_shorter_than_its_tag(audio_reader const * reader)
{
    return reader->input_shorter_than_its_tag;
}

/**
 * @internal
 * @brief Tells whether the open input file contains floating point samples.
 *
 * The frontend reads such a file with @c get_audio_float() and encodes it with
 * @c lame_encode_buffer_ieee_float(). @c get_audio() returns -1 for such a
 * file.
 *
 * @param reader  the reader of the input file.
 * @return nonzero for floating point samples, 0 otherwise.
 */
int
input_is_float(audio_reader const * reader)
{
    return reader->pcm_is_ieee_float;
}

/**
 * @internal
 * @brief Closes the input file of a reader and frees the reader.
 *
 * @param reader  the reader from init_infile(), or NULL.
 */
void
close_infile(audio_reader * reader)
{
    if (reader == NULL)
        return;
#ifdef HAVE_MPG123
    if (reader->hip != 0) {
        hip_decode_exit(reader->hip); /* release mp3decoder memory */
    }
#endif
    close_input_file(reader->music_in);
    free(reader->in_buffer);
#ifdef LIBSNDFILE
    if (reader->snd_file) {
        if (sf_close(reader->snd_file) != 0) {
            reader_error("Could not close sound file \n");
        }
    }
#endif
    freePcmBuffer(&reader->pcm32);
    freePcmBuffer(&reader->pcm16);
    freePcmBuffer(&reader->pcmf);
    free(reader->in_id3v2_tag);
    free(reader);
}


static int get_audio_common(audio_reader * reader, lame_t gfp, frame_dest const *dest);


/**
 * @internal
 * @brief Converts a floating point sample to a 16 bit one, for the 16 bit
 *        PCM that @c --decode writes.
 *
 * The function rounds the sample to 32 bits and keeps the top 16 bits.
 * Integer samples are reduced to 16 bits in the same way. So both readers in
 * this file return the same value, whichever one @c --with-fileio selected.
 *
 * @param u a finite sample, where 1.0 is full scale.
 * @return the 16 bit sample. A sample at or above full scale gives the largest
 *         or the smallest 16 bit value.
 */
static short
float_sample_to_16bit(float u)
{
    /* Magnitude that a sample of 1.0 would map to at 32 bit. The two
       full-scale magnitudes differ by one, but neither is representable in a
       float: both round to 2^31, so a single factor scales both signs. Samples
       of magnitude 1 or above are taken before scaling, so the product always
       stays below 2^31 and the conversion cannot overflow. */
    float const full_scale = -(float) INT_MIN;
    int     wide;
    if (u >= 1)
        return SHRT_MAX;
    if (u <= -1)
        return SHRT_MIN;
    if (u >= 0)
        wide = (int) (u * full_scale + 0.5f);
    else
        wide = (int) (u * full_scale - 0.5f);
    return (short) (wide >> (8 * sizeof(int) - 16));
}

/**
 * @internal
 * @brief Counts the samples that the encoder gets above full scale.
 *
 * Before counting, the function applies the same scaling as the encoder: the
 * overall scale, the left and right scales, and the mix of two input channels
 * into one mono output channel. It uses the values that @c lame_init_params()
 * set. A sample that this scaling brings back within full scale is not
 * counted.
 *
 * @param gfp  the encoder instance, after @c lame_init_params().
 * @param l    the left channel, where 1.0 is full scale.
 * @param r    the right channel. Not read for mono input.
 * @param n    the number of samples per channel.
 * @return the number of samples above full scale.
 */
static unsigned long
count_above_full_scale(lame_t gfp, float const *l, float const *r, int n)
{
    float const gain = lame_get_scale(gfp);
    float const gain_l = gain * lame_get_scale_left(gfp);
    float const gain_r = gain * lame_get_scale_right(gfp);
    unsigned long count = 0;
    int     i;

    if (lame_get_num_channels(gfp) == 2 && lame_get_mode(gfp) == MONO) {
        float const mix_l = 0.5f * gain_l, mix_r = 0.5f * gain_r;
        for (i = 0; i < n; ++i) {
            float const u = mix_l * l[i] + mix_r * r[i];
            count += (u > 1.0f) | (u < -1.0f);
        }
        return count;
    }
    for (i = 0; i < n; ++i) {
        float const u = gain_l * l[i];
        count += (u > 1.0f) | (u < -1.0f);
    }
    if (lame_get_num_channels(gfp) == 2) {
        for (i = 0; i < n; ++i) {
            float const v = gain_r * r[i];
            count += (v > 1.0f) | (v < -1.0f);
        }
    }
    return count;
}

/**
 * @internal
 * @brief Reads one frame of samples through a sample buffer, and swaps the
 *        channels when the user asked for it.
 *
 * The samples go through the sample buffer only when it holds samples, or has
 * samples to drop at the start or to hold back at the end. Otherwise they are
 * read straight into @p dest, with the channels already swapped.
 *
 * @param reader  the reader of the input file.
 * @param gfp     the encoder instance, after @c lame_init_params().
 * @param pcm     the sample buffer for the sample type of @p dest.
 * @param dest    the two channels of the output; @p left and @p right are the
 *                same two arrays.
 * @param left    the first channel of the output.
 * @param right   the second channel of the output.
 * @return the number of samples per channel. 0 at the end of the input, also
 *         when the input is shorter than the delay and padding in its tag,
 *         and a negative value on an error.
 */
static int
read_frame(audio_reader * reader, lame_t gfp, PcmBuffer * pcm, frame_dest const *dest,
           void *left, void *right)
{
    int     used = 0, read = 0;
    if (pcm->u == 0 && pcm->skip_start == 0 && pcm->skip_end == 0) {
        frame_dest swapped;
        if (frontend_config.reader.swap_channel == 0)
            return get_audio_common(reader, gfp, dest);
        swapped.i[0] = dest->i[1];
        swapped.i[1] = dest->i[0];
        swapped.s[0] = dest->s[1];
        swapped.s[1] = dest->s[0];
        swapped.f[0] = dest->f[1];
        swapped.f[1] = dest->f[0];
        return get_audio_common(reader, gfp, &swapped);
    }
    do {
        read = get_audio_common(reader, gfp, dest);
        if (addPcmBuffer(pcm, left, right, read, &used) < 0)
            return -1;
    } while (used <= 0 && read > 0);
    if (read < 0) {
        return read;
    }
    if (used < 0) {
        if (!reader->input_shorter_than_its_tag) {
            reader->input_shorter_than_its_tag = 1;
            reader_error("Error: the input holds fewer samples than the encoder delay and\n"
                         "       padding in its LAME tag. It gives no samples.\n");
        }
        return 0;
    }
    if (frontend_config.reader.swap_channel == 0)
        return takePcmBuffer(pcm, left, right, used, FRAME_BUFFER_SAMPLES);
    else
        return takePcmBuffer(pcm, right, left, used, FRAME_BUFFER_SAMPLES);
}

/************************************************************************
*
* get_audio()
*
* PURPOSE:  reads a frame of audio data from a file to the buffer,
*   aligns the data for future processing, and separates the
*   left and right channels
*
************************************************************************/
int
get_audio(audio_reader * reader, lame_t gfp, int buffer[2][FRAME_BUFFER_SAMPLES])
{
    frame_dest dest = { { NULL, NULL }, { NULL, NULL }, { NULL, NULL } };
    dest.i[0] = buffer[0];
    dest.i[1] = buffer[1];
    return read_frame(reader, gfp, &reader->pcm32, &dest, buffer[0], buffer[1]);
}

/*
  get_audio16 - behave as the original get_audio function, with a limited
                16 bit per sample output
*/
int
get_audio16(audio_reader * reader, lame_t gfp, short buffer[2][FRAME_BUFFER_SAMPLES])
{
    frame_dest dest = { { NULL, NULL }, { NULL, NULL }, { NULL, NULL } };
    dest.s[0] = buffer[0];
    dest.s[1] = buffer[1];
    return read_frame(reader, gfp, &reader->pcm16, &dest, buffer[0], buffer[1]);
}

/**
 * @internal
 * @brief Reads one frame of floating point samples.
 *
 * It works like @c get_audio(), which reads integer samples. The samples are
 * not converted: 1.0 is full scale, as @c lame_encode_buffer_ieee_float()
 * expects. The function counts the samples that are above full scale after
 * scaling. @c samples_above_full_scale() returns this count.
 *
 * @param reader  the reader of the input file.
 * @param gfp     the encoder instance, after @c lame_init_params().
 * @param buffer  receives up to 1152 samples per channel.
 * @return the number of samples per channel. 0 at the end of the input, and a
 *         negative value on an error.
 */
int
get_audio_float(audio_reader * reader, lame_t gfp, float buffer[2][FRAME_BUFFER_SAMPLES])
{
    frame_dest dest = { { NULL, NULL }, { NULL, NULL }, { NULL, NULL } };
    int     n;

    dest.f[0] = buffer[0];
    dest.f[1] = buffer[1];
    n = read_frame(reader, gfp, &reader->pcmf, &dest, buffer[0], buffer[1]);

    if (n < 0) {
        return n;
    }
    reader->num_samples_above_full_scale += count_above_full_scale(gfp, buffer[0], buffer[1], n);
    return n;
}

/************************************************************************
  get_audio_common - central functionality of get_audio*
    in: gfp
   out: buffer    int output    (if buffer != NULL)
        buffer16  16-bit output (if buffer16 != NULL)
        bufferf   float output  (if bufferf != NULL)
returns: samples read
note: exactly one of the three is given; a floating point file is read into
      bufferf, or into buffer16 for --decode, never into buffer, and only a
      floating point file into bufferf
*/

/**
 * @internal
 * @brief Splits interleaved samples into the two channels of @p dst.
 *
 * The @p n samples per channel end at @p src_end, which the loop moves back to
 * their start. Each sample passes through @p CONV. With one channel, the second
 * channel of @p dst is set to zero.
 */
#define DEINTERLEAVE(dst, src_end, n, nch, CONV)                      \
    do {                                                              \
        int     k_;                                                   \
        if ((nch) == 2) {                                             \
            for (k_ = (n); --k_ >= 0;) {                              \
                (dst)[1][k_] = CONV(*--(src_end));                    \
                (dst)[0][k_] = CONV(*--(src_end));                    \
            }                                                         \
        }                                                             \
        else {                                                        \
            memset((dst)[1], 0, (n) * sizeof((dst)[1][0]));           \
            for (k_ = (n); --k_ >= 0;)                                \
                (dst)[0][k_] = CONV(*--(src_end));                    \
        }                                                             \
    } while (0)
/** @internal @brief Keeps a sample as it is, for DEINTERLEAVE(). */
#define SAMPLE_AS_IS(x)     (x)
/** @internal @brief Keeps the top 16 bits of an int sample, for DEINTERLEAVE(). */
#define INT_TO_16BIT(x)     ((x) >> (8 * sizeof(int) - 16))

/**
 * @internal
 * @brief Returns the number of samples of a read that make up whole frames.
 *
 * A read returns fewer samples than it asked for only at the end of the input.
 * When that number is not a multiple of the channel count, the input ends
 * inside a frame. The samples of that frame are left out, and an error
 * message says so once. The encoding then ends with the last whole frame.
 *
 * @param reader        the reader of the input file.
 * @param samples_read  the number of samples that the read returned.
 * @param num_channels  the number of channels of the input.
 * @return the number of samples in whole frames.
 */
static int
whole_frame_samples(audio_reader * reader, int samples_read, int num_channels)
{
    int const partial = samples_read % num_channels;

    if (partial != 0 && !reader->input_ends_inside_a_frame) {
        reader->input_ends_inside_a_frame = 1;
        reader_error("Error: the input ends inside a sample frame. The samples of that frame\n"
                     "       are not encoded.\n");
    }
    return samples_read - partial;
}

/**
 * @internal
 * @brief Returns how many samples per channel to read for the next frame.
 *
 * That is one frame, or less where the input's sample count says fewer are
 * left. LAME takes input of any length, but the frame analyzer gets out of
 * step if a read returns more than one frame.
 *
 * @param reader         the reader of the input file.
 * @param gfp            the encoder.
 * @param framesize      the samples per channel of one frame.
 * @param input_is_mpeg  whether the input is MPEG audio.
 * @return the number of samples per channel to read.
 */
static int
frame_read_limit(audio_reader const * reader, lame_t gfp, int framesize, int input_is_mpeg)
{
    int     samples_to_read = framesize;

    /* if this flag has been set, then we are carefull to read
     * exactly num_samples and no more.  This is useful for .wav and .aiff
     * files which have id3 or other tags at the end.  Note that if you
     * are using LIBSNDFILE, this is not necessary
     */
    if (reader->count_samples_carefully) {
        unsigned long tmp_num_samples, remaining;
        /* get num_samples */
        if (input_is_mpeg) {
            tmp_num_samples = frontend_config.decoder.mp3input_data.nsamp;
        }
        else {
            tmp_num_samples = lame_get_num_samples(gfp);
        }
        if (reader->num_samples_read < tmp_num_samples) {
            remaining = tmp_num_samples - reader->num_samples_read;
        }
        else {
            remaining = 0;
        }
        if (remaining < (unsigned long) framesize && 0 != tmp_num_samples)
            /* in case the input is a FIFO (at least it's reproducible with
               a FIFO) tmp_num_samples may be 0 and therefore remaining
               would be 0, but we need to read some samples, so don't
               change samples_to_read to the wrong value in this case */
            samples_to_read = (int) remaining; /* bounded by framesize above */
    }
    return samples_to_read;
}

/**
 * @internal
 * @brief Reads the next frame of floating point PCM input.
 *
 * @param reader           the reader of the input file.
 * @param dest             receives the samples as float, or as 16 bit for
 *                         @c --decode.
 * @param num_channels     the number of channels, 1 or 2.
 * @param samples_to_read  the samples per channel to read.
 * @return the number of samples per channel, or a negative value on an error.
 */
static int
read_frame_float(audio_reader * reader, frame_dest const *dest, int num_channels,
                 int samples_to_read)
{
    int     samples_read;
    int     i;
    /* The samples as stored, 1.0 being full scale. get_audio_common() holds
       the frame to FRAME_BUFFER_SAMPLES samples of one or two channels. */
    float   fsamp[2 * FRAME_BUFFER_SAMPLES];
    float const *q;

    assert(num_channels == 1 || num_channels == 2);
    if (reader->snd_file) {
#ifdef LIBSNDFILE
        samples_read = (int) sf_read_float(reader->snd_file, fsamp,
                                           num_channels * samples_to_read);
#else
        samples_read = 0;
#endif
    }
    else {
        samples_read =
            read_samples_float(reader, reader->music_in, fsamp, num_channels * samples_to_read);
    }
    if (samples_read < 0) {
        return samples_read;
    }
    samples_read = whole_frame_samples(reader, samples_read, num_channels);
    q = fsamp + samples_read;
    if (dest->f[0] == NULL) {
        /* --decode writes 16 bit PCM, and a sample that is not a finite
           number has no 16 bit value */
        for (i = 0; i < samples_read; ++i) {
            if (!float_is_finite(fsamp[i])) {
                reader_error("Error: the input holds a sample that is not a finite number\n");
                return -1;
            }
        }
    }
    samples_read /= num_channels;
    if (dest->f[0] != NULL)
        DEINTERLEAVE(dest->f, q, samples_read, num_channels, SAMPLE_AS_IS);
    else
        DEINTERLEAVE(dest->s, q, samples_read, num_channels, float_sample_to_16bit);
    return samples_read;
}

/**
 * @internal
 * @brief Reads the next frame of integer PCM input.
 *
 * @param reader           the reader of the input file.
 * @param dest             receives the samples as int, or as 16 bit for
 *                         @c --decode.
 * @param num_channels     the number of channels, 1 or 2.
 * @param samples_to_read  the samples per channel to read.
 * @return the number of samples per channel, or a negative value on an error.
 */
static int
read_frame_int(audio_reader * reader, frame_dest const *dest, int num_channels,
               int samples_to_read)
{
    assert(num_channels == 1 || num_channels == 2);
    if (reader->snd_file) {
#ifdef LIBSNDFILE
        int     insamp[2 * FRAME_BUFFER_SAMPLES];
        int const items = num_channels * samples_to_read;
        int     samples_read = sf_read_int(reader->snd_file, insamp, items);
        int    *p;

        if (samples_read < 0) {
            return samples_read;
        }
        samples_read = whole_frame_samples(reader, samples_read, num_channels);
        p = insamp + samples_read;
        samples_read /= num_channels;
        if (dest->i[0] != NULL)
            DEINTERLEAVE(dest->i, p, samples_read, num_channels, SAMPLE_AS_IS);
        else
            DEINTERLEAVE(dest->s, p, samples_read, num_channels, INT_TO_16BIT);
        return samples_read;
#else
        return 0;
#endif
    }
    return read_samples_pcm(reader, dest, num_channels, samples_to_read);
}

static int
get_audio_common(audio_reader * reader, lame_t gfp, frame_dest const *dest)
{
    const int num_channels = lame_get_num_channels(gfp);
    const int framesize = lame_get_framesize(gfp);
    /* The input format cannot change while we are reading from it, so ask once. */
    const int input_is_mpeg = is_mpeg_file_format(frontend_config.reader.input_format);
    int     samples_read;
    int     samples_to_read;

    /* sanity checks, that's what we expect to be true */
    if ((num_channels < 1 || 2 < num_channels)
      ||(framesize < 1 || FRAME_BUFFER_SAMPLES < framesize)
      ||(dest->f[0] != NULL && !reader->pcm_is_ieee_float)
      ||(dest->i[0] != NULL && reader->pcm_is_ieee_float)) {
        reader_error("Error: internal problem!\n");
        return -1;
    }

    samples_to_read = frame_read_limit(reader, gfp, framesize, input_is_mpeg);

    if (input_is_mpeg)
        samples_read = read_samples_mp3(reader, dest);
    else if (reader->pcm_is_ieee_float)
        samples_read = read_frame_float(reader, dest, num_channels, samples_to_read);
    else
        samples_read = read_frame_int(reader, dest, num_channels, samples_to_read);
    if (samples_read < 0) {
        return samples_read;
    }

    /* if ... then it is considered infinitely long.
       Don't count the samples */
    if (reader->count_samples_carefully)
        reader->num_samples_read += samples_read;

    return samples_read;
}

#undef DEINTERLEAVE
#undef SAMPLE_AS_IS
#undef INT_TO_16BIT



/**
 * @internal
 * @brief Decodes the next frame of MPEG input into the two channels of
 *        @p dest.
 *
 * The decoder's interleaved 16 bit samples are split, and for int output
 * widened to the int's range, in one pass. From a mono stream, int output's
 * second channel is cleared; 16 bit output's is left as it is.
 *
 * @param reader  the reader of the input file.
 * @param dest    receives the samples as int, or as 16 bit for @c --decode.
 * @return the number of samples per channel, or a negative value on an error.
 */
static int
read_samples_mp3(LAME_UNUSED audio_reader * reader, LAME_UNUSED frame_dest const *dest)
{
    int     out;
#ifdef HAVE_MPG123
    short int *outbuf;
    size_t outbytes;
    int const stereo = frontend_config.decoder.mp3input_data.stereo;
    int const shift = 8 * (int) sizeof(int) - 16;
    int     i;
    static const char type_name[] = "MP3 file";

    /* Need to deinterleave so rather use mpg123_decode_frame() to decode the
       current frame and deinterleave from the internal buffer. */
    out = mpg123_decode_frame(reader->hip->mh, NULL, (unsigned char**)&outbuf, &outbytes);
    if (out != MPG123_OK && out != MPG123_DONE)
    {
        if (out == MPG123_NEW_FORMAT)
        {
            reader_error("Error: format changed in %s - not supported\n", type_name);
        }
        return -1;
    }
    out = (int)(outbytes/(sizeof(short)*stereo));
    if (dest->i[0] != NULL) {
        int    *const l = dest->i[0];
        int    *const r = dest->i[1];
        if (stereo == 2) {
            for (i = 0; i < out; ++i) {
                l[i] = (int) ((unsigned int) outbuf[2 * i] << shift);
                r[i] = (int) ((unsigned int) outbuf[2 * i + 1] << shift);
            }
        }
        else {
            for (i = 0; i < out; ++i)
                l[i] = (int) ((unsigned int) outbuf[i] << shift);
            memset(r, 0, out * sizeof(int));
        }
    }
    else if (stereo == 2) {
        for (i = 0; i < out; ++i) {
            dest->s[0][i] = outbuf[2 * i];
            dest->s[1][i] = outbuf[2 * i + 1];
        }
    }
    else if (out > 0)
        memcpy(dest->s[0], outbuf, sizeof(short)*out);
    if(reader->hip->pinfo)
        hip_finish_pinfo(reader->hip);
#else
    out = -1;
#endif
    return out;
}

static
int set_input_num_channels(lame_t gfp, int num_channels)
{
    if (gfp) {
        if (-1 == lame_set_num_channels(gfp, num_channels)) {
            reader_error("Unsupported number of channels: %d\n", num_channels);
            return 0;
        }
    }
    return 1;
}

static
int set_input_samplerate(lame_t gfp, int input_samplerate)
{
    if (gfp) {
        int sr = frontend_config.reader.input_samplerate;
        if (sr == 0) sr = input_samplerate;
        if (-1 == lame_set_in_samplerate(gfp, sr)) {
            reader_error("Unsupported sample rate: %d\n", sr);
            return 0;
        }
    }
    return 1;
}

/**
 * @internal
 * @brief Returns the data size for the header of a decoded WAV file.
 *
 * Prints a message when there are no samples, and when the data is larger
 * than a WAV header can hold.
 *
 * @param frames           the number of samples per channel.
 * @param bytes_per_frame  the size of one sample of all channels, in bytes.
 * @return the size of the data in bytes. 0 when there are no samples, and
 *         @c WAV_DATA_SIZE_MAX when the data is larger.
 */
unsigned int
wav_data_size(double frames, int bytes_per_frame)
{
    if (frames <= 0) {
        reader_error("WAVE file contains 0 PCM samples\n");
        return 0;
    }
    if (frames > WAV_DATA_SIZE_MAX / bytes_per_frame) {
        reader_error("Very huge WAVE file, can't set filesize accordingly\n");
        return WAV_DATA_SIZE_MAX;
    }
    return (unsigned int) (frames * bytes_per_frame);
}

int
WriteWaveHeader(FILE * const fp, unsigned int pcmbytes, int freq, int channels, int bits)
{
    int     bytes = (bits + 7) / 8;

    /* quick and dirty, but documented */
    fwrite("RIFF", 1, 4, fp); /* label */
    write_32_bits_low_high(fp, pcmbytes + 44u - 8u); /* length in bytes without header */
    fwrite("WAVEfmt ", 2, 4, fp); /* 2 labels */
    write_32_bits_low_high(fp, 2 + 2 + 4 + 4 + 2 + 2); /* length of PCM format declaration area */
    write_16_bits_low_high(fp, 1); /* is PCM? */
    write_16_bits_low_high(fp, channels); /* number of channels */
    write_32_bits_low_high(fp, freq); /* sample frequency in [Hz] */
    write_32_bits_low_high(fp, (unsigned int) freq * (unsigned int) (channels * bytes)); /* bytes per second */
    write_16_bits_low_high(fp, channels * bytes); /* bytes per sample time */
    write_16_bits_low_high(fp, bits); /* bits per sample */
    fwrite("data", 1, 4, fp); /* label */
    write_32_bits_low_high(fp, pcmbytes); /* length in bytes of raw PCM data */

    return ferror(fp) ? -1 : 0;
}




#if defined(LIBSNDFILE)

extern SNDFILE *sf_wchar_open(wchar_t const *wpath, int mode, SF_INFO * sfinfo);

static SNDFILE *
open_snd_file(audio_reader * reader, lame_t gfp, char const *inPath)
{
    char const *lpszFileName = inPath;
    SNDFILE *gs_pSndFileIn = NULL;
    SF_INFO gs_wfInfo;

    {
#if defined( _WIN32 ) && !defined(__MINGW32__)
        wchar_t *file_name = utf8ToUnicode(lpszFileName);
#endif
        /* Try to open the sound file */
        memset(&gs_wfInfo, 0, sizeof(gs_wfInfo));
#if defined( _WIN32 ) && !defined(__MINGW32__)
        gs_pSndFileIn = sf_wchar_open(file_name, SFM_READ, &gs_wfInfo);
#else
        gs_pSndFileIn = sf_open(lpszFileName, SFM_READ, &gs_wfInfo);
#endif
        if (gs_pSndFileIn != NULL && frontend_config.reader.swapbytes) {
            reader_error("WARNING: libsndfile takes the byte order from the file's header;\n"
                         "-x applies only to raw input (-r)\n");
        }

        /* Only a caller who asked for headerless PCM gets it. libsndfile
           cannot recognise raw input, so -r is the only thing that can say
           the file is meant to be read that way; without it an unrecognised
           file is an unrecognised file, and LAME's own reader - which
           refuses it - gets its turn instead. */
        if (gs_pSndFileIn == NULL && frontend_config.reader.input_format == sf_raw) {
            if (frontend_config.raw_pcm.in_signed == 0
                && frontend_config.raw_pcm.in_bitwidth != 8) {
                error_printf("Unsigned input only supported with bitwidth 8\n");
#if defined( _WIN32 ) && !defined(__MINGW32__)
                free(file_name);
#endif
                return 0;
            }
            /* the defaults raw PCM is read with */
            gs_wfInfo.seekable = 0; /* raw input, so not seekable */
            gs_wfInfo.samplerate = lame_get_in_samplerate(gfp);
            gs_wfInfo.channels = lame_get_num_channels(gfp);
            gs_wfInfo.format = SF_FORMAT_RAW;
            if ((frontend_config.raw_pcm.in_endian == ByteOrderLittleEndian)
                ^ (frontend_config.reader.swapbytes != 0)) {
                gs_wfInfo.format |= SF_ENDIAN_LITTLE;
            }
            else {
                gs_wfInfo.format |= SF_ENDIAN_BIG;
            }
            switch (frontend_config.raw_pcm.in_bitwidth) {
            case 8:
                gs_wfInfo.format |=
                    frontend_config.raw_pcm.in_signed == 0 ? SF_FORMAT_PCM_U8 : SF_FORMAT_PCM_S8;
                break;
            case 16:
                gs_wfInfo.format |= SF_FORMAT_PCM_16;
                break;
            case 24:
                gs_wfInfo.format |= SF_FORMAT_PCM_24;
                break;
            case 32:
                gs_wfInfo.format |= SF_FORMAT_PCM_32;
                break;
            default:
                break;
            }
#if defined( _WIN32 ) && !defined(__MINGW32__)
            gs_pSndFileIn = sf_wchar_open(file_name, SFM_READ, &gs_wfInfo);
#else
            gs_pSndFileIn = sf_open(lpszFileName, SFM_READ, &gs_wfInfo);
#endif
        }
#if defined( _WIN32 ) && !defined(__MINGW32__)
        free(file_name);
#endif

        /* Check result */
        if (gs_pSndFileIn == NULL) {
            sf_perror(gs_pSndFileIn);
            reader_error("Could not open sound file \"%s\".\n", lpszFileName);
            return 0;
        }
        switch (gs_wfInfo.format & SF_FORMAT_SUBMASK) {
        case SF_FORMAT_FLOAT:
        case SF_FORMAT_DOUBLE:
            reader->pcm_is_ieee_float = 1;
            break;
        default:
            break;
        }

        if ((gs_wfInfo.format & SF_FORMAT_RAW) == SF_FORMAT_RAW) {
            frontend_config.reader.input_format = sf_raw;
        }

        if(gs_wfInfo.frames >= 0 && gs_wfInfo.frames < (sf_count_t)(unsigned)NUM_SAMPLES_UNKNOWN)
            (void) lame_set_num_samples(gfp, gs_wfInfo.frames);
        else
            (void) lame_set_num_samples(gfp, NUM_SAMPLES_UNKNOWN);
        if (!set_input_num_channels(gfp, gs_wfInfo.channels)) {
            sf_close(gs_pSndFileIn);
            return 0;
        }
        if (!set_input_samplerate(gfp, gs_wfInfo.samplerate)) {
            sf_close(gs_pSndFileIn);
            return 0;
        }
        reader->pcmbitwidth = 32;
    }
    return gs_pSndFileIn;
}

#endif /* defined(LIBSNDFILE) */



/** @internal @brief The widest integer PCM sample the reader takes, in bytes. */
#define PCM_MAX_SAMPLE_BYTES 4

/* One integer PCM sample at p, assembled into the high end of an int through
   unsigned shifts: a byte >= 0x80 shifted into the sign position would
   otherwise overflow the signed int. unsigned int has the same width as int,
   so every shift amount here stays below the width; the unsigned result
   converts back to the same two's-complement sample value on assignment.
   b is the width of an int in bits. */
#define PCM_S8(p)       (int) ((unsigned int) (p)[0] << (b - 8))
#define PCM_U8(p)       (int) ((unsigned int) ((p)[0] ^ 0x80) << (b - 8))
#define PCM_S16LE(p)    (int) ((unsigned int) (p)[0] << (b - 16) | (unsigned int) (p)[1] << (b - 8))
#define PCM_S16BE(p)    (int) ((unsigned int) (p)[0] << (b - 8) | (unsigned int) (p)[1] << (b - 16))
#define PCM_S24LE(p)    (int) ((unsigned int) (p)[0] << (b - 24) | (unsigned int) (p)[1] << (b - 16) \
                               | (unsigned int) (p)[2] << (b - 8))
#define PCM_S24BE(p)    (int) ((unsigned int) (p)[0] << (b - 8) | (unsigned int) (p)[1] << (b - 16) \
                               | (unsigned int) (p)[2] << (b - 24))
#define PCM_S32LE(p)    (int) ((unsigned int) (p)[0] << (b - 32) | (unsigned int) (p)[1] << (b - 24) \
                               | (unsigned int) (p)[2] << (b - 16) | (unsigned int) (p)[3] << (b - 8))
#define PCM_S32BE(p)    (int) ((unsigned int) (p)[0] << (b - 8) | (unsigned int) (p)[1] << (b - 16) \
                               | (unsigned int) (p)[2] << (b - 24) | (unsigned int) (p)[3] << (b - 32))

/* Converts the n sample frames in raw with SAMPLE into the channels out[0]
   and out[1]. */
#define PCM_SPLIT(SAMPLE)                                                   \
    do {                                                                    \
        unsigned char const *p_ = raw;                                      \
        int     k_;                                                         \
        if (num_channels == 2) {                                            \
            for (k_ = 0; k_ < n; ++k_, p_ += 2 * bytes) {                   \
                out[0][k_] = SAMPLE(p_);                                    \
                out[1][k_] = SAMPLE(p_ + bytes);                            \
            }                                                               \
        }                                                                   \
        else {                                                              \
            for (k_ = 0; k_ < n; ++k_, p_ += bytes)                         \
                out[0][k_] = SAMPLE(p_);                                    \
        }                                                                   \
    } while (0)

/**
 * @internal
 * @brief Reads the next frame of integer PCM through the C library and
 *        converts it into the two channels of @p dest.
 *
 * Every sample width (8, 16, 24 and 32 bits) and both byte orders go through
 * one pass from the file's bytes to the channels. Mono output gets a second
 * channel of zeros. Unsigned samples are taken with 8 bits only.
 *
 * @param reader           the reader of the input file.
 * @param dest             receives the samples as int, or as 16 bit for
 *                         @c --decode.
 * @param num_channels     the number of channels, 1 or 2.
 * @param samples_to_read  the samples per channel to read.
 * @return the number of samples per channel, or a negative value on an error.
 */
static int
read_samples_pcm(audio_reader * reader, frame_dest const *dest, int num_channels,
                 int samples_to_read)
{
    unsigned char raw[2 * FRAME_BUFFER_SAMPLES * PCM_MAX_SAMPLE_BYTES];
    int     narrow[2][FRAME_BUFFER_SAMPLES]; /* the int samples when dest takes 16 bit */
    int    *out[2];
    int const bytes = reader->pcmbitwidth / 8;
    int const b = 8 * (int) sizeof(int);
    int const items = num_channels * samples_to_read;
    int     other_form;         /* big endian; for 8 bits, unsigned */
    int     n;
    FILE   *musicin = reader->music_in;

    switch (reader->pcmbitwidth) {
    case 32:
    case 24:
    case 16:
        if (frontend_config.raw_pcm.in_signed == 0) {
            reader_error("Unsigned input only supported with bitwidth 8\n");
            return -1;
        }
        other_form = (frontend_config.raw_pcm.in_endian != ByteOrderLittleEndian) ? 1 : 0;
        if (reader->pcmswapbytes) {
            other_form = !other_form;
        }
        break;

    case 8:
        other_form = reader->pcm_is_unsigned_8bit;
        break;

    default:
        reader_error("Only 8, 16, 24 and 32 bit input files supported \n");
        return -1;
    }
    if (items < 0 || items > 2 * FRAME_BUFFER_SAMPLES) {
        reader_error("Error: unexpected number of samples to read: %d\n", items);
        return -1;
    }
    {
        size_t const got = fread(raw, (size_t) bytes, (size_t) items, musicin);
        assert(got <= (size_t) items);
        n = (int) got;
    }
    if (ferror(musicin)) {
        reader_error("Error reading input file\n");
        return -1;
    }
    n = whole_frame_samples(reader, n, num_channels) / num_channels;

    if (dest->i[0] != NULL) {
        out[0] = dest->i[0];
        out[1] = dest->i[1];
    }
    else {
        out[0] = narrow[0];
        out[1] = narrow[1];
    }
    if (bytes == 1) {
        if (other_form)
            PCM_SPLIT(PCM_U8);
        else
            PCM_SPLIT(PCM_S8);
    }
    else if (bytes == 2) {
        if (other_form)
            PCM_SPLIT(PCM_S16BE);
        else
            PCM_SPLIT(PCM_S16LE);
    }
    else if (bytes == 3) {
        if (other_form)
            PCM_SPLIT(PCM_S24BE);
        else
            PCM_SPLIT(PCM_S24LE);
    }
    else {
        if (other_form)
            PCM_SPLIT(PCM_S32BE);
        else
            PCM_SPLIT(PCM_S32LE);
    }
    if (num_channels == 1)
        memset(out[1], 0, n * sizeof(int));
    if (dest->i[0] == NULL) {
        int     ch, k;
        for (ch = 0; ch < 2; ++ch)
            for (k = 0; k < n; ++k)
                dest->s[ch][k] = (short) (out[ch][k] >> (b - 16));
    }
    return n;
}

#undef PCM_SPLIT
#undef PCM_S8
#undef PCM_U8
#undef PCM_S16LE
#undef PCM_S16BE
#undef PCM_S24LE
#undef PCM_S24BE
#undef PCM_S32LE
#undef PCM_S32BE


/**
 * @internal
 * @brief Reads 32 bit floating point samples, in the byte order of the host.
 *
 * The byte order of the file is decided in the same way as for integer
 * samples: little endian, unless the format or @c --swap-bytes says otherwise.
 * If it differs from the byte order of the host, the four bytes of each sample
 * are reversed.
 *
 * @param reader           the reader of the input file.
 * @param musicin          the input file.
 * @param sample_buffer    receives the samples, interleaved.
 * @param samples_to_read  the number of samples to read, at most 2304.
 * @return the number of samples read. A negative value on an error.
 */
static int
read_samples_float(audio_reader * reader, FILE * musicin,
                   float sample_buffer[2 * FRAME_BUFFER_SAMPLES],
                   int samples_to_read)
{
    compiletime_assert(sizeof(float) == 4);
    int     file_is_big_endian =
        (frontend_config.raw_pcm.in_endian != ByteOrderLittleEndian) ? 1 : 0;
    int     samples_read, i;

    if (reader->pcmswapbytes) {
        file_is_big_endian = !file_is_big_endian;
    }
    if (samples_to_read < 0 || samples_to_read > 2 * FRAME_BUFFER_SAMPLES) {
        reader_error("Error: unexpected number of samples to read: %d\n", samples_to_read);
        return -1;
    }
    samples_read = (int) fread(sample_buffer, 4, (size_t) samples_to_read, musicin);
    if (ferror(musicin)) {
        reader_error("Error reading input file\n");
        return -1;
    }
    if (file_is_big_endian != (machine_byte_order() == ByteOrderBigEndian)) {
        unsigned char *b = (unsigned char *) sample_buffer;
        for (i = 0; i < samples_read; ++i, b += 4) {
            unsigned char t = b[0];
            b[0] = b[3];
            b[3] = t;
            t = b[1];
            b[1] = b[2];
            b[2] = t;
        }
    }
    return samples_read;
}



/* AIFF Definitions */

static uint32_t const IFF_ID_FORM = 0x464f524d; /* "FORM" */
static uint32_t const IFF_ID_AIFF = 0x41494646; /* "AIFF" */
static uint32_t const IFF_ID_AIFC = 0x41494643; /* "AIFC" */
static uint32_t const IFF_ID_COMM = 0x434f4d4d; /* "COMM" */
static uint32_t const IFF_ID_SSND = 0x53534e44; /* "SSND" */

static uint32_t const IFF_ID_NONE = 0x4e4f4e45; /* "NONE" *//* AIFF-C data format */
static uint32_t const IFF_ID_2CBE = 0x74776f73; /* "twos" *//* AIFF-C data format */
static uint32_t const IFF_ID_2CLE = 0x736f7774; /* "sowt" *//* AIFF-C data format */
static uint32_t const IFF_ID_FL32 = 0x666C3332; /* "fl32" *//* AIFF-C data format */
static uint32_t const IFF_ID_FL64 = 0x666C3634; /* "fl64" *//* AIFF-C data format */

static uint32_t const WAV_ID_RIFF = 0x52494646; /* "RIFF" */
static uint32_t const WAV_ID_WAVE = 0x57415645; /* "WAVE" */
static uint32_t const WAV_ID_FMT = 0x666d7420; /* "fmt " */
static uint32_t const WAV_ID_DATA = 0x64617461; /* "data" */

#ifndef WAVE_FORMAT_PCM
static uint16_t const WAVE_FORMAT_PCM = 0x0001;
#endif
#ifndef WAVE_FORMAT_IEEE_FLOAT
static uint16_t const WAVE_FORMAT_IEEE_FLOAT = 0x0003;
#endif
#ifndef WAVE_FORMAT_EXTENSIBLE
static uint16_t const WAVE_FORMAT_EXTENSIBLE = 0xFFFE;
#endif
#ifndef WAVE_FORMAT_MPEG
static uint16_t const WAVE_FORMAT_MPEG = 0x0050;
#endif
#ifndef WAVE_FORMAT_MPEGLAYER3
static uint16_t const WAVE_FORMAT_MPEGLAYER3 = 0x0055;
#endif

/** The number of chunks the WAV reader reads at most to find the data chunk. */
#define WAV_MAX_CHUNKS 20


static uint32_t
make_even_number_of_bytes_in_length(uint32_t x)
{
    return x + (x & 0x01);
}

/**
 * @internal
 * @brief Reads the size field of a chunk, and rounds the size up to an even
 *        number of bytes.
 *
 * @param sf          the input file, at the size field.
 * @param big_endian  1 for an AIFF file, 0 for a WAV file.
 * @param size        receives the size of the chunk body, padding included.
 * @return 0, or -1 when the field cannot be read.
 */
static int
read_chunk_size(FILE * sf, int big_endian, uint32_t * size)
{
    if (big_endian ? read_32_bits_high_low(sf, size) : read_32_bits_low_high(sf, size))
        return -1;
    *size = make_even_number_of_bytes_in_length(*size);
    return 0;
}

/**
 * @internal
 * @brief Takes the size field and the body of an AIFF chunk from the bytes of
 *        the FORM chunk that are left.
 *
 * @param remaining  the bytes left in the FORM chunk, at least 4.
 * @param size       the size of the chunk body, padding included.
 * @param min_size   the smallest body this chunk type can have.
 * @return 0, or -1 when the body is too small or does not fit.
 */
static int
take_chunk(uint32_t * remaining, uint32_t size, uint32_t min_size)
{
    *remaining -= 4;
    if (size < min_size || *remaining < size)
        return -1;
    *remaining -= size;
    return 0;
}


/*****************************************************************************
 *
 *	Read Microsoft Wave headers
 *
 *	By the time we get here the first 32-bits of the file have already been
 *	read, and we're pretty sure that we're looking at a WAV file.
 *
 *****************************************************************************/

static int
parse_wave_header(audio_reader * reader, lame_global_flags * gfp, FILE * sf)
{
    uint32_t ui32_nSamplesPerSec = 0;
    uint32_t ui32_DataChunkSize = 0;
    uint16_t ui16_wFormatTag = 0;
    uint16_t ui16_nChannels = 0;
    uint16_t ui16_wBitsPerSample = 0;

    int     is_wav = 0;
    int     loop_sanity = 0;

    uint32_t ui32_chunkSize = 0; /* file_length */
    uint32_t ui32_WAVEID    = 0;
    if (read_32_bits_high_low(sf, &ui32_chunkSize)
        || read_32_bits_high_low(sf, &ui32_WAVEID))
        return -1;
    if (ui32_WAVEID != WAV_ID_WAVE || ui32_chunkSize < 1)
        return -1;

    for (loop_sanity = 0; loop_sanity < WAV_MAX_CHUNKS; ++loop_sanity) {
        uint32_t ui32_ckID = 0;
        if (read_32_bits_high_low(sf, &ui32_ckID))
            return -1;
        if (ui32_ckID == WAV_ID_FMT) {
            uint32_t ui32_nAvgBytesPerSec = 0;
            uint32_t ui32_cksize = 0;
            uint16_t ui16_nBlockAlign = 0;

            if (read_chunk_size(sf, 0, &ui32_cksize))
                return -1;
            if (ui32_cksize < 16u) {
                /*DEBUGF("'fmt' chunk too short (only %ld bytes)!", ui32_cksize);*/
                return -1;
            }
            if (read_16_bits_low_high(sf, &ui16_wFormatTag)
                || read_16_bits_low_high(sf, &ui16_nChannels)
                || read_32_bits_low_high(sf, &ui32_nSamplesPerSec)
                || read_32_bits_low_high(sf, &ui32_nAvgBytesPerSec)
                || read_16_bits_low_high(sf, &ui16_nBlockAlign)
                || read_16_bits_low_high(sf, &ui16_wBitsPerSample))
                return -1;
            /* The block alignment and the byte rate only restate what the
               other fields already say, so they are cross-checked rather
               than used: writers get them wrong often enough that a
               mismatch must not cost the user the file. */
            if (frontend_config.ui_config.silent < 0
                && ui16_nChannels > 0 && ui16_wBitsPerSample > 0) {
                uint32_t const align = pcm_bytes_per_frame(ui16_nChannels, ui16_wBitsPerSample);
                if (ui16_nBlockAlign != align)
                    error_printf("Note: block alignment is %u, expected %u\n",
                                 (unsigned int) ui16_nBlockAlign, (unsigned int) align);
                if (ui32_nAvgBytesPerSec != ui32_nSamplesPerSec * align)
                    error_printf("Note: byte rate is %u, expected %u\n",
                                 (unsigned int) ui32_nAvgBytesPerSec,
                                 (unsigned int) (ui32_nSamplesPerSec * align));
            }
            ui32_cksize -= 16u;
            /* WAVE_FORMAT_EXTENSIBLE support */
            if ((ui32_cksize > 9u) && (ui16_wFormatTag == WAVE_FORMAT_EXTENSIBLE)) {
                uint16_t ui16_cbSize              = 0;
                uint16_t ui16_wValidBitsPerSample = 0;
                uint16_t ui16_SubFormat           = 0;
                if (read_16_bits_low_high(sf, &ui16_cbSize)
                    || read_16_bits_low_high(sf, &ui16_wValidBitsPerSample)
                    /* the channel mask only names the speakers; zero means
                       unspecified and nothing here depends on it */
                    || fskip_uint32(sf, 4u) != 0
                    || read_16_bits_low_high(sf, &ui16_SubFormat))
                    return -1;
                /* An extensible header describes a 22 byte extension and
                   cannot carry more valid bits than the sample holds. */
                if (ui16_cbSize < 22u)
                    return -1;
                if (ui16_wValidBitsPerSample == 0
                    || ui16_wValidBitsPerSample > ui16_wBitsPerSample)
                    return -1;
                ui32_cksize -= 10u;
                ui16_wFormatTag = ui16_SubFormat; /* SubType coincident with format_tag for PCM int or float */
            }
            /* DEBUGF("   skipping %d bytes\n", ui32_cksize); */
            if (ui32_cksize > 0) {
                if (fskip_uint32(sf, ui32_cksize) != 0)
                    return -1;
            };
        }
        else if (ui32_ckID == WAV_ID_DATA) {
            if (read_32_bits_low_high(sf, &ui32_DataChunkSize))
                return -1;
            is_wav = 1;
            /* We've found the audio data. Read no further! */
            break;
        }
        else {
            uint32_t ui32_cksize = 0;
            if (read_chunk_size(sf, 0, &ui32_cksize))
                return -1;
            if (fskip_uint32(sf, ui32_cksize) != 0) {
                return -1;
            }
        }
    }
    if (is_wav) {
        if (ui16_wFormatTag == WAVE_FORMAT_MPEG || ui16_wFormatTag == WAVE_FORMAT_MPEGLAYER3) {
            return sf_mp123;
        }
        if (ui16_wFormatTag != WAVE_FORMAT_PCM && ui16_wFormatTag != WAVE_FORMAT_IEEE_FLOAT) {
            reader_error("Unsupported data format: 0x%04X\n", ui16_wFormatTag);
            return 0;   /* oh no! non-supported format  */
        }

        /* make sure the header is sane */
        if (!set_input_num_channels(gfp, ui16_nChannels))
            return 0;
        /* The header carries the rate as 32 unsigned bits and the encoder
           takes it as an int, so the upper half of that range cannot be
           passed on at all. Refuse it here, while the declared value is
           still intact: converting first and letting the "not below 1"
           check catch the result reports a negative rate that appears
           nowhere in the file. */
        if (ui32_nSamplesPerSec > (uint32_t) INT_MAX) {
            reader_error("Unsupported sample rate: %u\n",
                         (unsigned int) ui32_nSamplesPerSec);
            return -1;
        }
        if (!set_input_samplerate(gfp, (int) ui32_nSamplesPerSec))
            return 0;
        /* The reader unpacks 8, 16, 24 and 32 bit integer samples, and reads
           floating point ones as 32 bit; no other width can be turned into
           audio. Deciding that here rather than at the first read names the
           field that is wrong while the header is still in view, and it keeps
           a floating point file of some other width from being unpacked as
           integers and then reinterpreted as floats, which produces noise
           rather than an error. The sibling AIFF reader has enumerated its
           accepted widths all along. */
        {
            int     width_ok;

            if (ui16_wFormatTag == WAVE_FORMAT_IEEE_FLOAT)
                width_ok = (ui16_wBitsPerSample == 32);
            else
                width_ok = pcm_int_width_supported(ui16_wBitsPerSample);
            if (!width_ok) {
                reader_error("Unsupported bits per sample: %d\n", ui16_wBitsPerSample);
                return -1;
            }
        }
        reader->pcmbitwidth = ui16_wBitsPerSample;
        reader->pcm_is_unsigned_8bit = 1;
        reader->pcm_is_ieee_float = (ui16_wFormatTag == WAVE_FORMAT_IEEE_FLOAT ? 1 : 0);
        if (ui32_DataChunkSize == NUM_SAMPLES_UNKNOWN)
            (void) lame_set_num_samples(gfp, NUM_SAMPLES_UNKNOWN);
        else
            (void) lame_set_num_samples(gfp, ui32_DataChunkSize / pcm_bytes_per_frame(ui16_nChannels, ui16_wBitsPerSample));
        return 1;
    }
    return -1;
}



/************************************************************************
* aiff_check2
*
* PURPOSE:	Checks AIFF header information to make sure it is valid.
*	        returns 0 on success, 1 on errors
************************************************************************/

static int
aiff_check2(IFF_AIFF * const pcm_aiff_data)
{
    if (pcm_aiff_data->sampleType != IFF_ID_SSND) {
        reader_error("ERROR: input sound data is not PCM\n");
        return 1;
    }
    if (!pcm_int_width_supported(pcm_aiff_data->sampleSize)) {
        reader_error("ERROR: input sound data is not 8, 16, 24 or 32 bits\n");
        return 1;
    }
    if (pcm_aiff_data->numChannels != 1 && pcm_aiff_data->numChannels != 2) {
        reader_error("ERROR: input sound data is not mono or stereo\n");
        return 1;
    }
    if (pcm_aiff_data->blkAlgn.blockSize != 0) {
        reader_error("ERROR: block size of input sound data is not 0 bytes\n");
        return 1;
    }
    /* A bug, since we correctly skip the offset earlier in the code.
       if (pcm_aiff_data->blkAlgn.offset != 0) {
       error_printf("Block offset is not 0 bytes in '%s'\n", file_name);
       return 1;
       } */

    return 0;
}


/*****************************************************************************
 *
 *	Read Audio Interchange File Format (AIFF) headers.
 *
 *	By the time we get here the first 32 bits of the file have already been
 *	read, and we're pretty sure that we're looking at an AIFF file.
 *
 *****************************************************************************/

static int
parse_aiff_header(audio_reader * reader, lame_global_flags * gfp, FILE * sf)
{
    uint32_t  ui32_ChunkSize = 0;
    uint32_t  ui32_TypeID = 0;
    IFF_AIFF aiff_info;
    int     seen_comm_chunk = 0, seen_ssnd_chunk = 0;
    long    pcm_data_pos = -1;

    memset(&aiff_info, 0, sizeof(aiff_info));
    aiff_info.sampleFormat = IFF_ID_NONE;
    if (read_32_bits_high_low(sf, &ui32_ChunkSize)
        || read_32_bits_high_low(sf, &ui32_TypeID))
        return -1;
    if (ui32_ChunkSize < 4)     /* malformed FORM size: guard the -= 4 underflow */
        return -1;
    ui32_ChunkSize -= 4;
    if ((ui32_TypeID != IFF_ID_AIFF) && (ui32_TypeID != IFF_ID_AIFC))
        return -1;

    while (ui32_ChunkSize >= 8) {
        uint32_t ui32_type = 0;
        if (read_32_bits_high_low(sf, &ui32_type))
            return -1;
        ui32_ChunkSize -= 4;

        /* DEBUGF(
           "found chunk type %08x '%4.4s'\n", ui32_type, (char*)&ui32_type); */

        /* don't use a switch here to make it easier to use 'break' for SSND */
        if (ui32_type == IFF_ID_COMM) {
            uint32_t ui32_cksize = 0;
            uint16_t ui16_numChannels = 0, ui16_sampleSize = 0;
            uint32_t ui32_numSampleFrames = 0;

            if (read_chunk_size(sf, 1, &ui32_cksize)
                || take_chunk(&ui32_ChunkSize, ui32_cksize, 18))
                return -1;
            seen_comm_chunk = seen_ssnd_chunk + 1;

            if (read_16_bits_high_low(sf, &ui16_numChannels)
                || read_32_bits_high_low(sf, &ui32_numSampleFrames)
                || read_16_bits_high_low(sf, &ui16_sampleSize)
                || read_ieee_extended_high_low(sf, &aiff_info.sampleRate))
                return -1;
            /* The rate reaches lame as an int below, and a value outside that
               range has no defined conversion - including the infinity an
               all-ones exponent decodes to. INT_MAX is exact as a double on
               any target with an int of 53 bits or fewer. */
            if (!(aiff_info.sampleRate >= 1
                  && aiff_info.sampleRate <= (double) INT_MAX))
                return -1;
            aiff_info.numChannels = (short) ui16_numChannels;
            aiff_info.numSampleFrames = ui32_numSampleFrames;
            aiff_info.sampleSize = (short) ui16_sampleSize;
            ui32_cksize -= 18;
            if (ui32_TypeID == IFF_ID_AIFC) {
                if (ui32_cksize < 4)
                    return -1;
                if (read_32_bits_high_low(sf, &aiff_info.sampleFormat))
                    return -1;
                ui32_cksize -= 4;
            }
            if (fskip_uint32(sf, ui32_cksize) != 0)
                return -1;
        }
        else if (ui32_type == IFF_ID_SSND) {
            uint32_t ui32_cksize = 0;
            if (read_chunk_size(sf, 1, &ui32_cksize)
                || take_chunk(&ui32_ChunkSize, ui32_cksize, 8))
                return -1;
            seen_ssnd_chunk = 1;

            aiff_info.sampleType = IFF_ID_SSND;
            if (read_32_bits_high_low(sf, &aiff_info.blkAlgn.offset)
                || read_32_bits_high_low(sf, &aiff_info.blkAlgn.blockSize))
                return -1;
            ui32_cksize -= 8;
            if (seen_comm_chunk > 0) {
                if (fskip_uint32(sf, aiff_info.blkAlgn.offset) != 0)
                    return -1;
                /* We've found the audio data. Read no further! */
                break;
            }
            pcm_data_pos = ftell(sf);
            if (pcm_data_pos >= 0) {
                pcm_data_pos += aiff_info.blkAlgn.offset;
            }
            if (fskip_uint32(sf, ui32_cksize) != 0)
                return -1;
        }
        else {
            uint32_t ui32_cksize = 0;
            if (read_chunk_size(sf, 1, &ui32_cksize)
                || take_chunk(&ui32_ChunkSize, ui32_cksize, 0))
                return -1;
            if (fskip_uint32(sf, ui32_cksize) != 0)
                return -1;
        }
    }
    if (aiff_info.sampleFormat == IFF_ID_2CLE) {
        reader->pcm_is_ieee_float = 0;
        reader->pcmswapbytes = frontend_config.reader.swapbytes;
    }
    else if (aiff_info.sampleFormat == IFF_ID_2CBE) {
        reader->pcm_is_ieee_float = 0;
        reader->pcmswapbytes = !frontend_config.reader.swapbytes;
    }
    else if (aiff_info.sampleFormat == IFF_ID_NONE) {
        reader->pcm_is_ieee_float = 0;
        reader->pcmswapbytes = !frontend_config.reader.swapbytes;
    }
    else if (aiff_info.sampleFormat == IFF_ID_FL32) {
        reader->pcm_is_ieee_float = 1;
        reader->pcmswapbytes = !frontend_config.reader.swapbytes;
    }
    else if (aiff_info.sampleFormat == IFF_ID_FL64) {
        /* reading 64 bit floating point samples is not implemented */
        reader_error("Unsupported data format: 64 bit floating point\n");
        return -1;
    }
    else {
        return -1;
    }

    /* DEBUGF("Parsed AIFF %d\n", is_aiff); */
    if (seen_comm_chunk && (seen_ssnd_chunk > 0 || aiff_info.numSampleFrames == 0)) {
        /* make sure the header is sane */
        if (0 != aiff_check2(&aiff_info))
            return 0;
        if (!set_input_num_channels(gfp, aiff_info.numChannels))
            return 0;
        if (!set_input_samplerate(gfp, (int) aiff_info.sampleRate))
            return 0;
        (void) lame_set_num_samples(gfp, aiff_info.numSampleFrames);
        reader->pcmbitwidth = aiff_info.sampleSize;
        reader->pcm_is_unsigned_8bit = 0;
        if (pcm_data_pos >= 0) {
            if (fseek(sf, pcm_data_pos, SEEK_SET) != 0) {
                reader_error("Can't rewind stream to audio data position\n");
                return 0;
            }
        }

        return 1;
    }
    return -1;
}



/************************************************************************
*
* parse_file_header
*
* PURPOSE: Read the header from a bytestream.  Try to determine whether
*          it's a WAV file or AIFF without rewinding, since rewind
*          doesn't work on pipes and there's a good chance we're reading
*          from stdin (otherwise we'd probably be using libsndfile).
*
* When this function returns, the file offset will be positioned at the
* beginning of the sound data.
*
************************************************************************/

static int
parse_file_header(audio_reader * reader, lame_global_flags * gfp, FILE * sf)
{
    uint32_t ui32_type = 0;
    /*
       DEBUGF(
       "First word of input stream: %08x '%4.4s'\n", ui32_type, (char*) &type);
     */
    reader->count_samples_carefully = 0;
    reader->pcm_is_unsigned_8bit = frontend_config.raw_pcm.in_signed == 1 ? 0 : 1;
    /*frontend_config.reader.input_format = sf_raw; commented out, because it is better to fail
       here as to encode some hundreds of input files not supported by LAME
       If you know you have RAW PCM data, use the -r switch
     */

    if (read_32_bits_high_low(sf, &ui32_type) != 0) {
        /* not even the four identifying bytes are present */
        reader_error("Warning: unsupported audio format\n");
        return sf_unknown;
    }

    if (ui32_type == WAV_ID_RIFF) {
        /* It's probably a WAV file */
        int const ret = parse_wave_header(reader, gfp, sf);
        if (ret == sf_mp123) {
            reader->count_samples_carefully = 1;
            return sf_mp123;
        }
        if (ret > 0) {
            if (lame_get_num_samples(gfp) == NUM_SAMPLES_UNKNOWN
                || frontend_config.reader.ignorewavlength == 1)
            {
                reader->count_samples_carefully = 0;
                lame_set_num_samples(gfp, NUM_SAMPLES_UNKNOWN);
            }
            else
                reader->count_samples_carefully = 1;
            return sf_wave;
        }
        if (ret < 0) {
            reader_error("Warning: corrupt or unsupported WAVE format\n");
        }
    }
    else if (ui32_type == IFF_ID_FORM) {
        /* It's probably an AIFF file */
        int const ret = parse_aiff_header(reader, gfp, sf);
        if (ret > 0) {
            reader->count_samples_carefully = 1;
            return sf_aiff;
        }
        if (ret < 0) {
            reader_error("Warning: corrupt or unsupported AIFF format\n");
        }
    }
    else {
        reader_error("Warning: unsupported audio format\n");
    }
    return sf_unknown;
}


static int
open_mpeg_file_part2(LAME_UNUSED audio_reader * reader, lame_t gfp, LAME_UNUSED FILE * musicin,
                     LAME_UNUSED char const *inPath,
                     LAME_UNUSED int *enc_delay, LAME_UNUSED int *enc_padding)
{
#ifdef HAVE_MPG123
    if (-1 == lame123_decode_initfile(reader, musicin, &frontend_config.decoder.mp3input_data,
                                      enc_delay, enc_padding)) {
        reader_error("Error opening MPEG input file %s.\n", inPath);
        return 0;
    }
#endif
    if (!set_input_num_channels(gfp, frontend_config.decoder.mp3input_data.stereo)) {
        return 0;
    }
    if (!set_input_samplerate(gfp, frontend_config.decoder.mp3input_data.samplerate)) {
        return 0;
    }
    (void) lame_set_num_samples(gfp, frontend_config.decoder.mp3input_data.nsamp);
    return 1;
}


/** @internal @brief The size of the stdio buffer an input file is read through. */
#define INPUT_BUFFER_BYTES (64 * 1024)

/**
 * @internal
 * @brief Gives a file the reader opened a larger stdio buffer.
 *
 * It must be called before the first read. The buffer belongs to the reader,
 * which frees it after the file is closed. Without memory for it, the file
 * keeps the C library's buffer.
 *
 * @param reader   the reader of the input file.
 * @param musicin  the file, just opened; not standard input, which stays
 *                 open after the reader is closed.
 */
static void
set_input_buffer(audio_reader * reader, FILE * musicin)
{
    reader->in_buffer = malloc(INPUT_BUFFER_BYTES);
    if (reader->in_buffer != NULL
        && setvbuf(musicin, (char *) reader->in_buffer, _IOFBF, INPUT_BUFFER_BYTES) != 0) {
        free(reader->in_buffer);
        reader->in_buffer = NULL;
    }
}

static FILE *
open_wave_file(audio_reader * reader, lame_t gfp, char const *inPath, int *enc_delay,
               int *enc_padding)
{
    FILE   *musicin;

    /* set the defaults from info incase we cannot determine them from file */
    lame_set_num_samples(gfp, NUM_SAMPLES_UNKNOWN);

    if (!strcmp(inPath, "-")) {
        lame_set_stream_binary_mode(musicin = stdin); /* Read from standard input. */
    }
    else {
        if ((musicin = lame_fopen(inPath, "rb")) == NULL) {
            reader_error("Could not find \"%s\".\n", inPath);
            return 0;
        }
        set_input_buffer(reader, musicin);
    }

    if (frontend_config.reader.input_format == sf_ogg) {
        reader_error("sorry, vorbis support in LAME is deprecated.\n");
        close_input_file(musicin);
        return 0;
    }
    else if (frontend_config.reader.input_format == sf_raw) {
        /* assume raw PCM */
        if (frontend_config.ui_config.silent < 9) {
            console_printf("Assuming raw pcm input file");
            if (frontend_config.reader.swapbytes)
                console_printf(" : Forcing byte-swapping\n");
            else
                console_printf("\n");
        }
        reader->pcmswapbytes = frontend_config.reader.swapbytes;
    }
    else {
        frontend_config.reader.input_format = parse_file_header(reader, gfp, musicin);
    }
    if (frontend_config.reader.input_format == sf_mp123) {
        if (open_mpeg_file_part2(reader, gfp, musicin, inPath, enc_delay, enc_padding))
            return musicin;
        close_input_file(musicin);
        return 0;
    }
    if (frontend_config.reader.input_format == sf_unknown) {
        /* The input type comes from the file name or an input option, and
           standard input has no name. */
        if (lame_get_decode_only(gfp))
            reader_error("To decode an MP3 from standard input, or from a file whose name does\n"
                         "not end in .mp3, give --mp3input (--mp2input or --mp1input for\n"
                         "layer II or layer I).\n");
        close_input_file(musicin);
        return 0;
    }

    if (lame_get_num_samples(gfp) == NUM_SAMPLES_UNKNOWN && musicin != stdin) {
        int const tmp_num_channels = lame_get_num_channels(gfp);
        double const flen = lame_get_file_size(musicin); /* try to figure out num_samples */
        if (flen >= 0 && tmp_num_channels > 0 ) {
            /* try file size, assume 2 bytes per sample */
            unsigned long fsize = (unsigned long) (flen / (2 * tmp_num_channels));
            (void) lame_set_num_samples(gfp, fsize);
            reader->count_samples_carefully = 0;
        }
    }
    return musicin;
}



static FILE *
open_mpeg_file(audio_reader * reader, lame_t gfp, char const *inPath, int *enc_delay,
               int *enc_padding)
{
    FILE   *musicin;

    /* set the defaults from info incase we cannot determine them from file */
    lame_set_num_samples(gfp, NUM_SAMPLES_UNKNOWN);

    if (strcmp(inPath, "-") == 0) {
        musicin = stdin;
        lame_set_stream_binary_mode(musicin); /* Read from standard input. */
    }
    else {
        musicin = lame_fopen(inPath, "rb");
        if (musicin == NULL) {
            reader_error("Could not find \"%s\".\n", inPath);
            return 0;
        }
    }
    if ( 0 == open_mpeg_file_part2(reader, gfp, musicin, inPath, enc_delay, enc_padding) ) {
        close_input_file(musicin);
        return 0;
    }
    if (lame_get_num_samples(gfp) == NUM_SAMPLES_UNKNOWN && musicin != stdin) {
        double  flen = lame_get_file_size(musicin); /* try to figure out num_samples */
        if (flen >= 0) {
            /* try file size, assume 2 bytes per sample */
            if (frontend_config.decoder.mp3input_data.bitrate > 0) {
                double  totalseconds =
                    (flen * 8.0 / (1000.0 * frontend_config.decoder.mp3input_data.bitrate));
                unsigned long tmp_num_samples =
                    (unsigned long) (totalseconds * lame_get_in_samplerate(gfp));

                (void) lame_set_num_samples(gfp, tmp_num_samples);
                frontend_config.decoder.mp3input_data.nsamp = tmp_num_samples;
                reader->count_samples_carefully = 0;
            }
        }
    }
    return musicin;
}


static int
close_input_file(FILE * musicin)
{
    int     ret = 0;

    if (musicin != stdin && musicin != 0) {
        ret = fclose(musicin);
    }
    if (ret != 0) {
        reader_error("Could not close audio input file\n");
    }
    return ret;
}

#ifdef HAVE_MPG123
#define CHECK123(code) if(MPG123_OK != (code)) return -1

#ifdef _WIN32
static mpg123_ssize_t lame123_read_from_file(void* handle, void* buffer, size_t size)
{
   return fread(buffer, 1, size, (FILE*)handle);
}

static off_t lame123_seek_in_file(void* handle, off_t offset, int direction)
{
   HANDLE const os_handle =
       (HANDLE) _get_osfhandle(_fileno((FILE*) handle));

   /* fseek() has undefined behavior for non-seeking Windows devices. */
   if (os_handle == INVALID_HANDLE_VALUE ||
       GetFileType(os_handle) != FILE_TYPE_DISK)
      return (off_t)-1;
   if (fseek((FILE*)handle, offset, direction) != 0)
      return (off_t)-1;
   return ftell((FILE*)handle);
}

static void lame123_cleanup_file(LAME_UNUSED void* handle)
{
   /* don't call fclose(); close_input_file() will do that */
}
#endif

int lame123_decode_initfile(audio_reader * reader, FILE *fd, mp3data_struct *mp3data, int *enc_delay,
                            int *enc_padding)
{
    off_t len;
    unsigned char *id3buf;
    size_t id3size;
    struct mpg123_frameinfo fi;
    long rate, val;
    int channels;

    mpg123_init();
    memset(mp3data, 0, sizeof(mp3data_struct));
    if (reader->hip) {
        hip_decode_exit(reader->hip);
    }
    reader->hip = hip_decode_init();
    if(!reader->hip || !reader->hip->mh)
        return -1;
    /* TODO: enforce float format ... optionally be careful for builds
       that only know 16 bit output. */
    mpg123_param(reader->hip->mh, MPG123_ADD_FLAGS, MPG123_STORE_RAW_ID3, 0.);
    mpg123_param(reader->hip->mh, MPG123_ADD_FLAGS, MPG123_QUIET, 0.);
    mpg123_format_none(reader->hip->mh);
    /* TODO: switch to MPG123_ENC_FLOAT_32, always! */
    CHECK123(mpg123_format2(reader->hip->mh,
        0, MPG123_MONO|MPG123_STEREO, MPG123_ENC_SIGNED_16));
    /* TODO: verboseness / silence set up */
#ifdef _WIN32
    /* On Win32 compiles it can happen that lame.exe and libmp3lame.dll use
       different C++ runtimes, which maintail different FILE* lists, and
       fileno() would produce invalid file numbers for those msvcrt instances.
       So use mpg123_replace_reader_handle() / mpg123_open_handle() here
       instead of mpg123_open_fd(). */
    CHECK123(mpg123_replace_reader_handle(reader->hip->mh, lame123_read_from_file, lame123_seek_in_file, lame123_cleanup_file));
    CHECK123(mpg123_open_handle(reader->hip->mh, fd));
#else
    CHECK123(mpg123_open_fd(reader->hip->mh, fileno(fd)));
#endif
    /* Seek to get past Info frame and ID3v2. */
    CHECK123(mpg123_seek(reader->hip->mh, SEEK_SET, 0));
    /* TODO: Figure out if MPG123_GAPLESS is desired or not. */
    /* Guessing seems to be OK, so we do not have to insist on knowing
       if libmpg123 got that info from Info tag or not. */
    /* A negative length means that libmpg123 does not know it, as for a
       stream without an Info tag read from a pipe. */
    len = mpg123_framelength(reader->hip->mh);
    if (len < 0)
        mp3data->totalframes = 0;
    else if (len <= INT_MAX)
        mp3data->totalframes = (int)len;
    else
        return -1;
    len = mpg123_length(reader->hip->mh);
    if (len < 0)
        mp3data->nsamp = NUM_SAMPLES_UNKNOWN;
    else if (len <= INT_MAX)
        mp3data->nsamp = len;
    else
        return -1;
    /* Encoder delay and padding are not needed when libmpg123 handles gapless
       decoding itself. So let's see if we get away with that. */
    mpg123_getstate(reader->hip->mh, MPG123_ENC_DELAY, &val, NULL);
    *enc_delay = (int)val;
    mpg123_getstate(reader->hip->mh, MPG123_ENC_PADDING, &val, NULL);
    *enc_padding = (int)val;
    if(reader->in_id3v2_tag)
        free(reader->in_id3v2_tag);
    reader->in_id3v2_size = 0;
    if( MPG123_OK == mpg123_id3_raw(reader->hip->mh, NULL, NULL,
        &id3buf, &id3size) && id3buf && id3size ) {
        reader->in_id3v2_tag = malloc(id3size);
        if(reader->in_id3v2_tag) {
            memcpy(reader->in_id3v2_tag, id3buf, id3size);
            reader->in_id3v2_size = id3size;
        }
    }
    CHECK123(mpg123_info(reader->hip->mh, &fi));
    CHECK123(mpg123_getformat(reader->hip->mh, &rate, &channels, NULL));
    /* How much of this is actually needed for the frontend? */
    mp3data->header_parsed = 1;
    mp3data->stereo = channels; /* Channel count correct? Or is dual mono different? */
    mp3data->samplerate = (int)rate;
    mp3data->mode = fi.mode;
    mp3data->mode_ext = fi.mode_ext;
    mp3data->framesize = mpg123_spf(reader->hip->mh);
    mp3data->bitrate = fi.bitrate;
    if(frontend_config.reader.input_format == sf_mp123) switch(fi.layer) {
        case 1:
            frontend_config.reader.input_format = sf_mp1;
        break;
        case 2:
            frontend_config.reader.input_format = sf_mp2;
        break;
        case 3:
            frontend_config.reader.input_format = sf_mp3;
        break;
    }

    return 0;
}
#endif

int
is_mpeg_file_format(int input_file_format)
{
    switch (input_file_format) {
    case sf_mp1:
        return 1;
    case sf_mp2:
        return 2;
    case sf_mp3:
        return 3;
    case sf_mp123:
        return -1;
    default:
        break;
    }
    return 0;
}


/**
 * @internal
 * @brief Writes decoded 16-bit samples to the output file.
 *
 * Two channels are written interleaved. A WAV file is little endian. Raw
 * output (-t) is little endian, or big endian with -x.
 *
 * @param outf    the output file.
 * @param Buffer  the samples of the first and the second channel.
 * @param iread   the number of samples per channel.
 * @param nch     the number of channels, 1 or 2.
 * @return 0, or -1 when the write or the flush fails.
 */
int
put_audio16(FILE * outf, short Buffer[2][FRAME_BUFFER_SAMPLES], int iread, int nch)
{
    unsigned short data[2 * FRAME_BUFFER_SAMPLES];
    enum ByteOrder const out_order =
        (frontend_config.decoder.disable_wav_header && frontend_config.decoder.swapbytes)
        ? ByteOrderBigEndian : ByteOrderLittleEndian;
    int const count = nch == 1 ? iread : 2 * iread;
    int     i;

    if (nch == 1) {
        for (i = 0; i < iread; i++) {
            data[i] = (unsigned short) Buffer[0][i];
        }
    }
    else {
        for (i = 0; i < iread; i++) {
            data[2 * i] = (unsigned short) Buffer[0][i];
            data[2 * i + 1] = (unsigned short) Buffer[1][i];
        }
    }
    if (out_order != machine_byte_order()) {
        for (i = 0; i < count; i++) {
            data[i] = (unsigned short) ((data[i] << 8) | (data[i] >> 8));
        }
    }
    if (count > 0) {
        if (fwrite(data, sizeof(data[0]), (size_t) count, outf) != (size_t) count)
            return -1;
    }
    if (frontend_config.writer.flush_write == 1) {
        if (fflush(outf) != 0)
            return -1;
    }
    return 0;
}

hip_t
get_hip(audio_reader const * reader)
{
    return reader->hip;
}

size_t
sizeOfOldTag(audio_reader const * reader)
{
    return reader->in_id3v2_size;
}

unsigned char*
getOldTag(audio_reader const * reader)
{
    return reader->in_id3v2_tag;
}

/* end of get_audio.c */
