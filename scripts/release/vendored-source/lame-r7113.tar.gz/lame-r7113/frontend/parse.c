/*
 *      Command line parsing related functions
 *
 *      Copyright (c) 1999 Mark Taylor
 *                    2000-2017 Robert Hegemann
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 */

/* $Id$ */

#ifdef HAVE_CONFIG_H
# include <config.h>
#endif

#include <assert.h>
#include <ctype.h>
#include <math.h>
 
#ifdef STDC_HEADERS
# include <stdio.h>
# include <stdlib.h>
# include <string.h>
#else
# ifndef HAVE_STRCHR
#  define strchr index
#  define strrchr rindex
# endif
char   *strchr(), *strrchr();
# ifndef HAVE_MEMCPY
#  define memcpy(d, s, n) bcopy ((s), (d), (n))
#  define memmove(d, s, n) bcopy ((s), (d), (n))
# endif
#endif


#ifdef HAVE_LIMITS_H
# include <limits.h>
#endif

#include "lame.h"
#include "machine.h"

#include "parse.h"
#include "main.h"
#include "get_audio.h"
#include "version.h"
#include "console.h"

#undef dimension_of
#define dimension_of(array) (sizeof(array)/sizeof(array[0]))

#ifdef WITH_DMALLOC
#include <dmalloc.h>
#endif

                 
#ifdef HAVE_ICONV
#include <iconv.h>
#include <errno.h>
#ifdef HAVE_LANGINFO_H
#include <locale.h>
#include <langinfo.h>
#endif
#if defined(__KLIBC__) && !defined(iconv_open)
/* kLIBC iconv_open() does not support UTF-16LE and //TRANSLIT */
static iconv_t os2_iconv_open (const char *tocode, const char *fromcode)
{
    char to[strlen(tocode) + 1];
    char from[strlen(fromcode) + 1];
    char *p;

    strcpy(to, tocode);
    strcpy(from, fromcode);

    if (!strncmp(to, "UTF-16", 6))
    {
        strcpy(to, "UCS-2");
        memmove(to + 5, to + 6, strlen(to + 6) + 1);
    }

    p = strstr(to, "//");
    if (p)
        *p = '\0';

    if (!strncmp(from, "UTF-16", 6))
    {
        strcpy(from, "UCS-2");
        memmove(from + 5, from + 6, strlen(from + 6) + 1);
    }

    p = strstr(from, "//");
    if (p)
        *p = '\0';

    return iconv_open(to, from);
}

#define iconv_open(t, f) os2_iconv_open(t, f)
#endif /* KLIBC iconv */
#endif /* HAVE_ICONV */

#if defined LAME_INTERNAL_OPTIONS
#define INTERNAL_OPTS 1
#else
#define INTERNAL_OPTS 0
#endif

#if (INTERNAL_OPTS!=0)
#include "set_get.h"
#define DEV_HELP(a) a
#else
#define DEV_HELP(a)
#define lame_set_tune(a,b) (void)0
#define lame_set_short_threshold(a,b,c) (void)0
#define lame_set_maskingadjust(a,b) (void)0
#define lame_set_maskingadjust_short(a,b) (void)0
#define lame_set_ATHcurve(a,b) (void)0
#define lame_set_preset_notune(a,b) (void)0
#define lame_set_substep(a,b) (void)0
#define lame_set_subblock_gain(a,b) (void)0
#define lame_set_sfscale(a,b) (void)0
#endif

static int const lame_alpha_version_enabled = LAME_ALPHA_VERSION;
static int const internal_opts_enabled = INTERNAL_OPTS;

/* GLOBAL VARIABLES.  set by parse_args() */
/* we need to clean this up */

const FrontendConfig frontend_config_defaults = FRONTEND_CONFIG_DEFAULTS;
FrontendConfig frontend_config = FRONTEND_CONFIG_DEFAULTS;



/* possible text encodings */
typedef enum TextEncoding
{ TENC_RAW     /* bytes will be stored as-is into ID3 tags, which are Latin1 per definition */
, TENC_LATIN1  /* text will be converted from local encoding to Latin1, as ID3 needs it */
, TENC_UTF16   /* text will be converted from local encoding to Unicode (UCS-2), as ID3v2 wants it */
, TENC_UTF8    /* text will be converted from local encoding to UTF-8, as ID3v2.4 wants it */
} TextEncoding;

#ifdef HAVE_ICONV
#define ID3TAGS_EXTENDED

static char*
currentCharacterEncoding(void)
{
#if defined(_WIN32)
    /* main.c hands on the command line and LAMEOPT as UTF-8. */
    char* cur_code = "UTF-8";
#elif defined(HAVE_LANGINFO_H)
    char* cur_code = nl_langinfo(CODESET);
#else
    char* env_lang = getenv("LANG");
    char* xxx_code = env_lang == NULL ? NULL : strrchr(env_lang, '.');
    char* cur_code = xxx_code == NULL ? "" : xxx_code+1;
#endif
    return cur_code;
}

/**
 * @internal
 * @brief Converts text from one character set to another.
 *
 * iconv() stops at the first character that it cannot convert. The function
 * then returns the part that was converted, and prints a warning with the value
 * and the number of bytes that were dropped.
 *
 * @param to        the target character set, as iconv_open() names it.
 * @param from      the character set of the text.
 * @param src       the text.
 * @param srcbytes  the number of bytes of @a src to convert.
 * @param room      the number of bytes that iconv() may write. The buffer is
 *                  larger, so the result always ends with zero bytes.
 * @param lead      the number of bytes at the start of the result that the
 *                  caller fills in, for a byte-order mark.
 * @return the converted text. An empty string if this system cannot convert
 *         between the two character sets. NULL if no memory is left.
 */
static char *
convert_text(char const *to, char const *from, char const *src,
             size_t srcbytes, size_t room, size_t lead)
{
    char   *dst = calloc(room + 4, 4);
    iconv_t xiconv;
    char   *i_ptr, *o_ptr;
    size_t  srcln, avail, rc;
    /*  The names carry a "//TRANSLIT" flag for iconv_open(), which is an
        instruction rather than part of the encoding's name; the messages below
        stop at it. <string.h> and strcspn() are not visible here on
        pre-standard compilers, so the length is counted by hand. */
    int     to_len = 0;

    while (to[to_len] != '\0' && to[to_len] != '/') {
        ++to_len;
    }

    if (dst == 0) {
        return 0;
    }
    xiconv = iconv_open(to, from);
    if (xiconv == (iconv_t) -1) {
        if (frontend_config.ui_config.silent < 9) {
            error_printf("Cannot convert text from %s to %.*s on this system;"
                         " the value is left out of the tag.\n",
                         from, to_len, to);
        }
        return dst;
    }
    i_ptr = (char *) src;
    o_ptr = &dst[lead];
    srcln = srcbytes;
    avail = room;
    rc = iconv(xiconv, &i_ptr, &srcln, &o_ptr, &avail);
    iconv_close(xiconv);
    if (rc == (size_t) -1 && frontend_config.ui_config.silent < 9) {
        /*  The value is echoed back because a run may set several tag fields,
            and otherwise there is no way to tell which of them was cut. */
        error_printf("Only part of '%s' could be written as %.*s;"
                     " %lu byte(s) of it were dropped.\n",
                     src, to_len, to, (unsigned long) srcln);
    }
    return dst;
}


static
char* toLatin1( char* src )
{
    if (src == 0) {
        return 0;
    }
    {
        size_t const l = strlen(src);
        return convert_text("ISO_8859-1//TRANSLIT", currentCharacterEncoding(),
                            src, l, l*4, 0);
    }
}


static
char* toUtf8( char* src )
{
    if (src == 0) {
        return 0;
    }
    {
        /* XXX: size calculation for UTF-16, a bit too much for UTF-8, but not too small */
        size_t const l = strlen(src);
        return convert_text("UTF-8//TRANSLIT", currentCharacterEncoding(),
                            src, l, (l+1)*4, 0);
    }
}


static
char* toUtf16( char* src )
{
    if (src == 0) {
        return 0;
    }
    {
        size_t const l = strlen(src);
        /* Two bytes are reserved at the front for the byte-order mark, which
           is written afterwards so that it survives a conversion that could
           not start at all. */
        char *dst = convert_text("UTF-16LE//TRANSLIT", currentCharacterEncoding(),
                                 src, l, (l+1)*4, 2);
        if (dst != 0) {
            dst[0] = 0xff;
            dst[1] = 0xfe;
        }
        return dst;
    }
}
#endif

#if defined( _WIN32 ) && !defined(__MINGW32__)
#define ID3TAGS_EXTENDED

char* toLatin1(char const* s)
{
    return utf8ToLatin1(s);
}

unsigned short* toUtf16(char const* s)
{
    return utf8ToUtf16(s);
}

/* The text is UTF-8 already: main.c converts the command line. */
char* toUtf8(char const* s)
{
    return s == 0 ? 0 : strdup(s);
}
#endif

static int evaluateArgument(char const* token, char const* arg, char* end_ptr)
{
    if (arg != 0 && arg != end_ptr)
        return 1;
    error_printf("WARNING: argument missing for '%s'\n", token);
    return 0;
}

/* No option means anything beyond this magnitude, and the callers scale what
   they read by up to a thousand before converting it to an int - so a
   thousand times this has to fit in one. */
#define MAX_NUMERIC_ARGUMENT 1.e6

/* Set when an option's value was refused; parse_args_() fails at the end. */
static int unusable_number = 0;

/**
 * @internal
 * @brief Prints an error for an option value that no option can use, and
 *        marks the parse as failed.
 *
 * @param token  the option, for the message.
 * @param arg    the value as given.
 */
static void
refuse_number(char const* token, char const* arg)
{
    error_printf("Error: '%s' is not a usable value for '%s'\n", arg, token);
    unusable_number = 1;
}

static int getDoubleValue(char const* token, char const* arg, double* ptr)
{
    char *end_ptr=0;
    double d = strtod(arg, &end_ptr);
    if (!double_is_finite(d) || d > MAX_NUMERIC_ARGUMENT || d < -MAX_NUMERIC_ARGUMENT) {
        refuse_number(token, arg);
        d = 0;
    }
    if (ptr != 0) {
        *ptr = d;
    }
    return evaluateArgument(token, arg, end_ptr);
}

static int getIntValue(char const* token, char const* arg, int* ptr)
{
    char *end_ptr=0;
    long d = strtol(arg, &end_ptr, 10);
    if (d > (long) MAX_NUMERIC_ARGUMENT || d < -(long) MAX_NUMERIC_ARGUMENT) {
        refuse_number(token, arg);
        d = 0;
    }
    if (ptr != 0) {
        *ptr = (int)d;
    }
    return evaluateArgument(token, arg, end_ptr);
}

#ifdef ID3TAGS_EXTENDED
/**
 * @internal
 * @brief Returns the ID3v2 text frame that a tag option sets.
 * @param type  the letter of the option: a, t, l, g, n or y.
 * @return the four-character frame identifier. NULL for the comment (c), a
 *         user frame (v) and any other letter.
 */
static char const *
id3v2_text_frame(int type)
{
    switch (type)
    {
        case 'a': return "TPE1";
        case 't': return "TIT2";
        case 'l': return "TALB";
        case 'g': return "TCON";
        case 'n': return "TRCK";
        case 'y': return "TYER";
    }
    return NULL;
}

/* Set an ID3v2 tag field from UTF-16 data. The data pointer is genuinely
   UTF-16 here, so the UTF-16 id3tag_* setters are used throughout. */
static int
set_id3v2tag_utf16(lame_global_flags* gfp, int type, unsigned short const* str)
{
    char const *const id = id3v2_text_frame(type);

    if (id != NULL)
        return id3tag_set_textinfo_utf16(gfp, id, str);
    switch (type)
    {
        case 'c': return id3tag_set_comment_utf16(gfp, 0, 0, str);
        case 'v': return id3tag_set_fieldvalue_utf16(gfp, str);
    }
    return -3;
}

/* Set an ID3v2 tag field from UTF-8 data. The data pointer is a UTF-8 char
   string (not UTF-16 as the old, mistyped single handler assumed), so the
   UTF-8 id3tag_* setters are used - including id3tag_set_fieldvalue_utf8 for
   'v', which replaces the removed *_ucs2 calls the UTF-8 path used to make. */
static int
set_id3v2tag_utf8(lame_global_flags* gfp, int type, char const* str)
{
    char const *const id = id3v2_text_frame(type);

    if (id != NULL)
        return id3tag_set_textinfo_utf8(gfp, id, str);
    switch (type)
    {
        case 'c': return id3tag_set_comment_utf8(gfp, 0, 0, str);
        case 'v': return id3tag_set_fieldvalue_utf8(gfp, str);
    }
    return -3;
}
#endif

static int
set_id3tag(lame_global_flags* gfp, int type, char const* str)
{
    switch (type)
    {
        case 'a': return id3tag_set_artist(gfp, str), 0;
        case 't': return id3tag_set_title(gfp, str), 0;
        case 'l': return id3tag_set_album(gfp, str), 0;
        case 'g': return id3tag_set_genre(gfp, str);
        case 'c': return id3tag_set_comment(gfp, str), 0;
        case 'n': return id3tag_set_track(gfp, str);
        case 'y': return id3tag_set_year(gfp, str), 0;
        case 'v': return id3tag_set_fieldvalue(gfp, str);
    }
    return 0;
}

static int
id3_tag(lame_global_flags* gfp, int type, TextEncoding enc, char* str)
{
    void* x = 0;
    int result;
    if ((enc == TENC_UTF16 || enc == TENC_UTF8) && type != 'v' ) {
        id3_tag(gfp, type, TENC_LATIN1, str); /* for id3v1 */
    }
    switch (enc) 
    {
        default:
#ifdef ID3TAGS_EXTENDED
        case TENC_LATIN1: x = toLatin1(str); break;
        case TENC_UTF16:  x = toUtf16(str);  break;
        case TENC_UTF8:   x = toUtf8(str);   break;
#else
        case TENC_RAW:    x = strdup(str);   break;
#endif
    }
    switch (enc)
    {
        default:
#ifdef ID3TAGS_EXTENDED
        case TENC_LATIN1: result = set_id3tag(gfp, type, x);   break;
        case TENC_UTF16:  result = set_id3v2tag_utf16(gfp, type, x); break;
        case TENC_UTF8:   result = set_id3v2tag_utf8(gfp, type, x);  break;
#else
        case TENC_RAW:    result = set_id3tag(gfp, type, x);   break;
#endif
    }
    free(x);
    return result;
}




/************************************************************************
*
* license
*
* PURPOSE:  Writes version and license to the file specified by fp
*
************************************************************************/

static int
lame_version_print(FILE * const fp)
{
    const char *b = get_lame_os_bitness();
    const char *v = get_lame_version();
    const char *u = get_lame_url();
    const size_t lenb = strlen(b);
    const size_t lenv = strlen(v);
    const size_t lenu = strlen(u);
    const size_t lw = 80;       /* line width of terminal in characters */
    const size_t sw = 16;       /* static width of text */

    if (lw >= lenb + lenv + lenu + sw || lw < lenu + 2)
        /* text fits in 80 chars per line, or line even too small for url */
        if (lenb > 0)
            fprintf(fp, "LAME %s version %s (%s)\n\n", b, v, u);
        else
            fprintf(fp, "LAME version %s (%s)\n\n", v, u);
    else {
        int const n_white_spaces = (int)(lw - 2 - lenu);
        /* text too long, wrap url into next line, right aligned */
        if (lenb > 0)
            fprintf(fp, "LAME %s version %s\n%*s(%s)\n\n", b, v, n_white_spaces, "", u);
        else
            fprintf(fp, "LAME version %s\n%*s(%s)\n\n", v, n_white_spaces, "", u);
    }
    if (lame_alpha_version_enabled)
        fprintf(fp, "warning: alpha versions should be used for testing only\n\n");


    return 0;
}

static int
print_license(FILE * const fp)
{                       /* print version & license */
    lame_version_print(fp);
    fprintf(fp,
            "Copyright (c) 1999-2011 by The LAME Project\n"
            "Copyright (c) 1999,2000,2001 by Mark Taylor\n"
            "Copyright (c) 1998 by Michael Cheng\n"
            "Copyright (c) 1995,1996,1997 by Michael Hipp: mpglib\n" "\n");
    fprintf(fp,
            "This library is free software; you can redistribute it and/or\n"
            "modify it under the terms of the GNU Library General Public\n"
            "License as published by the Free Software Foundation; either\n"
            "version 2 of the License, or (at your option) any later version.\n"
            "\n");
    fprintf(fp,
            "This library is distributed in the hope that it will be useful,\n"
            "but WITHOUT ANY WARRANTY; without even the implied warranty of\n"
            "MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU\n"
            "Library General Public License for more details.\n"
            "\n");
    fprintf(fp,
            "You should have received a copy of the GNU Library General Public\n"
            "License along with this program. If not, see\n"
            "<http://www.gnu.org/licenses/>.\n");
    return 0;
}


/************************************************************************
*
* usage
*
* PURPOSE:  Writes command line syntax to the file specified by fp
*
************************************************************************/

int
usage(FILE * const fp, const char *ProgramName)
{                       /* print general syntax */
    lame_version_print(fp);
    fprintf(fp,
            "usage: %s [options] <infile> [outfile]\n"
            "\n"
            "    <infile> and/or <outfile> can be \"-\", which means stdin/stdout.\n"
            "\n"
            "Try:\n"
            "     \"%s --help\"           for general usage information\n"
            " or:\n"
            "     \"%s --preset help\"    for information on suggested predefined settings\n"
            " or:\n"
            "     \"%s --longhelp\"\n"
            "  or \"%s -?\"              for a complete options list\n\n",
            ProgramName, ProgramName, ProgramName, ProgramName, ProgramName);
    return 0;
}


/************************************************************************
*
* usage
*
* PURPOSE:  Writes command line syntax to the file specified by fp
*           but only the most important ones, to fit on a vt100 terminal
*
************************************************************************/

int
short_help(const lame_global_flags * gfp, FILE * const fp, const char *ProgramName)
{                       /* print short syntax help */
    lame_version_print(fp);
    fprintf(fp,
            "usage: %s [options] <infile> [outfile]\n"
            "\n"
            "    <infile> and/or <outfile> can be \"-\", which means stdin/stdout.\n"
            "\n" "RECOMMENDED:\n" "    lame -V2 input.wav output.mp3\n" "\n", ProgramName);
    fprintf(fp,
            "OPTIONS:\n"
            "    -b bitrate      set the bitrate, default 128 kbps\n"
            "    -h              higher quality, but a little slower.\n"
            "    -f              fast mode (lower quality)\n"
            "    -V n            quality setting for VBR.  default n=%i\n"
            "                    0=high quality,bigger files. 9.999=smaller files\n",
            lame_get_VBR_q(gfp));
    fprintf(fp,
            "    --preset type   type must be \"medium\", \"standard\", \"extreme\", \"insane\",\n"
            "                    or a value for an average desired bitrate and depending\n"
            "                    on the value specified, appropriate quality settings will\n"
            "                    be used.\n"
            "                    \"--preset help\" gives more info on these\n" "\n");
    fprintf(fp,
#if defined(WIN32)
            "    --priority type  sets the process priority\n"
            "                     0,1 = Low priority\n"
            "                     2   = normal priority\n"
            "                     3,4 = High priority\n" "\n"
#endif
#if defined(__OS2__)
            "    --priority type  sets the process priority\n"
            "                     0 = Low priority\n"
            "                     1 = Medium priority\n"
            "                     2 = Regular priority\n"
            "                     3 = High priority\n"
            "                     4 = Maximum priority\n" "\n"
#endif
            "    --help id3      ID3 tagging related options\n" "\n"
            DEV_HELP(
            "    --help dev      developer options\n" "\n"
            )
            "    --longhelp      full list of options\n" "\n"
            "    --license       print License information\n\n"
            );

    return 0;
}

/************************************************************************
*
* usage
*
* PURPOSE:  Writes command line syntax to the file specified by fp
*
************************************************************************/

static void
wait_for(FILE * const fp, int lessmode)
{
    if (lessmode) {
        fflush(fp);
        getchar();
    }
    else {
        fprintf(fp, "\n");
    }
    fprintf(fp, "\n");
}

static void
help_id3tag(FILE * const fp)
{
    fprintf(fp,
            "  ID3 tag options:\n"
            "    --tt <title>    audio/song title (max 30 chars for version 1 tag)\n"
            "    --ta <artist>   audio/song artist (max 30 chars for version 1 tag)\n"
            "    --tl <album>    audio/song album (max 30 chars for version 1 tag)\n"
            "    --ty <year>     audio/song year of issue (1 to 9999)\n"
            "    --tc <comment>  user-defined text (max 30 chars for v1 tag, 28 for v1.1)\n");
    fprintf(fp,
            "    --tn <track[/total]>   audio/song track number and (optionally) the total\n"
            "                           number of tracks on the original recording. (track\n"
            "                           and total each 1 to 255. just the track number\n"
            "                           creates v1.1 tag, providing a total forces v2.0).\n");
    fprintf(fp,
            "    --tg <genre>    audio/song genre (name or number in list)\n"
            "    --ti <file>     audio/song albumArt (jpeg/png/gif file, v2.3 tag)\n"
            "    --tv <id=value> user-defined frame specified by id and value (v2.3 tag)\n"
            "                    syntax: --tv \"TXXX=description=content\"\n"
            );
    fprintf(fp,
            "    --add-id3v2     force addition of version 2 tag\n"
            "    --id3v1-only    add only a version 1 tag\n"
            "    --id3v2-only    add only a version 2 tag\n"
#ifdef ID3TAGS_EXTENDED
            "    --id3v2-utf8    add following options in unicode UTF-8 text encoding\n"
            "    --id3v2-utf16   add following options in unicode UTF-16 text encoding\n"
            "    --id3v2-latin1  add following options in latin-1 text encoding\n"
#endif
            "    --space-id3v1   pad version 1 tag with spaces instead of nulls\n"
            "    --pad-id3v2     same as '--pad-id3v2-size 128'\n"
            "    --pad-id3v2-size <value> adds version 2 tag, pad with extra <value> bytes\n"
            "    --genre-list    print alphabetically sorted ID3 genre list and exit\n"
            "    --ignore-tag-errors  ignore errors in values passed for tags\n" "\n"
            );
    fprintf(fp,
            "    Note: A version 2 tag will NOT be added unless one of the input fields\n"
            "    won't fit in a version 1 tag (e.g. the title string is longer than 30\n"
            "    characters), or the '--add-id3v2' or '--id3v2-only' options are used,\n"
            "    or output is redirected to stdout.\n"
            );
}

static void
help_developer_switches(FILE * const fp)
{
    if ( !internal_opts_enabled ) {
    fprintf(fp,
            "    Note: Almost all of the following switches aren't available in this build!\n\n"
            );
    }
    fprintf(fp,
            "  ATH related:\n"
            "    --noath         turns ATH down to a flat noise floor\n"
            "    --athshort      ignore GPSYCHO for short blocks, use ATH only\n"
            "    --athonly       ignore GPSYCHO completely, use ATH only\n"
            "    --athtype n     selects between different ATH types [0-4]\n"
            "    --athlower x    lowers ATH by x dB\n"
            );
    fprintf(fp,
            "    --athaa-type n  ATH auto adjust: 0 'no' else 'loudness based'\n"
/*  OBSOLETE "    --athaa-loudapprox n   n=1 total energy or n=2 equal loudness curve\n"*/
            "    --athaa-sensitivity x  activation offset in -/+ dB for ATH auto-adjustment\n"
            "\n");
    fprintf(fp,
            "  PSY related:\n"
            "    --short         use short blocks when appropriate\n"
            "    --noshort       do not use short blocks\n"
            "    --allshort      use only short blocks\n"
            );
    fprintf(fp,
            "(1) --temporal-masking x   x=0 disables, x=1 enables temporal masking effect\n"
            "    --nssafejoint   M/S switching criterion\n"
            "    --nsmsfix <arg> M/S switching tuning [effective 0-3.5]\n"
            "(2) --interch x     adjust inter-channel masking ratio\n"
            "    --ns-bass x     adjust masking for sfbs  0 -  6 (long)  0 -  5 (short)\n"
            "    --ns-alto x     adjust masking for sfbs  7 - 13 (long)  6 - 10 (short)\n"
            "    --ns-treble x   adjust masking for sfbs 14 - 21 (long) 11 - 12 (short)\n"
            );
    fprintf(fp,
            "    --ns-sfb21 x    change ns-treble by x dB for sfb21\n"
            "    --shortthreshold x,y  short block switching threshold,\n"
            "                          x for L/R/M channel, y for S channel\n"
            "    -Z [n]          always do calculate short block maskings\n");
    fprintf(fp,
            "  Noise Shaping related:\n"
            "(1) --substep n     pseudo substep noise shaping. n is 0 to 7, the sum of\n"
            "                    1 (apply it), 2 (half steps from the start) and\n"
            "                    4 (short blocks too)\n"
            "(1) -X n[,m]        selects between different noise measurements\n"
            "                    n for long block, m for short. if m is omitted, m = n\n"
            " 1: CBR, ABR and VBR-old encoding modes only\n"
            " 2: ignored\n"
           );
}

/* One vector-routine name, terminator included.  They are short identifiers;
   a name that did not fit here could not be matched by the library either. */
#define VECTOR_NAME_MAX     32
/* The whole list of them, as --longhelp and the error message print it. */
#define VECTOR_CHOICES_MAX  128

/* The names --vector takes, assembled into buf.  They are read out of the
   library rather than written out here, so a build without AVX2 - or one for
   another architecture - never offers a choice it cannot honour.  The help
   text and the error message get the same list for the same reason. */
static const char *
vector_choices(char *buf, size_t size)
{
    int     i;
    int const n = lame_get_num_vector_routines();
    size_t  used;

    if (size == 0)
        return "";
    buf[0] = '\0';
    strncat(buf, "auto, none", size - 1);
    used = lame_strnlen(buf, size);
    for (i = 0; i < n; ++i) {
        const char *const name = lame_get_vector_routines_name(i);
        size_t const len = lame_strnlen(name, size);

        if (used + 2 + len + 1 > size)
            break;
        strncat(buf, ", ", size - used - 1);
        used += 2;
        strncat(buf, name, size - used - 1);
        used += len;
    }
    return buf;
}

int
long_help(const lame_global_flags * gfp, FILE * const fp, const char *ProgramName, int lessmode)
{                       /* print long syntax help */
    lame_version_print(fp);
    fprintf(fp,
            "usage: %s [options] <infile> [outfile]\n"
            "\n"
            "    <infile> and/or <outfile> can be \"-\", which means stdin/stdout.\n"
            "\n" "RECOMMENDED:\n" "    lame -V2 input.wav output.mp3\n" "\n", ProgramName);
    fprintf(fp,
            "OPTIONS:\n"
            "  Input options:\n"
            "    --scale <arg>   scale input (multiply PCM data) by <arg>\n"
            "    --scale-l <arg> scale channel 0 (left) input (multiply PCM data) by <arg>\n"
            "    --scale-r <arg> scale channel 1 (right) input (multiply PCM data) by <arg>\n"
            "    --swap-channel  swap L/R channels\n"
            "    --ignorelength  ignore file length in WAV header\n"
            "    --gain <arg>    apply Gain adjustment in decibels, range -20.0 to +12.0\n"
           );
#ifdef HAVE_MPG123
    fprintf(fp,
            "    --mp1input      input file is a MPEG Layer I   file\n"
            "    --mp2input      input file is a MPEG Layer II  file\n"
            "    --mp3input      input file is a MPEG Layer III file\n"
           );
#endif
    fprintf(fp,
            "    --nogap <file1> <file2> <...>\n"
            "                    gapless encoding for a set of contiguous files\n"
            "    --nogapout <dir>\n"
            "                    output dir for gapless encoding (must precede --nogap)\n"
            "    --nogaptags     allow the use of VBR tags in gapless encoding\n"
            "    --out-dir <dir> output dir, must exist\n"
           );
    fprintf(fp,
            "\n"
            "  Input options for RAW PCM:\n"
            "    -r              input is raw pcm\n"
            "    -s sfreq        sampling frequency of input file (kHz) - default 44.1 kHz\n"
            "    --signed        input is signed (default)\n"
            "    --unsigned      input is unsigned\n"
            "    --bitwidth w    input bit width is w (default 16)\n"
            "    -x              force byte-swapping of input\n"
            "    --little-endian input is little-endian (default)\n"
            "    --big-endian    input is big-endian\n"
            "    -a              downmix from stereo to mono file for mono encoding\n"
           );

    wait_for(fp, lessmode);
    fprintf(fp,
            "  Operational options:\n"
            "    -m <mode>       (j)oint, (s)imple, (f)orce, (d)ual-mono, (m)ono (l)eft (r)ight\n"
            "                    default is (j)\n"
            "                    joint  = Uses the best possible of MS and LR stereo\n"
            "                    simple = force LR stereo on all frames\n"
            "                    force  = force MS stereo on all frames.\n"
	   );
    fprintf(fp,
            "    --preset type   type must be \"medium\", \"standard\", \"extreme\", \"insane\",\n"
            "                    or a value for an average desired bitrate and depending\n"
            "                    on the value specified, appropriate quality settings will\n"
            "                    be used.\n"
            "                    \"--preset help\" gives more info on these\n"
            "    --comp  <arg>   choose bitrate to achieve a compression ratio of <arg>\n");
    fprintf(fp, "    --replaygain-fast   compute RG fast but slightly inaccurately (default)\n"
#ifdef HAVE_MPG123
            "    --replaygain-accurate   compute RG more accurately and find the peak sample\n"
#endif
            "    --noreplaygain  disable ReplayGain analysis\n"
            "    --replaygain-id3v2  also write ReplayGain to the ID3v2 tag, as the\n"
            "                    REPLAYGAIN_TRACK_GAIN and REPLAYGAIN_TRACK_PEAK frames\n"
#ifdef HAVE_MPG123
            "    --clipdetect    enable --replaygain-accurate and print a message whether\n"
            "                    clipping occurs and how far the waveform is from full scale\n"
#endif
        );
    fprintf(fp,
            "    --flush         flush output stream as soon as possible\n"
            "    --preserve-modtime  give the output file the date and time of the\n"
            "                    input file\n"
            "    --freeformat    produce a free format bitstream\n"
            "    --decode        input=mp3 file, output=wav\n"
            "    -t              disable writing wav header when using --decode\n");

    wait_for(fp, lessmode);
    fprintf(fp,
            "  Verbosity:\n"
            "    --disptime <arg>print progress report every arg seconds\n"
            "    -S              don't print progress report, VBR histograms\n"
            "    --nohist        disable VBR histogram display\n"
            "    --quiet         don't print anything on screen\n"
            "    --silent        don't print anything on screen, but fatal errors\n"
            "    --brief         print more useful information\n"
            "    --verbose       print a lot of useful information\n" "\n");
    fprintf(fp,
            "  Noise shaping & psycho acoustic algorithms:\n"
            "    -q <arg>        <arg> = 0...9.  Default  -q 3 \n"
            "                    -q 0:  Highest quality, very slow \n"
            "                    -q 9:  Poor quality, but fast \n"
            "    -h              Same as -q 2.   \n"
            "    -f              Same as -q 7.   Fast, ok quality\n");

    wait_for(fp, lessmode);
    fprintf(fp,
            "  CBR (constant bitrate, the default) options:\n"
            "    -b <bitrate>    set the bitrate in kbps, default 128 kbps\n"
            "    --cbr           enforce use of constant bitrate\n"
            "\n"
            "  ABR options:\n"
            "    --abr <bitrate> specify average bitrate desired (instead of quality)\n" "\n");
    fprintf(fp,
            "  VBR options:\n"
            "    -V n            quality setting for VBR.  default n=%i\n"
            "                    0=high quality,bigger files. 9=smaller files\n"
            "    -v              the same as -V 4\n"
            "    --vbr-old       use old variable bitrate (VBR) routine\n"
            "    --vbr-new       use new variable bitrate (VBR) routine (default)\n"
            "    -Y              lets LAME ignore noise in sfb21, like in CBR\n"
			"                    (Default for V3 to V9.999)\n"
            ,
            lame_get_VBR_q(gfp));
    fprintf(fp,
            "    -b <bitrate>    specify minimum allowed bitrate, default  32 kbps\n"
            "    -B <bitrate>    specify maximum allowed bitrate, default 320 kbps\n"
            "    -F              strictly enforce the -b option, for use with players that\n"
            "                    do not support low bitrate mp3\n"
            "    -t              disable writing LAME Tag\n"
            "    -T              enable and force writing LAME Tag\n");

    wait_for(fp, lessmode);
    DEV_HELP(
        help_developer_switches(fp);
        wait_for(fp, lessmode);
            )

    fprintf(fp,
            "  MP3 header/stream options:\n"
            "    -e <emp>        de-emphasis n/5/c  (obsolete)\n"
            "    -c              mark as copyright\n"
            "    -o              mark as non-original\n"
            "    -p              error protection.  adds 16 bit checksum to every frame\n"
            "                    (the checksum is computed correctly)\n"
            "    --nores         disable the bit reservoir\n"
            "    --strictly-enforce-ISO   comply as much as possible to ISO MPEG spec\n");
    fprintf(fp,
            "    --buffer-constraint <constraint> available values for constraint:\n"
            "                                     default, strict, maximum\n"
            "\n"
            );
    fprintf(fp,
            "  Filter options:\n"
            "  --lowpass <freq>        frequency(kHz), lowpass filter cutoff above freq\n"
            "  --lowpass-width <freq>  frequency(kHz) - default 15%% of lowpass freq\n"
            "  --highpass <freq>       frequency(kHz), highpass filter cutoff below freq\n"
            "  --highpass-width <freq> frequency(kHz) - default 15%% of highpass freq\n");
    fprintf(fp,
            "  --resample <sfreq>  sampling frequency of output file(kHz)- default=automatic\n");

    wait_for(fp, lessmode);
    help_id3tag(fp);
    fprintf(fp,
#if defined(WIN32)
            "\n\nMS-Windows-specific options:\n"
            "    --priority <type>  sets the process priority:\n"
            "                         0,1 = Low priority (IDLE_PRIORITY_CLASS)\n"
            "                         2 = normal priority (NORMAL_PRIORITY_CLASS, default)\n"
            "                         3,4 = High priority (HIGH_PRIORITY_CLASS))\n"
            "    Note: Calling '--priority' without a parameter will select priority 0.\n"
#endif
#if defined(__OS2__)
            "\n\nOS/2-specific options:\n"
            "    --priority <type>  sets the process priority:\n"
            "                         0 = Low priority (IDLE, delta = 0)\n"
            "                         1 = Medium priority (IDLE, delta = +31)\n"
            "                         2 = Regular priority (REGULAR, delta = -31)\n"
            "                         3 = High priority (REGULAR, delta = 0)\n"
            "                         4 = Maximum priority (REGULAR, delta = +31)\n"
            "    Note: Calling '--priority' without a parameter will select priority 0.\n"
#endif
            "\nMisc:\n    --license       print License information\n\n"
        );

    wait_for(fp, lessmode);
    {
        char    choices[VECTOR_CHOICES_MAX];

        fprintf(fp,
                "  Platform specific:\n"
                "    --vector <name>     which vector routines to run: %s\n"
                "                        default is auto, the widest set this CPU has\n"
                "    --noasm <type>      deprecated, use --vector\n",
                vector_choices(choices, sizeof choices));
    }
    wait_for(fp, lessmode);

    display_bitrates(fp);

    return 0;
}

static void
display_bitrate(FILE * const fp, const char *const version, const int d, const int indx)
{
    int     i;
    int nBitrates = 14;
    if (d == 4)
        nBitrates = 8;


    fprintf(fp,
            "\nMPEG-%-3s layer III sample frequencies (kHz):  %2d  %2d  %g\n"
            "bitrates (kbps):", version, 32 / d, 48 / d, 44.1 / d);
    for (i = 1; i <= nBitrates; i++)
        fprintf(fp, " %2i", lame_get_bitrate(indx, i));
    fprintf(fp, "\n");
}

int
display_bitrates(FILE * const fp)
{
    display_bitrate(fp, "1", 1, 1);
    display_bitrate(fp, "2", 2, 0);
    display_bitrate(fp, "2.5", 4, 0);
    fprintf(fp, "\n");
    fflush(fp);
    return 0;
}

/**
 * @internal
 * @brief Calls lame_init_params(), and prints the table of valid bitrates
 *        when it rejects the bitrate.
 * @param gfp  the encoder instance.
 * @return the result of lame_init_params(). -1 is the result that the table
 *         goes with.
 */
int
frontend_init_params(lame_global_flags * gfp)
{
    int const ret = lame_init_params(gfp);

    if (ret == -1) {
        display_bitrates(stderr);
    }
    return ret;
}

/**
 * @internal
 * @brief Returns the message for a negative result of an encode or flush call.
 *
 * The codes are the ones that lame_encode_buffer() and lame_encode_flush()
 * document.
 *
 * @param code  the result of the call.
 * @return the message, without a line break.
 */
const char *
frontend_encode_error_text(int code)
{
    switch (code) {
    case -1:
        return "the output buffer is too small";
    case -2:
        return "the encoder is out of memory";
    case -3:
        return "the encoder is not set up";
    case -4:
        return "the psychoacoustic model failed";
    case -6:
        return "the ReplayGain analysis of the resampled input failed";
    case LAME_BADINPUTDATA:
        return "the input holds a sample that is not a number, is infinite, "
            "or is more than 4096 times full scale";
    case LAME_INTERNALERROR:
        return "the encoder could not fit a frame into its bits";
    default:
        return "the encoder failed";
    }
}


/*  note: for presets it would be better to externalize them in a file.
    suggestion:  lame --preset <file-name> ...
            or:  lame --preset my-setting  ... and my-setting is defined in lame.ini
 */

/*
Note from GB on 08/25/2002:
I am merging --presets and --alt-presets. Old presets are now aliases for
corresponding abr values from old alt-presets. This way we now have a
unified preset system, and I hope than more people will use the new tuned
presets instead of the old unmaintained ones.
*/



/************************************************************************
*
* usage
*
* PURPOSE:  Writes presetting info to #stdout#
*
************************************************************************/


static void
presets_longinfo_dm(FILE * msgfp)
{
    fprintf(msgfp,
            "\n"
            "The --preset switches are aliases over LAME settings.\n"
            "\n" "\n");
    fprintf(msgfp,
            "To activate these presets:\n"
            "\n" "   For VBR modes (generally highest quality):\n" "\n");
    fprintf(msgfp,
            "     --preset medium      This preset should provide near transparency to most\n"
            "                          people on most music.\n"
            "\n"
            "     --preset standard    This preset should generally be transparent to most\n"
            "                          people on most music and is already quite high\n"
            "                          in quality.\n" "\n");
    fprintf(msgfp,
            "     --preset extreme     If you have extremely good hearing and similar\n"
            "                          equipment, this preset will generally provide\n"
            "                          slightly higher quality than the \"standard\" mode.\n" "\n");
    fprintf(msgfp,
            "   For CBR 320kbps (highest quality possible from the --preset switches):\n"
            "\n"
            "     --preset insane      This preset will usually be overkill for most people\n"
            "                          and most situations, but if you must have the\n"
            "                          absolute highest quality with no regard to filesize,\n"
            "                          this is the way to go.\n" "\n");
    fprintf(msgfp,
            "   For ABR modes (high quality per given bitrate but not as high as VBR):\n"
            "\n"
            "     --preset <kbps>      Using this preset will usually give you good quality\n"
            "                          at a specified bitrate. Depending on the bitrate\n"
            "                          entered, this preset will determine the optimal\n"
            "                          settings for that particular situation. For example:\n"
            "                          \"--preset 185\" activates this preset and uses 185\n"
            "                          as an average kbps.\n" "\n");
    fprintf(msgfp,
            "   \"cbr\"  - If you use the ABR mode (read above) with a significant\n"
            "            bitrate such as 80, 96, 112, 128, 160, 192, 224, 256, 320,\n"
            "            you can use the \"cbr\" option to force CBR mode encoding\n"
            "            instead of the standard abr mode. ABR does provide higher\n"
            "            quality but CBR may be useful in situations such as when\n"
            "            streaming an mp3 over the internet may be important.\n" "\n");
    fprintf(msgfp,
            "    For example:\n"
            "\n"
            "    --preset standard <input file> <output file>\n"
            " or --preset cbr 192 <input file> <output file>\n"
            " or --preset 172 <input file> <output file>\n"
            " or --preset extreme <input file> <output file>\n" "\n" "\n");
    fprintf(msgfp,
            "A few aliases are also available for ABR mode:\n"
            "phone => 16kbps/mono        phon+/lw/mw-eu/sw => 24kbps/mono\n"
            "mw-us => 40kbps/mono        voice => 56kbps/mono\n"
            "fm/radio/tape => 112kbps    hifi => 160kbps\n"
            "cd => 192kbps               studio => 256kbps\n");
}


/** The size of the name of a --preset alias, terminator included. */
#define PRESET_ALIAS_SIZE 8

/** @internal @brief A --preset alias for an ABR bitrate. */
typedef struct {
    char    name[PRESET_ALIAS_SIZE]; /**< the alias */
    int     kbps;             /**< the ABR bitrate */
    int     mono;             /**< 1 when the alias also selects mono */
} preset_alias;

/** The aliases of --preset that select an ABR bitrate. */
static const preset_alias preset_aliases[] = {
    { "phone", 16, 1 },
    { "phon+", 24, 1 }, { "lw", 24, 1 }, { "mw-eu", 24, 1 }, { "sw", 24, 1 },
    { "mw-us", 40, 1 },
    { "voice", 56, 1 },
    { "fm", 112, 0 }, { "radio", 112, 0 }, { "tape", 112, 0 },
    { "hifi", 160, 0 },
    { "cd", 192, 0 },
    { "studio", 256, 0 }
};

static int
presets_set(lame_t gfp, int fast, int cbr, const char *preset_name, const char *ProgramName)
{
    int     mono = 0;
    int     kbps = atoi(preset_name);
    size_t  i;

    if ((strcmp(preset_name, "help") == 0) && (fast < 1)
        && (cbr < 1)) {
        lame_version_print(stdout);
        presets_longinfo_dm(stdout);
        return -2;      /* asked for and got: stop, but not an error */
    }

    /*aliases for compatibility with old presets */
    for (i = 0; i < dimension_of(preset_aliases); ++i) {
        if (strncmp(preset_name, preset_aliases[i].name, PRESET_ALIAS_SIZE) == 0) {
            kbps = preset_aliases[i].kbps;
            mono = preset_aliases[i].mono;
            break;
        }
    }

    if (strcmp(preset_name, "medium") == 0) {
        lame_set_VBR_q(gfp, 4);
        lame_set_VBR(gfp, vbr_default);
        return 0;
    }

    if (strcmp(preset_name, "standard") == 0) {
        lame_set_VBR_q(gfp, 2);
        lame_set_VBR(gfp, vbr_default);
        return 0;
    }

    else if (strcmp(preset_name, "extreme") == 0) {
        lame_set_VBR_q(gfp, 0);
        lame_set_VBR(gfp, vbr_default);
        return 0;
    }

    else if ((strcmp(preset_name, "insane") == 0) && (fast < 1)) {

        lame_set_preset(gfp, INSANE);

        return 0;
    }

    /* Generic ABR Preset */
    if (kbps > 0 && fast < 1) {
        if (kbps >= 8 && kbps <= 320) {
            lame_set_preset(gfp, kbps);

            if (cbr == 1)
                lame_set_VBR(gfp, vbr_off);

            if (mono == 1) {
                lame_set_mode(gfp, MONO);
            }

            return 0;

        }
        else {
            lame_version_print(Console_IO.Error_fp);
            error_printf("Error: The bitrate specified is out of the valid range for this preset\n"
                         "\n"
                         "When using this mode you must enter a value between \"8\" and \"320\"\n"
                         "\n" "For further information try: \"%s --preset help\"\n", ProgramName);
            return -1;
        }
    }

    lame_version_print(Console_IO.Error_fp);
    error_printf("Error: You did not enter a valid profile and/or options with --preset\n"
                 "\n"
                 "Available profiles are:\n"
                 "\n"
                 "                 medium\n"
                 "                 standard\n"
                 "                 extreme\n"
                 "                 insane\n"
                 "          <cbr> (ABR Mode) - The ABR Mode is implied. To use it,\n"
                 "                             simply specify a bitrate. For example:\n"
                 "                             \"--preset 185\" activates this\n"
                 "                             preset and uses 185 as an average kbps.\n" "\n");
    error_printf("    Some examples:\n"
                 "\n"
                 " or \"%s --preset standard <input file> <output file>\"\n"
                 " or \"%s --preset cbr 192 <input file> <output file>\"\n"
                 " or \"%s --preset 172 <input file> <output file>\"\n"
                 " or \"%s --preset extreme <input file> <output file>\"\n"
                 "\n"
                 "For further information try: \"%s --preset help\"\n", ProgramName, ProgramName,
                 ProgramName, ProgramName, ProgramName);
    return -1;
}

static void
genre_list_handler(int num, const char *name, LAME_UNUSED void *cookie)
{
    console_printf("%3d %s\n", num, name);
}


/************************************************************************
*
* parse_args
*
* PURPOSE:  Sets encoding parameters to the specifications of the
* command line.  Default settings are used for parameters
* not specified in the command line.
*
* If the input file is in WAVE or AIFF format, the sampling frequency is read
* from the AIFF header.
*
* The input and output filenames are read into #inpath# and #outpath#.
*
************************************************************************/

/* would use real "strcasecmp" but it isn't portable */
static int
local_strcasecmp(const char *s1, const char *s2)
{
    unsigned char c1;
    unsigned char c2;

    do {
        c1 = (unsigned char) tolower((unsigned char) *s1);
        c2 = (unsigned char) tolower((unsigned char) *s2);
        if (!c1) {
            break;
        }
        ++s1;
        ++s2;
    } while (c1 == c2);
    return c1 - c2;
}

#if !defined(HAVE_MPG123)
/** @internal @brief The options that need the decoder, without the two dashes. */
static char const *const decoder_options[] = {
    "replaygain-accurate", "clipdetect", "mp1input", "mp2input", "mp3input"
};

/**
 * @internal
 * @brief Whether an option needs the decoder, which this build does not have.
 * @param token  the option, without the two dashes.
 * @return 1 when it does, 0 when it does not.
 */
static int
is_decoder_option(char const *token)
{
    size_t  i;

    for (i = 0; i < dimension_of(decoder_options); ++i)
        if (0 == local_strcasecmp(token, decoder_options[i]))
            return 1;
    return 0;
}

/** @internal @brief Reports that an input or an option needs the missing decoder. */
static void
report_missing_decoder(void)
{
    error_printf("Error: libmp3lame not compiled with mpg123 *decoding* support \n");
}
#endif

static int
local_strncasecmp(const char *s1, const char *s2, int n)
{
    unsigned char c1 = 0;
    unsigned char c2 = 0;
    int     cnt = 0;

    do {
        if (cnt == n) {
            break;
        }
        c1 = (unsigned char) tolower((unsigned char) *s1);
        c2 = (unsigned char) tolower((unsigned char) *s2);
        if (!c1) {
            break;
        }
        ++s1;
        ++s2;
        ++cnt;
    } while (c1 == c2);
    return c1 - c2;
}



static int
resample_rate(double freq)
{
    if (freq >= 1.e3)
        freq *= 1.e-3;

    switch ((int) freq) {
    case 8:
        return 8000;
    case 11:
        return 11025;
    case 12:
        return 12000;
    case 16:
        return 16000;
    case 22:
        return 22050;
    case 24:
        return 24000;
    case 32:
        return 32000;
    case 44:
        return 44100;
    case 48:
        return 48000;
    default:
        error_printf("Illegal resample frequency: %.3f kHz\n", freq);
        return 0;
    }
}

#ifdef _WIN32
#define SLASH '\\'
#define COLON ':'
#elif __OS2__
#define SLASH '\\'
#else
#define SLASH '/'
#endif

/**
 * @internal
 * @brief Tells whether a character is a directory separator of a path.
 *
 * On Windows and OS/2 both @c \\ and @c / separate; elsewhere @c / does.
 *
 * @param c  the character.
 * @return 1 if @p c is a separator, else 0.
 */
static int
is_slash(char c)
{
#if defined(_WIN32) || defined(__OS2__)
    return c == '\\' || c == '/';
#else
    return c == '/';
#endif
}

/**
 * @internal
 * @brief Tells whether a character ends a part of a path: a separator, or on
 *        Windows the colon after a drive letter.
 *
 * @param c  the character.
 * @return 1 if @p c ends a part, else 0.
 */
static int
is_path_separator(char c)
{
#ifdef _WIN32
    if (c == COLON)
        return 1;
#endif
    return is_slash(c);
}

static
size_t scanPath(char const* s, char const** a, char const** b)
{
    char const* s1 = s;
    char const* s2 = s;
    if (s != 0) {
        for (; *s; ++s) {
            if (is_path_separator(*s))
                s2 = s;
        }
#ifdef _WIN32
        if (*s2 == COLON) {
            ++s2;
        }
#endif
    }
    if (a) {
        *a = s1;
    }
    if (b) {
        *b = s2;
    }
    return s2-s1;
}

static
size_t scanBasename(char const* s, char const** a, char const** b)
{
    char const* s1 = s;
    char const* s2 = s;
    if (s != 0) {
        for (; *s; ++s) {
            if (is_path_separator(*s))
                s1 = s2 = s;
            else if (*s == '.')
                s2 = s;
        }
        if (s2 == s1) {
            s2 = s;
        }
        if (is_path_separator(*s1)) {
            ++s1;
        }
    }
    if (a != 0) {
        *a = s1;
    }
    if (b != 0) {
        *b = s2;
    }
    return s2-s1;
}

/**
 * @internal
 * @brief The file name suffixes that the frontends know, with the input
 *        format that each one hints at.
 *
 * generateOutPath() replaces any of these suffixes with the suffix of the
 * output. frontend_classify_suffix() takes the input format from them. A
 * format of @c sf_unknown means that the suffix is known but does not say
 * how to read the file.
 */
static const struct {
    const char *suffix;         /**< the suffix, with its dot */
    sound_file_format format;   /**< the input format it hints at */
} known_suffixes[] = {
    { ".wav", sf_wave }, { ".wave", sf_wave },
    { ".aif", sf_aiff }, { ".aiff", sf_aiff }, { ".aifc", sf_aiff },
    { ".raw", sf_raw }, { ".pcm", sf_unknown },
    { ".mp1", sf_mp123 }, { ".mp2", sf_mp123 }, { ".mp3", sf_mp123 }, { ".mpg", sf_mp123 },
    { ".mpa", sf_unknown },
    { ".ogg", sf_ogg },
    { ".cda", sf_unknown }, { ".au", sf_unknown }, { ".snd", sf_unknown },
    { ".flac", sf_unknown }, { ".wv", sf_unknown }, { ".ofr", sf_unknown },
    { ".tak", sf_unknown }, { ".mp4", sf_unknown }, { ".m4a", sf_unknown },
    { ".w64", sf_unknown }
};

/**
 * @internal
 * @brief Returns the input format that the suffix of a file name hints at.
 *
 * The frontends use only the suffix. The header parsers of init_infile()
 * still decide the format of a file that has one.
 *
 * @param path  the file name.
 * @return the format, or @c sf_unknown when the suffix is not known or does
 *         not hint at a format.
 */
sound_file_format
frontend_classify_suffix(const char *path)
{
    char const *suffix;
    size_t  i;

    if (path == NULL)
        return sf_unknown;
    (void) scanBasename(path, NULL, &suffix);
    for (i = 0; i < dimension_of(known_suffixes); ++i) {
        if (local_strcasecmp(suffix, known_suffixes[i].suffix) == 0)
            return known_suffixes[i].format;
    }
    return sf_unknown;
}

static 
int isCommonSuffix(char const* s_ext)
{
    size_t i;
    for (i = 0; i < dimension_of(known_suffixes); ++i) {
        if (local_strcasecmp(s_ext, known_suffixes[i].suffix) == 0) {
            return 1;
        }
    }
    return 0;
}


/**
 * @internal
 * @brief Builds the name of an output file from the name of its input file.
 *
 * The name is the output directory, or the directory of the input file if
 * there is none, then the base name of the input file, then its suffix, then
 * @p s_ext. A suffix in #known_suffixes is left out, except when there is no
 * output directory and the suffix is @p s_ext.
 *
 * @param inPath        the name of the input file.
 * @param outDir        the output directory, or NULL or "" for none.
 * @param s_ext         the suffix of the output file, with its dot.
 * @param outPath       receives the name, NUL-terminated.
 * @param outPath_size  the size of @p outPath, in bytes.
 * @return 0 on success. 1 if the name does not fit into @p outPath. Then the
 *         function prints an error, and @p outPath holds a part of the name.
 */
int generateOutPath(char const* inPath, char const* outDir, char const* s_ext, char* outPath,
                    size_t outPath_size)
{
    size_t i = 0;
    int out_dir_used = 0;

    if (outDir != 0 && outDir[0] != 0) {
        out_dir_used = 1;
        while (*outDir) {
            outPath[i++] = *outDir++;
            if (i >= outPath_size) {
                goto err_generateOutPath;
            }
        }
        if (i > 0 && !is_slash(outPath[i-1])) {
            outPath[i++] = SLASH;
            if (i >= outPath_size) {
                goto err_generateOutPath;
            }
        }
        outPath[i] = 0;
    }
    else {
        char const* pa;
        char const* pb;
        size_t j, n = scanPath(inPath, &pa, &pb);
        if (i+n >= outPath_size) {
            goto err_generateOutPath;
        }
        for (j = 0; j < n; ++j) {
            outPath[i++] = pa[j];
        }
        if (n > 0) {
            outPath[i++] = SLASH;
            if (i >= outPath_size) {
                goto err_generateOutPath;
            }
        }
        outPath[i] = 0;
    }
    {
        int replace_suffix = 0;
        char const* na;
        char const* nb;
        size_t j, n = scanBasename(inPath, &na, &nb);
        if (i+n >= outPath_size) {
            goto err_generateOutPath;
        }
        for (j = 0; j < n; ++j) {
            outPath[i++] = na[j];
        }
        outPath[i] = 0;
        if (isCommonSuffix(nb) == 1) {
            replace_suffix = 1;
            if (out_dir_used == 0) {
                if (local_strcasecmp(nb, s_ext) == 0) {
                    replace_suffix = 0;
                }
            }
        }
        if (replace_suffix == 0) {
            while (*nb) {
                outPath[i++] = *nb++;
                if (i >= outPath_size) {
                    goto err_generateOutPath;
                }
            }
            outPath[i] = 0;
        }
    }
    {
        size_t const ext_n = lame_strnlen(s_ext, outPath_size);
        if (ext_n >= outPath_size - i) {
            goto err_generateOutPath;
        }
        snprintf(outPath + i, outPath_size - i, "%s", s_ext);
    }
    return 0;
err_generateOutPath:
    error_printf( "error: output file name too long\n" );
    return 1;
}


static int
set_id3_albumart(lame_t gfp, char const* file_name)
{
    int ret = -1;
    FILE *fpi = 0;

    if (file_name == 0) {
        return 0;
    }
    fpi = lame_fopen(file_name, "rb");
    if (!fpi) {
        ret = 1;
    }
    else {
        char *albumart = 0;
        long end = -1;

        /* A pipe, or a file too large for a long, has no size to read. */
        if (fseek(fpi, 0, SEEK_END) == 0)
            end = ftell(fpi);
        if (end < 0 || fseek(fpi, 0, SEEK_SET) != 0) {
            ret = 5;
        }
        else {
            size_t const size = (size_t) end;

            albumart = (char *)malloc(size);
            if (!albumart) {
                ret = 2;
            }
            else {
                if (fread(albumart, 1, size, fpi) != size) {
                    ret = 3;
                }
                else {
                    ret = id3tag_set_albumart(gfp, albumart, size) ? 4 : 0;
                }
                free(albumart);
            }
        }
        fclose(fpi);
    }
    switch (ret) {
    case 1: error_printf("Could not find: '%s'.\n", file_name); break;
    case 2: error_printf("Insufficient memory for reading the albumart.\n"); break;
    case 3: error_printf("Read error: '%s'.\n", file_name); break;
    case 4: error_printf("Unsupported image: '%s'.\nSpecify JPEG/PNG/GIF image\n", file_name); break;
    case 5: error_printf("Cannot read the album art from '%s': its size is not known.\n", file_name); break;
    default: break;
    }
    return ret;
}


enum ID3TAG_MODE 
{ ID3TAG_MODE_DEFAULT
, ID3TAG_MODE_V1_ONLY
, ID3TAG_MODE_V2_ONLY
};

static int dev_only_with_arg(char const* str, char const* token, char const* nextArg, int* argIgnored, int* argUsed)
{
    if (0 != local_strcasecmp(token,str)) return 0;
    *argUsed = 1;
    if (internal_opts_enabled) return 1;
    *argIgnored = 1;
    error_printf("WARNING: ignoring developer-only switch --%s %s\n", token, nextArg);
    return 0;
}

static int dev_only_without_arg(char const* str, char const* token, int* argIgnored)
{
    if (0 != local_strcasecmp(token,str)) return 0;
    if (internal_opts_enabled) return 1;
    *argIgnored = 1;
    error_printf("WARNING: ignoring developer-only switch --%s\n", token);
    return 0;
}


/* --vector <name>.  The library matches the name strictly, so whatever the
   user typed is lower-cased first.

   A rejected name ends the run rather than falling back: the option exists to
   pin an encode to one set of routines, and an encode that quietly used a
   different set would answer a question nobody asked. */
static int
set_vector_routines(lame_global_flags * gfp, const char *name)
{
    char    lower[VECTOR_NAME_MAX];
    size_t  i;
    int     rc;

    for (i = 0; i + 1 < sizeof lower && name[i] != '\0'; ++i)
        lower[i] = (char) tolower((unsigned char) name[i]);
    lower[i] = '\0';

    rc = lame_set_vector_routines(gfp, lower);
    if (rc == 0)
        return 0;

    switch (rc) {
    case -3:
        error_printf("Error: this build has no '%s' vector routines.\n", lower);
        break;
    case -4:
        error_printf("Error: this processor cannot run the '%s' vector routines.\n", lower);
        break;
    default:
        error_printf("Error: '%s' is not a set of vector routines.\n", lower);
        break;
    }
    {
        char    choices[VECTOR_CHOICES_MAX];

        error_printf("       this build offers: %s\n", vector_choices(choices, sizeof choices));
    }
    return -1;
}

/**
 * Copies an input or output file name from the command line into a buffer of
 * PATH_MAX+1 bytes. The copy always ends with a NUL.
 *
 * @param src  the file name, NUL-terminated.
 * @param dst  a buffer of at least PATH_MAX+1 bytes. On success, it contains a
 *             NUL-terminated copy of @p src. On failure, it is not changed.
 * @return 0 on success. -1 if @p src is PATH_MAX bytes or longer. Then the
 *         function prints an error with the file name.
 */
static int
set_path_arg(char const *const src, char *const dst)
{
    int const arg_n = (int)lame_strnlen(src, PATH_MAX);
    if (arg_n >= PATH_MAX) {
        error_printf("input/output file name too long (limit %d): %s\n",
                     PATH_MAX, src);
        return -1;
    }
    strncpy(dst, src, PATH_MAX);
    dst[PATH_MAX] = '\0';
    return 0;
}


/**
 * @internal
 * @brief The settings of one parse_args_() run that an option leaves for a later
 *        option or for the checks after the last one.
 */
typedef struct {
    int     input_file;        /**< 1 when an input file name was given */
    int     autoconvert;       /**< -a: the stereo input is encoded as mono */
    int     nogap;             /**< --nogap: the file names are nogap inputs */
    int     nogap_tags;        /**< 1 to write VBR tags in nogap mode */
    int     count_nogap;       /**< the number of nogap input files */
    int     noreplaygain;      /**< the user switched ReplayGain off */
    int     vector_selected;   /**< --vector was given; it wins over --noasm */
    int     noasm_none;        /**< --noasm sse was given; nothing may raise it */
    int     id3tag_mode;       /**< which ID3 versions are written, ID3TAG_MODE */
    int     ignore_tag_errors; /**< errors in tag values are ignored */
    enum TextEncoding id3_tenc; /**< the text encoding of the tag options */
} parse_state;

/** @internal @brief What an option handler did with the option it was given. */
typedef enum {
    OPT_NOT_MINE,               /**< the option belongs to another handler */
    OPT_DONE,                   /**< the option is set; the parse goes on */
    OPT_STOP_OK,                /**< the parse stops without an error */
    OPT_STOP_ERROR              /**< the parse stops with an error */
} option_result;

/** @internal @brief An option without an argument that sets an int setting. */
typedef struct {
    char const *name;           /**< the option, without the two dashes */
    int    *field;              /**< the setting */
    int     value;              /**< the value the option gives it */
} int_flag_option;

/**
 * @internal
 * @brief Sets the setting of the row of @p table that is named @p token.
 *
 * @param table  the rows.
 * @param n      the number of rows.
 * @param token  the option, without the two dashes.
 * @return 1 when a row has that name, 0 otherwise.
 */
static int
set_int_flag(int_flag_option const *table, size_t n, char const *token)
{
    size_t  k;

    for (k = 0; k < n; ++k) {
        if (0 == local_strcasecmp(token, table[k].name)) {
            *table[k].field = table[k].value;
            return 1;
        }
    }
    return 0;
}

/** The input and output options that set one int setting. */
static int_flag_option const io_flags[] = {
    { "signed", &frontend_config.raw_pcm.in_signed, 1 },
    { "unsigned", &frontend_config.raw_pcm.in_signed, 0 },
    { "flush", &frontend_config.writer.flush_write, 1 },
    { "preserve-modtime", &frontend_config.writer.preserve_modtime, 1 },
    { "replaygain-id3v2", &frontend_config.writer.replaygain_id3v2, 1 },
    { "swap-channel", &frontend_config.reader.swap_channel, 1 },
    { "ignorelength", &frontend_config.reader.ignorewavlength, 1 }
};

/** The options for the messages on the screen that set one int setting. */
static int_flag_option const info_flags[] = {
    { "nohist", &frontend_config.ui_config.brhist, 0 },
    /* on a scale from 1 to 10 be very silent */
    { "quiet", &frontend_config.ui_config.silent, 10 },
    { "silent", &frontend_config.ui_config.silent, 9 },
    { "brief", &frontend_config.ui_config.silent, -5 },  /* print few info on screen */
    { "verbose", &frontend_config.ui_config.silent, -10 } /* print a lot on screen */
};

/** @internal @brief An ID3 option that sets one text field of the tag. */
typedef struct {
    char const *name;           /**< the option, without the two dashes */
    int     field;              /**< the field, as the letter id3_tag() takes */
} tag_text_option;

/** The ID3 options that set one text field. */
static tag_text_option const tag_text_options[] = {
    { "tt", 't' }, { "ta", 'a' }, { "tl", 'l' }, { "ty", 'y' }, { "tc", 'c' }
};

/** @internal @brief A developer option without an argument that calls one setter. */
typedef struct {
    char const *name;           /**< the option, without the two dashes */
    int     (CDECL * setter) (lame_global_flags *, int); /**< the setter, NULL in a build without
                                                      the developer options */
    int     value;              /**< the value the option passes */
} dev_flag_option;

#if (INTERNAL_OPTS!=0)
# define DEV_SETTER(f) f
#else
# define DEV_SETTER(f) NULL
#endif

/** The developer options without an argument that call one setter with a constant. */
static dev_flag_option const dev_flags[] = {
    { "noshort", lame_set_no_short_blocks, 1 },
    { "short", lame_set_no_short_blocks, 0 },
    { "allshort", lame_set_force_short_blocks, 1 },
    { "notemp", lame_set_useTemporal, 0 },
    { "no-preset-tune", DEV_SETTER(lame_set_preset_notune), 0 },
    { "sfscale", DEV_SETTER(lame_set_sfscale), 1 },
    { "noath", lame_set_noATH, 1 },
    { "athonly", lame_set_ATHonly, 1 },
    { "athshort", lame_set_ATHshort, 1 }
};

/**
 * @internal
 * @brief Parses the options that choose how the audio is encoded.
 *
 * @param gfp          the encoder instance.
 * @param st           the state of the parse.
 * @param token        the option, without the two dashes.
 * @param nextArg      the next word of the command line, or "".
 * @param argUsed      receives how many words after the option it uses.
 * @return OPT_NOT_MINE for an option of another group, else what the parse does next.
 */
static option_result
parse_encoding_options(lame_t gfp, parse_state * st, char const *token, char *nextArg, int *argUsed)
{
    double  double_value = 0;
    int     int_value = 0;

    if (0 == local_strcasecmp(token, "resample")) {
        *argUsed = getDoubleValue(token, nextArg, &double_value);
        if (*argUsed)
            (void) lame_set_out_samplerate(gfp, resample_rate(double_value));
        return OPT_DONE;
    }
    if (0 == local_strcasecmp(token, "vbr-old")) {
        lame_set_VBR(gfp, vbr_rh);
        return OPT_DONE;
    }
    if (0 == local_strcasecmp(token, "vbr-new")) {
        lame_set_VBR(gfp, vbr_mt);
        return OPT_DONE;
    }
    if (0 == local_strcasecmp(token, "vbr-mtrh")) {
        lame_set_VBR(gfp, vbr_mtrh);
        return OPT_DONE;
    }
    if (0 == local_strcasecmp(token, "cbr")) {
        lame_set_VBR(gfp, vbr_off);
        return OPT_DONE;
    }
    if (0 == local_strcasecmp(token, "abr")) {
        /* values larger than 8000 are bps (like Fraunhofer), so it's strange to get 320000 bps MP3 when specifying 8000 bps MP3 */
        *argUsed = getIntValue(token, nextArg, &int_value);
        if (*argUsed) {
            if (int_value >= 8000) {
                int_value = (int_value + 500) / 1000;
            }
            if (int_value > 320) {
                int_value = 320;
            }
            if (int_value < 8) {
                int_value = 8;
            }
            lame_set_VBR(gfp, vbr_abr);
            lame_set_VBR_mean_bitrate_kbps(gfp, int_value);
        }
        return OPT_DONE;
    }
    if (0 == local_strcasecmp(token, "r3mix")) {
        lame_set_preset(gfp, R3MIX);
        return OPT_DONE;
    }
    if (0 == local_strcasecmp(token, "nores")) {
        lame_set_disable_reservoir(gfp, 1);
        return OPT_DONE;
    }
    if (0 == local_strcasecmp(token, "strictly-enforce-ISO")) {
        lame_set_strict_ISO(gfp, MDB_STRICT_ISO);
        return OPT_DONE;
    }
    if (0 == local_strcasecmp(token, "buffer-constraint")) {
        *argUsed = 1;
        if (strcmp(nextArg, "default") == 0)
            (void) lame_set_strict_ISO(gfp, MDB_DEFAULT);
        else if (strcmp(nextArg, "strict") == 0)
            (void) lame_set_strict_ISO(gfp, MDB_STRICT_ISO);
        else if (strcmp(nextArg, "maximum") == 0)
            (void) lame_set_strict_ISO(gfp, MDB_MAXIMUM);
        else {
            error_printf("unknown buffer constraint '%s'\n", nextArg);
            return OPT_STOP_ERROR;
        }
        return OPT_DONE;
    }
    if (0 == local_strcasecmp(token, "scale")) {
        *argUsed = getDoubleValue(token, nextArg, &double_value);
        if (*argUsed && lame_set_scale(gfp, (float) double_value) != 0)
            refuse_number(token, nextArg);
        return OPT_DONE;
    }
    if (0 == local_strcasecmp(token, "scale-l")) {
        *argUsed = getDoubleValue(token, nextArg, &double_value);
        if (*argUsed && lame_set_scale_left(gfp, (float) double_value) != 0)
            refuse_number(token, nextArg);
        return OPT_DONE;
    }
    if (0 == local_strcasecmp(token, "scale-r")) {
        *argUsed = getDoubleValue(token, nextArg, &double_value);
        if (*argUsed && lame_set_scale_right(gfp, (float) double_value) != 0)
            refuse_number(token, nextArg);
        return OPT_DONE;
    }
    if (0 == local_strcasecmp(token, "gain")) {
        *argUsed = getDoubleValue(token, nextArg, &double_value);
        if (*argUsed) {
            double gain = double_value;
            gain = gain > -20.f ? gain : -20.f;
            gain = gain < 12.f ? gain : 12.f;
            gain = pow(10.f, gain*0.05);
            (void) lame_set_scale(gfp, (float) gain);
        }
        return OPT_DONE;
    }
    if (0 == local_strcasecmp(token, "vector")) {
        *argUsed = 1;
        if (set_vector_routines(gfp, nextArg) != 0)
            return OPT_STOP_ERROR;
        st->vector_selected = 1;
        return OPT_DONE;
    }
    if (0 == local_strcasecmp(token, "noasm")) {
        *argUsed = 1;
        if (local_strcasecmp(nextArg, "sse") == 0) {
            error_printf("WARNING: --noasm sse is deprecated,"
                         " use --vector none instead\n");
            if (!st->vector_selected) {
                (void) lame_set_vector_routines(gfp, "none");
                st->noasm_none = 1;
            }
        }
        else if (local_strcasecmp(nextArg, "avx2") == 0) {
            error_printf("WARNING: --noasm avx2 is deprecated,"
                         " use --vector sse2 instead\n");
            /* The option could be repeated to turn off more than
               one tier, so a second mapping may only lower the
               selection: "sse" already asked for none. */
            if (!st->vector_selected && !st->noasm_none)
                (void) lame_set_vector_routines(gfp, "sse2");
        }
        else {
            error_printf("WARNING: --noasm %s is deprecated and selects nothing;"
                         " see --vector\n", nextArg);
        }
        return OPT_DONE;
    }
    if (0 == local_strcasecmp(token, "freeformat")) {
        lame_set_free_format(gfp, 1);
        return OPT_DONE;
    }
    if (0 == local_strcasecmp(token, "replaygain-fast")) {
        lame_set_findReplayGain(gfp, 1);
        return OPT_DONE;
    }
#ifdef HAVE_MPG123
    if (0 == local_strcasecmp(token, "replaygain-accurate")) {
        lame_set_decode_on_the_fly(gfp, 1);
        lame_set_findReplayGain(gfp, 1);
        return OPT_DONE;
    }
#endif
    if (0 == local_strcasecmp(token, "noreplaygain")) {
        st->noreplaygain = 1;
        lame_set_findReplayGain(gfp, 0);
        return OPT_DONE;
    }
#ifdef HAVE_MPG123
    if (0 == local_strcasecmp(token, "clipdetect")) {
        frontend_config.ui_config.print_clipping_info = 1;
        lame_set_decode_on_the_fly(gfp, 1);
        return OPT_DONE;
    }
#endif
    if (0 == local_strcasecmp(token, "comp")) {
        *argUsed = getDoubleValue(token, nextArg, &double_value);
        if (*argUsed) {
            if (double_value < 1.0) {
                error_printf("Must specify compression ratio >= 1.0\n");
                return OPT_STOP_ERROR;
            }
            else {
                lame_set_compression_ratio(gfp, (float) double_value);
            }
        }
        return OPT_DONE;
    }
    if (0 == local_strcasecmp(token, "athaa-sensitivity")) {
        *argUsed = getDoubleValue(token, nextArg, &double_value);
        if (*argUsed)
            lame_set_athaa_sensitivity(gfp, (float) double_value);
        return OPT_DONE;
    }
    return OPT_NOT_MINE;
}

/**
 * @internal
 * @brief Parses the lowpass and highpass filter options.
 *
 * A frequency from 0.001 to 50000 is accepted. A value below 50 for --lowpass,
 * and below 16 for the other three options, is in kHz; a larger one is in Hz.
 * A negative --lowpass or --highpass switches that filter off.
 *
 * @param gfp          the encoder instance.
 * @param token        the option, without the two dashes.
 * @param nextArg      the next word of the command line, or "".
 * @param argUsed      receives how many words after the option it uses.
 * @return OPT_NOT_MINE for an option of another group, else what the parse does next.
 */
static option_result
parse_filter_options(lame_t gfp, char const *token, char *nextArg, int *argUsed)
{
    double  double_value = 0;

    if (0 == local_strcasecmp(token, "lowpass")) {
        *argUsed = getDoubleValue(token, nextArg, &double_value);
        if (*argUsed) {
            if (double_value < 0) {
                lame_set_lowpassfreq(gfp, -1);
            }
            else {
                if (double_value < 0.001 || double_value > 50000.) {
                    error_printf("Must specify lowpass with --lowpass freq, freq >= 0.001 kHz\n");
                    return OPT_STOP_ERROR;
                }
                lame_set_lowpassfreq(gfp, (int) (double_value * (double_value < 50. ? 1.e3 : 1.e0) + 0.5));
            }
        }
        return OPT_DONE;
    }
    if (0 == local_strcasecmp(token, "lowpass-width")) {
        *argUsed = getDoubleValue(token, nextArg, &double_value);
        if (*argUsed) {
            if (double_value < 0.001 || double_value > 50000.) {
                error_printf
                    ("Must specify lowpass width with --lowpass-width freq, freq >= 0.001 kHz\n");
                return OPT_STOP_ERROR;
            }
            lame_set_lowpasswidth(gfp, (int) (double_value * (double_value < 16. ? 1.e3 : 1.e0) + 0.5));
        }
        return OPT_DONE;
    }
    if (0 == local_strcasecmp(token, "highpass")) {
        *argUsed = getDoubleValue(token, nextArg, &double_value);
        if (*argUsed) {
            if (double_value < 0.0) {
                lame_set_highpassfreq(gfp, -1);
            }
            else {
                if (double_value < 0.001 || double_value > 50000.) {
                    error_printf("Must specify highpass with --highpass freq, freq >= 0.001 kHz\n");
                    return OPT_STOP_ERROR;
                }
                lame_set_highpassfreq(gfp, (int) (double_value * (double_value < 16. ? 1.e3 : 1.e0) + 0.5));
            }
        }
        return OPT_DONE;
    }
    if (0 == local_strcasecmp(token, "highpass-width")) {
        *argUsed = getDoubleValue(token, nextArg, &double_value);
        if (*argUsed) {
            if (double_value < 0.001 || double_value > 50000.) {
                error_printf
                    ("Must specify highpass width with --highpass-width freq, freq >= 0.001 kHz\n");
                return OPT_STOP_ERROR;
            }
            lame_set_highpasswidth(gfp, (int) (double_value * (double_value < 16. ? 1.e3 : 1.e0) + 0.5));
        }
        return OPT_DONE;
    }
    return OPT_NOT_MINE;
}

/**
 * @internal
 * @brief Parses the options for the input and output files.
 *
 * @param gfp          the encoder instance.
 * @param st           the state of the parse.
 * @param token        the option, without the two dashes.
 * @param nextArg      the next word of the command line, or "".
 * @param outDir       receives the output directory, PATH_MAX+1 bytes.
 * @param ProgramName  the name of the program, for messages.
 * @param argUsed      receives how many words after the option it uses.
 * @return OPT_NOT_MINE for an option of another group, else what the parse does next.
 */
static option_result
parse_io_options(lame_t gfp, parse_state * st, char const *token, char *nextArg, char *const outDir,
                 char const *ProgramName, int *argUsed)
{
    int     int_value = 0;

    if (set_int_flag(io_flags, dimension_of(io_flags), token))
        return OPT_DONE;
    if (0 == local_strcasecmp(token, "bitwidth")) {
        *argUsed = getIntValue(token, nextArg, &int_value);
        if (*argUsed)
            frontend_config.raw_pcm.in_bitwidth = int_value;
        return OPT_DONE;
    }
    if (0 == local_strcasecmp(token, "little-endian")) {
        frontend_config.raw_pcm.in_endian = ByteOrderLittleEndian;
        return OPT_DONE;
    }
    if (0 == local_strcasecmp(token, "big-endian")) {
        frontend_config.raw_pcm.in_endian = ByteOrderBigEndian;
        return OPT_DONE;
    }
#ifdef HAVE_MPG123
    if (0 == local_strcasecmp(token, "mp1input")) {
        frontend_config.reader.input_format = sf_mp1;
        return OPT_DONE;
    }
    if (0 == local_strcasecmp(token, "mp2input")) {
        frontend_config.reader.input_format = sf_mp2;
        return OPT_DONE;
    }
    if (0 == local_strcasecmp(token, "mp3input")) {
        frontend_config.reader.input_format = sf_mp3;
        return OPT_DONE;
    }
#endif
    if (0 == local_strcasecmp(token, "decode")) {
        (void) lame_set_decode_only(gfp, 1);
        return OPT_DONE;
    }
    if (0 == local_strcasecmp(token, "decode-mp3delay")) {
        *argUsed = getIntValue(token, nextArg, &int_value);
        if (*argUsed) {
            frontend_config.decoder.mp3_delay = int_value;
            frontend_config.decoder.mp3_delay_set = 1;
        }
        return OPT_DONE;
    }
    if (0 == local_strcasecmp(token, "nogaptags")) {
        st->nogap_tags = 1;
        return OPT_DONE;
    }
    if (0 == local_strcasecmp(token, "nogapout")) {
        int const arg_n = (int)lame_strnlen(nextArg, PATH_MAX);
        if (arg_n >= PATH_MAX) {
            error_printf("%s: %s argument length (%d) exceeds limit (%d)\n", ProgramName, token, arg_n, PATH_MAX);
            return OPT_STOP_ERROR;
        }
        strncpy(outDir, nextArg, PATH_MAX);
        outDir[PATH_MAX] = '\0';
        *argUsed = 1;
        return OPT_DONE;
    }
    if (0 == local_strcasecmp(token, "out-dir")) {
        int const arg_n = (int)lame_strnlen(nextArg, PATH_MAX);
        if (arg_n >= PATH_MAX) {
            error_printf("%s: %s argument length (%d) exceeds limit (%d)\n", ProgramName, token, arg_n, PATH_MAX);
            return OPT_STOP_ERROR;
        }
        strncpy(outDir, nextArg, PATH_MAX);
        outDir[PATH_MAX] = '\0';
        *argUsed = 1;
        return OPT_DONE;
    }
    if (0 == local_strcasecmp(token, "nogap")) {
        st->nogap = 1;
        return OPT_DONE;
    }
    return OPT_NOT_MINE;
}

/**
 * @internal
 * @brief Parses the ID3 tag options.
 *
 * @param gfp          the encoder instance.
 * @param st           the state of the parse.
 * @param token        the option, without the two dashes.
 * @param nextArg      the next word of the command line, or "".
 * @param argUsed      receives how many words after the option it uses.
 * @return OPT_NOT_MINE for an option of another group, else what the parse does next.
 */
static option_result
parse_id3_options(lame_t gfp, parse_state * st, char const *token, char *nextArg, int *argUsed)
{
    size_t  k;
    int     int_value = 0;

#ifdef ID3TAGS_EXTENDED
    if (0 == local_strcasecmp(token, "id3v2-utf16") || 0 == local_strcasecmp(token, "id3v2-ucs2")) {
        /* id3v2-ucs2 for compatibility only */
        st->id3_tenc = TENC_UTF16;
        id3tag_add_v2(gfp);
        return OPT_DONE;
    }
    if (0 == local_strcasecmp(token, "id3v2-utf8")) {
        st->id3_tenc = TENC_UTF8;
        id3tag_add_v2_4_UTF8(gfp);
        return OPT_DONE;
    }
    if (0 == local_strcasecmp(token, "id3v2-latin1")) {
        st->id3_tenc = TENC_LATIN1;
        id3tag_add_v2(gfp);
        return OPT_DONE;
    }
#endif
    for (k = 0; k < dimension_of(tag_text_options); ++k) {
        if (0 == local_strcasecmp(token, tag_text_options[k].name)) {
            *argUsed = 1;
            id3_tag(gfp, tag_text_options[k].field, st->id3_tenc, nextArg);
            return OPT_DONE;
        }
    }
    if (0 == local_strcasecmp(token, "tn")) {
        int ret = id3_tag(gfp, 'n', st->id3_tenc, nextArg);
        *argUsed = 1;
        if (ret != 0) {
            if (0 == st->ignore_tag_errors) {
                if (st->id3tag_mode == ID3TAG_MODE_V1_ONLY) {
                    if (frontend_config.ui_config.silent < 9) {
                        error_printf("The track number has to be between 1 and 255 for ID3v1.\n");
                    }
                    return OPT_STOP_ERROR;
                }
                else if (st->id3tag_mode == ID3TAG_MODE_V2_ONLY) {
                    /* an ID3v2 tag takes any track number */
                }
                else {
                    if (frontend_config.ui_config.silent < 9) {
                        error_printf("The track number has to be between 1 and 255 for ID3v1, ignored for ID3v1.\n");
                    }
                }
            }
        }
        return OPT_DONE;
    }
    if (0 == local_strcasecmp(token, "tg")) {
        int ret = 0;
        *argUsed = 1;
        if (nextArg != 0 && strlen(nextArg) > 0) {
            ret = id3_tag(gfp, 'g', st->id3_tenc, nextArg);
        }
        if (ret != 0) {
            if (0 == st->ignore_tag_errors) {
                if (ret == -1) {
                    error_printf("Unknown ID3v1 genre number: '%s'.\n", nextArg);
                    return OPT_STOP_ERROR;
                }
                else if (ret == -2) {
                    if (st->id3tag_mode == ID3TAG_MODE_V1_ONLY) {
                        error_printf("Unknown ID3v1 genre: '%s'.\n", nextArg);
                        return OPT_STOP_ERROR;
                    }
                    else if (st->id3tag_mode == ID3TAG_MODE_V2_ONLY) {
                        /* an ID3v2 tag keeps the genre as text */
                    }
                    else {
                        if (frontend_config.ui_config.silent < 9) {
                            error_printf("Unknown ID3v1 genre: '%s'.  Setting ID3v1 genre to 'Other'\n", nextArg);
                        }
                    }
                }
                else {
                    if (frontend_config.ui_config.silent < 10)
                        error_printf("Internal error.\n");
                    return OPT_STOP_ERROR;
                }
            }
        }
        return OPT_DONE;
    }
    if (0 == local_strcasecmp(token, "tv")) {
        *argUsed = 1;
        if (id3_tag(gfp, 'v', st->id3_tenc, nextArg)) {
            if (frontend_config.ui_config.silent < 9) {
                error_printf("Invalid field value: '%s'. Ignored\n", nextArg);
            }
        }
        return OPT_DONE;
    }
    if (0 == local_strcasecmp(token, "ti")) {
        *argUsed = 1;
        if (set_id3_albumart(gfp, nextArg) != 0) {
            if (! st->ignore_tag_errors) {
                return OPT_STOP_ERROR;
            }
        }
        return OPT_DONE;
    }
    if (0 == local_strcasecmp(token, "ignore-tag-errors")) {
        st->ignore_tag_errors = 1;
        return OPT_DONE;
    }
    if (0 == local_strcasecmp(token, "add-id3v2")) {
        id3tag_add_v2(gfp);
        return OPT_DONE;
    }
    if (0 == local_strcasecmp(token, "id3v1-only")) {
        id3tag_v1_only(gfp);
        st->id3tag_mode = ID3TAG_MODE_V1_ONLY;
        return OPT_DONE;
    }
    if (0 == local_strcasecmp(token, "id3v2-only")) {
        id3tag_v2_only(gfp);
        st->id3tag_mode = ID3TAG_MODE_V2_ONLY;
        return OPT_DONE;
    }
    if (0 == local_strcasecmp(token, "space-id3v1")) {
        id3tag_space_v1(gfp);
        return OPT_DONE;
    }
    if (0 == local_strcasecmp(token, "pad-id3v2")) {
        id3tag_pad_v2(gfp);
        frontend_config.writer.id3v2_padding = 128;
        return OPT_DONE;
    }
    if (0 == local_strcasecmp(token, "pad-id3v2-size")) {
        *argUsed = getIntValue(token, nextArg, &int_value);
        if (*argUsed) {
            int_value = int_value <= LAME_MAXID3V2PADDING ? int_value : LAME_MAXID3V2PADDING;
            int_value = int_value >= 0      ? int_value : 0;
            id3tag_set_pad(gfp, int_value);
            frontend_config.writer.id3v2_padding = int_value;
        }
        return OPT_DONE;
    }
    if (0 == local_strcasecmp(token, "genre-list")) {
        id3tag_genre_list(genre_list_handler, NULL);
        return OPT_STOP_OK;
    }
    return OPT_NOT_MINE;
}

/**
 * @internal
 * @brief Parses the options for the messages on the screen and for help.
 *
 * @param gfp          the encoder instance.
 * @param token        the option, without the two dashes.
 * @param nextArg      the next word of the command line, or "".
 * @param ProgramName  the name of the program, for messages.
 * @param argUsed      receives how many words after the option it uses.
 * @return OPT_NOT_MINE for an option of another group, else what the parse does next.
 */
static option_result
parse_info_options(lame_t gfp, char const *token, char *nextArg, char const *ProgramName,
                   int *argUsed)
{
    double  double_value = 0;

    if (set_int_flag(info_flags, dimension_of(info_flags), token))
        return OPT_DONE;
#if defined(__OS2__) || defined(WIN32)
    if (0 == local_strcasecmp(token, "priority")) {
        int     int_value = 0;

        *argUsed = getIntValue(token, nextArg, &int_value);
        if (*argUsed)
            setProcessPriority(int_value);
        return OPT_DONE;
    }
#endif
    /* some more GNU-ish options could be added
     * brief         => few messages on screen (name, status report)
     * o/output file => specifies output filename
     * O             => stdout
     * i/input file  => specifies input filename
     * I             => stdin
     */
    if (0 == local_strcasecmp(token, "version") || 0 == local_strcasecmp(token, "license")) {
        print_license(stdout);
        return OPT_STOP_OK;
    }
    if (0 == local_strcasecmp(token, "help") || 0 == local_strcasecmp(token, "usage")) {
        if (0 == local_strncasecmp(nextArg, "id3", 3)) {
            help_id3tag(stdout);
        }
        else if (0 == local_strncasecmp(nextArg, "dev", 3)) {
            help_developer_switches(stdout);
        }
        else {
            short_help(gfp, stdout, ProgramName);
        }
        return OPT_STOP_OK;
    }
    if (0 == local_strcasecmp(token, "longhelp")) {
        long_help(gfp, stdout, ProgramName, 0 /* lessmode=NO */ );
        return OPT_STOP_OK;
    }
    if (0 == local_strcasecmp(token, "?")) {
#ifdef __unix__
        FILE   *fp = popen("less -Mqc", "w");
        long_help(gfp, fp, ProgramName, 0 /* lessmode=NO */ );
        pclose(fp);
#else
        long_help(gfp, stdout, ProgramName, 1 /* lessmode=YES */ );
#endif
        return OPT_STOP_OK;
    }
    if (0 == local_strcasecmp(token, "disptime")) {
        *argUsed = getDoubleValue(token, nextArg, &double_value);
        if (*argUsed)
            frontend_config.ui_config.update_interval = (float) double_value;
        return OPT_DONE;
    }
    return OPT_NOT_MINE;
}

/**
 * @internal
 * @brief Parses --preset and --alt-preset, which read one or more words.
 *
 * @param gfp          the encoder instance.
 * @param token        the option, without the two dashes.
 * @param nextArg      the next word of the command line, or "".
 * @param ProgramName  the name of the program, for messages.
 * @param argc         the number of words of the command line.
 * @param argv         the words of the command line.
 * @param i            the position of the option in @p argv.
 * @param argUsed      receives how many words after the option it uses.
 * @return OPT_NOT_MINE for another option, else what the parse does next.
 */
static option_result
parse_preset_option(lame_t gfp, char const *token, char *nextArg, char const *ProgramName, int argc,
                    char **argv, int i, int *argUsed)
{
    if (0 == local_strcasecmp(token, "preset") || 0 == local_strcasecmp(token, "alt-preset")) {
        int     fast = 0, cbr = 0;

        *argUsed = 1;
        while ((strcmp(nextArg, "fast") == 0) || (strcmp(nextArg, "cbr") == 0)) {

            if ((strcmp(nextArg, "fast") == 0) && (fast < 1))
                fast = 1;
            if ((strcmp(nextArg, "cbr") == 0) && (cbr < 1))
                cbr = 1;

            (*argUsed)++;
            nextArg = i + *argUsed < argc ? argv[i + *argUsed] : "";
        }

        {
            int const ret = presets_set(gfp, fast, cbr, nextArg, ProgramName);
            if (ret < 0)
                return ret == -2 ? OPT_STOP_OK : OPT_STOP_ERROR;
        }
        return OPT_DONE;
    }
    return OPT_NOT_MINE;
}

/**
 * @internal
 * @brief Parses the developer options. A build without them ignores them
 *        with a warning.
 *
 * @param gfp          the encoder instance.
 * @param token        the option, without the two dashes.
 * @param nextArg      the next word of the command line, or "".
 * @param argUsed      receives how many words after the option it uses.
 * @return OPT_NOT_MINE for an option of another group, else what the parse does next.
 */
static option_result
parse_developer_options(lame_t gfp, char const *token, char *nextArg, int *argUsed)
{
    double  double_value = 0;
    int     int_value = 0;
    int     argIgnored = 0;
    size_t  row;

    for (row = 0; row < dimension_of(dev_flags); ++row) {
        if (dev_only_without_arg(dev_flags[row].name, token, &argIgnored)) {
            (void) dev_flags[row].setter(gfp, dev_flags[row].value);
            return OPT_DONE;
        }
    }
    if (dev_only_with_arg("interch", token, nextArg, &argIgnored, argUsed)) {
        *argUsed = getDoubleValue(token, nextArg, &double_value);
        if (*argUsed)
            (void) lame_set_interChRatio(gfp, (float) double_value);
        return OPT_DONE;
    }
    if (dev_only_with_arg("temporal-masking", token, nextArg, &argIgnored, argUsed)) {
        *argUsed = getIntValue(token, nextArg, &int_value);
        if (*argUsed)
            (void) lame_set_useTemporal(gfp, int_value ? 1 : 0);
        return OPT_DONE;
    }
    if (dev_only_without_arg("nspsytune", token, &argIgnored)) {
        ;
        return OPT_DONE;
    }
    if (dev_only_without_arg("nssafejoint", token, &argIgnored)) {
        lame_set_exp_nspsytune(gfp, lame_get_exp_nspsytune(gfp) | 2);
        return OPT_DONE;
    }
    if (dev_only_with_arg("nsmsfix", token, nextArg, &argIgnored, argUsed)) {
        *argUsed = getDoubleValue(token, nextArg, &double_value);
        if (*argUsed)
            (void) lame_set_msfix(gfp, double_value);
        return OPT_DONE;
    }
    if (dev_only_with_arg("ns-bass", token, nextArg, &argIgnored, argUsed)) {
        *argUsed = getDoubleValue(token, nextArg, &double_value);
        if (*argUsed) {
            int     k = (int) (double_value * 4);
            if (k < -32)
                k = -32;
            if (k > 31)
                k = 31;
            if (k < 0)
                k += 64;
            lame_set_exp_nspsytune(gfp, lame_get_exp_nspsytune(gfp) | (k << 2));
        }
        return OPT_DONE;
    }
    if (dev_only_with_arg("ns-alto", token, nextArg, &argIgnored, argUsed)) {
        *argUsed = getDoubleValue(token, nextArg, &double_value);
        if (*argUsed) {
            int     k = (int) (double_value * 4);
            if (k < -32)
                k = -32;
            if (k > 31)
                k = 31;
            if (k < 0)
                k += 64;
            lame_set_exp_nspsytune(gfp, lame_get_exp_nspsytune(gfp) | (k << 8));
        }
        return OPT_DONE;
    }
    if (dev_only_with_arg("ns-treble", token, nextArg, &argIgnored, argUsed)) {
        *argUsed = getDoubleValue(token, nextArg, &double_value);
        if (*argUsed) {
            int     k = (int) (double_value * 4);
            if (k < -32)
                k = -32;
            if (k > 31)
                k = 31;
            if (k < 0)
                k += 64;
            lame_set_exp_nspsytune(gfp, lame_get_exp_nspsytune(gfp) | (k << 14));
        }
        return OPT_DONE;
    }
    if (dev_only_with_arg("ns-sfb21", token, nextArg, &argIgnored, argUsed)) {
        /*  to be compatible with Naoki's original code,
         *  ns-sfb21 specifies how to change ns-treble for sfb21 */
        *argUsed = getDoubleValue(token, nextArg, &double_value);
        if (*argUsed) {
            int     k = (int) (double_value * 4);
            if (k < -32)
                k = -32;
            if (k > 31)
                k = 31;
            if (k < 0)
                k += 64;
            lame_set_exp_nspsytune(gfp, lame_get_exp_nspsytune(gfp) | (k << 20));
        }
        return OPT_DONE;
    }
    if (dev_only_with_arg("tune", token, nextArg, &argIgnored, argUsed)) { /*without helptext */
        *argUsed = getDoubleValue(token, nextArg, &double_value);
        if (*argUsed)
            lame_set_tune(gfp, (float) double_value);
        return OPT_DONE;
    }
    if (dev_only_with_arg("shortthreshold", token, nextArg, &argIgnored, argUsed)) {
        float   x, y;
        int     n = sscanf(nextArg, "%f,%f", &x, &y);
        if (n == 1) {
            y = x;
        }
        (void) lame_set_short_threshold(gfp, x, y);
        return OPT_DONE;
    }
    if (dev_only_with_arg("maskingadjust", token, nextArg, &argIgnored, argUsed)) {
        /*without helptext */
        *argUsed = getDoubleValue(token, nextArg, &double_value);
        if (*argUsed)
            (void) lame_set_maskingadjust(gfp, (float) double_value);
        return OPT_DONE;
    }
    if (dev_only_with_arg("maskingadjustshort", token, nextArg, &argIgnored, argUsed)) {
        /*without helptext */
        *argUsed = getDoubleValue(token, nextArg, &double_value);
        if (*argUsed)
            (void) lame_set_maskingadjust_short(gfp, (float) double_value);
        return OPT_DONE;
    }
    if (dev_only_with_arg("athcurve", token, nextArg, &argIgnored, argUsed)) { /*without helptext */
        *argUsed = getDoubleValue(token, nextArg, &double_value);
        if (*argUsed)
            (void) lame_set_ATHcurve(gfp, (float) double_value);
        return OPT_DONE;
    }
    if (dev_only_with_arg("substep", token, nextArg, &argIgnored, argUsed)) {
        *argUsed = getIntValue(token, nextArg, &int_value);
        if (*argUsed)
            (void) lame_set_substep(gfp, int_value);
        return OPT_DONE;
    }
    if (dev_only_with_arg("sbgain", token, nextArg, &argIgnored, argUsed)) { /*without helptext */
        *argUsed = getIntValue(token, nextArg, &int_value);
        if (*argUsed)
            (void) lame_set_subblock_gain(gfp, int_value);
        return OPT_DONE;
    }
    if (dev_only_with_arg("athlower", token, nextArg, &argIgnored, argUsed)) {
        *argUsed = getDoubleValue(token, nextArg, &double_value);
        if (*argUsed)
            (void) lame_set_ATHlower(gfp, (float) double_value);
        return OPT_DONE;
    }
    if (dev_only_with_arg("athtype", token, nextArg, &argIgnored, argUsed)) {
        *argUsed = getIntValue(token, nextArg, &int_value);
        if (*argUsed)
            (void) lame_set_ATHtype(gfp, int_value);
        return OPT_DONE;
    }
    if (dev_only_with_arg("athaa-type", token, nextArg, &argIgnored, argUsed)) {
        /*  switch for developing, no DOCU */
        /* once was 1:Gaby, 2:Robert, 3:Jon, else:off */
        *argUsed = getIntValue(token, nextArg, &int_value);
        if (*argUsed)
            (void) lame_set_athaa_type(gfp, int_value); /* now: 0:off else:Jon */
        return OPT_DONE;
    }
    if (dev_only_with_arg("debug-file", token, nextArg, &argIgnored, argUsed)) {
        /* switch for developing, no DOCU */
        /* file name to print debug info into */
        set_debug_file(nextArg);
        return OPT_DONE;
    }
    return argIgnored ? OPT_DONE : OPT_NOT_MINE;
}

/**
 * @internal
 * @brief Parses one word of single-letter options, such as -h or -b128.
 *
 * @param gfp          the encoder instance.
 * @param st           the state of the parse.
 * @param token        the word, without the dash.
 * @param nextArg      the next word of the command line, or "".
 * @param ProgramName  the name of the program, for messages.
 * @param i            the position of the word in the command line. It moves
 *                     on when an option uses the next word.
 * @return what the parse does next.
 */
static option_result
parse_short_options(lame_t gfp, parse_state * st, char const *token, char const *nextArg,
                    char const *ProgramName, int *i)
{
    char    c;
    int     argUsed = 0;

    while ((c = *token++) != '\0') {
        double double_value = 0;
        int int_value = 0;
        char const *arg = *token ? token : nextArg;
        switch (c) {
        case 'm':
            argUsed = 1;

            switch (*arg) {
            case 's':
                (void) lame_set_mode(gfp, STEREO);
                break;
            case 'd':
                (void) lame_set_mode(gfp, DUAL_CHANNEL);
                break;
            case 'f':
                lame_set_force_ms(gfp, 1);
                (void) lame_set_mode(gfp, JOINT_STEREO);
                break;
            case 'j':
                lame_set_force_ms(gfp, 0);
                (void) lame_set_mode(gfp, JOINT_STEREO);
                break;
            case 'm':
                (void) lame_set_mode(gfp, MONO);
                break;
            case 'l':
                (void) lame_set_mode(gfp, MONO);
                (void) lame_set_scale_left(gfp, 2);
                (void) lame_set_scale_right(gfp, 0);
                break;
            case 'r':
                (void) lame_set_mode(gfp, MONO);
                (void) lame_set_scale_left(gfp, 0);
                (void) lame_set_scale_right(gfp, 2);
                break;
            case 'a': /* same as 'j' ??? */
                lame_set_force_ms(gfp, 0);
                (void) lame_set_mode(gfp, JOINT_STEREO);
                break;
            default:
                error_printf("%s: -m mode must be s/d/f/j/m/l/r not %s\n", ProgramName,
                             arg);
                return OPT_STOP_ERROR;
            }
            break;

        case 'V':
            argUsed = getDoubleValue("V", arg, &double_value);
            if (argUsed) {
                /* vbr_default is set in lame.h; -v below does the same */
                if (lame_get_VBR(gfp) == vbr_off)
                    lame_set_VBR(gfp, vbr_default);
                lame_set_VBR_quality(gfp, (float) double_value);
            }
            break;
        case 'v':
            if (lame_get_VBR(gfp) == vbr_off)
                lame_set_VBR(gfp, vbr_default);
            break;

        case 'q':
            argUsed = getIntValue("q", arg, &int_value);
            if (argUsed) 
                (void) lame_set_quality(gfp, int_value);
            break;
        case 'f':
            (void) lame_set_quality(gfp, 7);
            break;
        case 'h':
            (void) lame_set_quality(gfp, 2);
            break;

        case 's':
            argUsed = getDoubleValue("s", arg, &double_value);
            if (argUsed) {
                double_value = (int) (double_value * (double_value <= 192 ? 1.e3 : 1.e0) + 0.5);
                frontend_config.reader.input_samplerate = (int)double_value;
                (void) lame_set_in_samplerate(gfp, (int)double_value);
            }
            break;
        case 'b':
            argUsed = getIntValue("b", arg, &int_value);
            if (argUsed) {
                lame_set_brate(gfp, int_value);
                lame_set_VBR_min_bitrate_kbps(gfp, lame_get_brate(gfp));
            }
            break;
        case 'B':
            argUsed = getIntValue("B", arg, &int_value);
            if (argUsed) {
                lame_set_VBR_max_bitrate_kbps(gfp, int_value);
            }
            break;
        case 'F':
            lame_set_VBR_hard_min(gfp, 1);
            break;
        case 't': /* dont write VBR tag */
            (void) lame_set_bWriteVbrTag(gfp, 0);
            frontend_config.decoder.disable_wav_header = 1;
            break;
        case 'T': /* do write VBR tag */
            (void) lame_set_bWriteVbrTag(gfp, 1);
            st->nogap_tags = 1;
            frontend_config.decoder.disable_wav_header = 0;
            break;
        case 'r': /* force raw pcm input file */
#if defined(LIBSNDFILE)
            error_printf
                ("WARNING: libsndfile may ignore -r and perform fseek's on the input.\n"
                 "Compile without libsndfile if this is a problem.\n");
#endif
            frontend_config.reader.input_format = sf_raw;
            break;
        case 'x': /* force byte swapping */
            frontend_config.reader.swapbytes = 1;
            break;
        case 'p': /* (jo) error_protection: add crc16 information to stream */
            lame_set_error_protection(gfp, 1);
            break;
        case 'a': /* autoconvert input file from stereo to mono - for mono mp3 encoding */
            st->autoconvert = 1;
            (void) lame_set_mode(gfp, MONO);
            break;
        case 'd':   /*(void) lame_set_allow_diff_short( gfp, 1 ); */
        case 'k':   /*lame_set_lowpassfreq(gfp, -1);
                      lame_set_highpassfreq(gfp, -1); */
            error_printf("WARNING: -%c is obsolete.\n", c);
            break;
        case 'S':
            frontend_config.ui_config.silent = 5;
            break;
        case 'X':
            /*  experimental switch -X:
                the differnt types of quant compare are tough
                to communicate to endusers, so they shouldn't
                bother to toy around with them
             */
            {
                int     x, y;
                int     n = sscanf(arg, "%d,%d", &x, &y);
                if (n == 1) {
                    y = x;
                }
                argUsed = 1;
                if (internal_opts_enabled) {
                    lame_set_quant_comp(gfp, x);
                    lame_set_quant_comp_short(gfp, y);
                }
            }
            break;
        case 'Y':
            lame_set_experimentalY(gfp, 1);
            break;
        case 'Z':
            /*  experimental switch -Z:
             */
            {
                int     n = 1;
                argUsed = sscanf(arg, "%d", &n);
                /*if (internal_opts_enabled)*/
                {
                    lame_set_experimentalZ(gfp, n);
                }
            }
            break;
        case 'e':
            argUsed = 1;

            switch (*arg) {
            case 'n':
                lame_set_emphasis(gfp, 0);
                break;
            case '5':
                lame_set_emphasis(gfp, 1);
                break;
            case 'c':
                lame_set_emphasis(gfp, 3);
                break;
            default:
                error_printf("%s: -e emp must be n/5/c not %s\n", ProgramName, arg);
                return OPT_STOP_ERROR;
            }
            break;
        case 'c':
            lame_set_copyright(gfp, 1);
            break;
        case 'o':
            lame_set_original(gfp, 0);
            break;

        case '?':
            long_help(gfp, stdout, ProgramName, 0 /* LESSMODE=NO */ );
            return OPT_STOP_OK;

        default:
            error_printf("%s: unrecognized option -%c\n", ProgramName, c);
            return OPT_STOP_ERROR;
        }
        if (argUsed) {
            if (arg == token)
                token = ""; /* no more from token */
            else
                ++*i; /* skip arg we used */
            arg = "";
            argUsed = 0;
        }
    }
    return OPT_DONE;
}

static int
parse_args_(lame_global_flags * gfp, int argc, char **argv,
           char *const inPath, char *const outPath, char *const outDir,
           char **nogap_inPath, int *num_nogap)
{
    parse_state st;
    int     i;
    const char *ProgramName = argv[0];

    memset(&st, 0, sizeof(st));
    st.id3tag_mode = ID3TAG_MODE_DEFAULT;
#ifdef ID3TAGS_EXTENDED
    st.id3_tenc = TENC_UTF16;
#else
    st.id3_tenc = TENC_LATIN1;
#endif

#if defined(HAVE_ICONV) && defined(HAVE_LANGINFO_H)
    setlocale(LC_CTYPE, "");
#endif
    inPath[0] = '\0';
    outPath[0] = '\0';
    outDir[0] = '\0';
    frontend_config = frontend_config_defaults;
    id3tag_init(gfp);
    unusable_number = 0;

    /* process args */
    for (i = 0; ++i < argc;) {
        char   *token;
        int     argUsed;

        token = argv[i];
        if (*token++ == '-') {
            char   *nextArg = i + 1 < argc ? argv[i + 1] : "";
            argUsed = 0;
            if (!*token) { /* The user wants to use stdin and/or stdout. */
                st.input_file = 1;
                if (inPath[0] == '\0')
                    strncpy(inPath, argv[i], PATH_MAX + 1);
                else if (outPath[0] == '\0')
                    strncpy(outPath, argv[i], PATH_MAX + 1);
            }
            if (*token == '-') { /* GNU style */
                option_result result;

                token++;
                result = parse_encoding_options(gfp, &st, token, nextArg, &argUsed);
                if (result == OPT_NOT_MINE)
                    result = parse_filter_options(gfp, token, nextArg, &argUsed);
                if (result == OPT_NOT_MINE)
                    result = parse_io_options(gfp, &st, token, nextArg, outDir, ProgramName,
                                              &argUsed);
                if (result == OPT_NOT_MINE)
                    result = parse_id3_options(gfp, &st, token, nextArg, &argUsed);
                if (result == OPT_NOT_MINE)
                    result = parse_info_options(gfp, token, nextArg, ProgramName, &argUsed);
                if (result == OPT_NOT_MINE)
                    result = parse_preset_option(gfp, token, nextArg, ProgramName, argc, argv, i,
                                                 &argUsed);
                if (result == OPT_NOT_MINE)
                    result = parse_developer_options(gfp, token, nextArg, &argUsed);
                if (result == OPT_NOT_MINE) {
#if !defined(HAVE_MPG123)
                    if (is_decoder_option(token)) {
                        report_missing_decoder();
                        return -1;
                    }
#endif
                    error_printf("%s: unrecognized option --%s\n", ProgramName, token);
                    return -1;
                }
                if (result != OPT_DONE)
                    return result == OPT_STOP_OK ? -2 : -1;
                i += argUsed;
            }
            else {
                option_result const result =
                    parse_short_options(gfp, &st, token, nextArg, ProgramName, &i);
                if (result != OPT_DONE)
                    return result == OPT_STOP_OK ? -2 : -1;
            }
        }
        else {
            if (st.nogap) {
                if ((num_nogap != NULL) && (st.count_nogap < *num_nogap)) {
                    if (set_path_arg(argv[i], nogap_inPath[st.count_nogap]) < 0)
                        return -1;
                    ++st.count_nogap;
                    st.input_file = 1;
                }
                else {
                    /* sorry, calling program did not allocate enough space */
                    error_printf
                        ("Error: 'nogap option'.  Calling program does not allow nogap option, or\n"
                         "you have exceeded maximum number of input files for the nogap option\n");
                    if (num_nogap) {
                        *num_nogap = -1;
                    }
                    return -1;
                }
            }
            else {
                /* normal options:   inputfile  [outputfile], and
                   either one can be a '-' for stdin/stdout */
                if (inPath[0] == '\0') {
                    if (set_path_arg(argv[i], inPath) < 0)
                        return -1;
                    st.input_file = 1;
                }
                else {
                    if (outPath[0] == '\0') {
                        if (set_path_arg(argv[i], outPath) < 0)
                            return -1;
                    }
                    else {
                        error_printf("%s: excess arg %s\n", ProgramName, argv[i]);
                        return -1;
                    }
                }
            }
        }
    }                   /* loop over args */

    if (unusable_number)
        return -1;

    if (!st.input_file) {
        usage(Console_IO.Console_fp, ProgramName);
        return -1;
    }

    if (lame_get_decode_only(gfp) && st.count_nogap > 0) {
        error_printf("combination of nogap and decode not supported!\n");
        return -1;
    }

    /* With --decode, -x swaps the bytes of the output, not of the input */
    if (lame_get_decode_only(gfp)) {
        frontend_config.decoder.swapbytes = frontend_config.reader.swapbytes;
        frontend_config.reader.swapbytes = 0;
    }

    if (inPath[0] == '-') {
        if (frontend_config.ui_config.silent == 0) { /* user didn't overrule default behaviour */
            frontend_config.ui_config.silent = 1;
        }
    }
#ifdef WIN32
    else
        dosToLongFileName(inPath);
#endif

    /* With nogap the caller names each output file from outDir. */
    if (outPath[0] == '\0' && st.count_nogap == 0) { /* no explicit output file */
        if (inPath[0] == '-') {
            /* if input is stdin, default output is stdout */
            strcpy(outPath, "-");
        }
        else {
            char const* s_ext = lame_get_decode_only(gfp) ? ".wav" : ".mp3";
            if (generateOutPath(inPath, outDir, s_ext, outPath, PATH_MAX + 1) != 0) {
                return -1;
            }
        }
    }

    /* RG is enabled by default */
    if (!st.noreplaygain)
        lame_set_findReplayGain(gfp, 1);

    /* disable VBR tags with nogap unless the VBR tags are forced */
    if (st.nogap && lame_get_bWriteVbrTag(gfp) && st.nogap_tags == 0) {
        console_printf("Note: Disabling VBR Xing/Info tag since it interferes with --nogap\n");
        lame_set_bWriteVbrTag(gfp, 0);
    }

    /* some file options not allowed with stdout */
    if (outPath[0] == '-') {
        (void) lame_set_bWriteVbrTag(gfp, 0); /* turn off VBR tag */
    }

    /* if user did not explicitly specify input is mp3, check file name */
    if (frontend_config.reader.input_format == sf_unknown)
        frontend_config.reader.input_format = frontend_classify_suffix(inPath);

#if !defined(HAVE_MPG123)
    if (is_mpeg_file_format(frontend_config.reader.input_format)) {
        report_missing_decoder();
        return -1;
    }
#endif

    /* default guess for number of channels */
    if (st.autoconvert)
        (void) lame_set_num_channels(gfp, 2);
    else if (MONO == lame_get_mode(gfp))
        (void) lame_set_num_channels(gfp, 1);
    else
        (void) lame_set_num_channels(gfp, 2);

    if (lame_get_free_format(gfp)) {
        if (lame_get_brate(gfp) < 8 || lame_get_brate(gfp) > 640) {
            error_printf("For free format, specify a bitrate between 8 and 640 kbps\n");
            error_printf("with the -b <bitrate> option. The lowest one that can\n");
            error_printf("be used depends on the sample rate and the number of\n");
            error_printf("channels; the encoder reports it if the choice is too low.\n");
            return -1;
        }
    }
    if (num_nogap != NULL)
        *num_nogap = st.count_nogap;
    return 0;
}

static int
string_to_argv(char* str, char** argv, int N)
{
    int     argc = 0;
    if (str == 0) return argc;
    argv[argc++] = "lhama";
    for (;;) {
        int     quoted = 0;
        while (isspace((unsigned char) *str)) { /* skip blanks */
            ++str;
        }
        if (*str == '\"') { /* is quoted argument ? */
            quoted = 1;
            ++str;
        }
        if (*str == '\0') { /* end of string reached */
            break;
        }
        /* found beginning of some argument */
        if (argc < N) {
            argv[argc++] = str;
        }
        /* look out for end of argument, either end of string, blank or quote */
        for(; *str != '\0'; ++str) {
            if (quoted) {
                if (*str == '\"') { /* end of quotation reached */
                    *str++ = '\0';
                    break;
                }
            }
            else {
                if (isspace((unsigned char) *str)) { /* parameter separator reached */
                    *str++ = '\0';
                    break;
                }
            }
        }
    }
    return argc;
}

static int
merge_argv(int argc, char** argv, int str_argc, char** str_argv, int N)
{
    int     i;
    int     merged;
    if (argc > 0) {
        str_argv[0] = argv[0];
        if (str_argc < 1) str_argc = 1;
    }
    for (i = 1; i < argc; ++i) {
        int     j = str_argc + i - 1;
        if (j < N) {
            str_argv[j] = argv[i];
        }
    }
    merged = argc + str_argc - 1;
    /* The write loop skips any slot >= N, so never report more entries than
       the array actually holds.  parse_args() sizes str_argv to fit, but clamp
       here as well so this helper can never hand back a count that runs past
       its own buffer. */
    if (merged > N)
        merged = N;
    return merged;
}

#ifdef DEBUG
static void
dump_argv(int argc, char** argv)
{
    int     i;
    for (i = 0; i < argc; ++i) {
        printf("%d: \"%s\"\n",i,argv[i]);
    }
}
#endif


int parse_args(lame_t gfp, int argc, char **argv, char *const inPath, char *const outPath,
               char *const outDir, char **nogap_inPath, int *num_nogap)
{
    char  **str_argv, *str;
    int     str_argc, ret;
    size_t  n;

    if (argc < 1) { /* not even a program name */
        error_printf("the argument list is empty\n");
        return -1;
    }
    str = lame_getenv("LAMEOPT");
    /* Size the merged argument vector to actually fit: at worst every byte of
       LAMEOPT begins a new token, the real argv contributes argc entries, plus
       one for argv[0].  argc and the environment are both bounded by the OS
       ARG_MAX, so n stays well within range. */
    n = (size_t) argc + (str != 0 ? strlen(str) : 0) + 1;
    str_argv = malloc(n * sizeof(*str_argv));
    if (str_argv == 0) {
        error_printf("out of memory while parsing the command line\n");
        free(str);
        return -1;
    }
    str_argc = string_to_argv(str, str_argv, (int) n);
    str_argc = merge_argv(argc, argv, str_argc, str_argv, (int) n);
#ifdef DEBUG
    dump_argv(str_argc, str_argv);
#endif
    ret = parse_args_(gfp, str_argc, str_argv, inPath, outPath, outDir, nogap_inPath, num_nogap);
    free(str_argv);
    free(str);
    return ret;
}

/* end of parse.c */
