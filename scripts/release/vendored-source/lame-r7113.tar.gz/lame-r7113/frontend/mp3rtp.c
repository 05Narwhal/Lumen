/*
 *      mp3rtp command line frontend program
 *
 *      initially contributed by Felix von Leitner
 *
 *      Copyright (c) 2000 Mark Taylor
 *                    2010 Robert Hegemann
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 */

/* $Id$ */

/* Still under work ..., need a client for test, where can I get one? */

/* An audio player named Zinf (aka freeamp) can play rtp streams */

/* 
 *  experimental translation:
 *
 *  gcc -I..\include -I..\libmp3lame -o mp3rtp mp3rtp.c ../libmp3lame/libmp3lame.a lametime.c get_audio.c ieeefloat.c timestatus.c parse.c rtp.c -lm
 *
 *  wavrec -t 14400 -s 44100 -S /proc/self/fd/1 | ./mp3rtp 10.1.1.42 -V2 -b128 -B256 - my_mp3file.mp3
 */

#ifdef HAVE_CONFIG_H
# include <config.h>
#endif

#ifdef HAVE_STDINT_H
# include <stdint.h>
#endif

#ifdef STDC_HEADERS
# include <stdlib.h>
# include <string.h>
#endif

#include <time.h>

#ifdef HAVE_UNISTD_H
# include <unistd.h>
#endif

#include "lame.h"
#include "main.h"
#include "parse.h"
#include "lametime.h"
#include "timestatus.h"
#include "get_audio.h"
#include "rtp.h"
#include "console.h"

#ifdef WITH_DMALLOC
#include <dmalloc.h>
#endif

/*
 * Encode (via LAME) to mp3 with RTP streaming of the output.
 *
 * Author: Felix von Leitner <leitner@vim.org>
 *
 *   mp3rtp destination [port[:ttl]] [lame encoding options] infile outfile
 *
 * examples:
 *   arecord -b 16 -s 22050 -w | ./mp3rtp 224.17.23.42 5004:2 -b 56 - /dev/null
 *   arecord -b 16 -s 44100 -w | ./mp3rtp 10.1.1.42 -V2 -b128 -B256 - my_mp3file.mp3
 *   arecord -b 16 -s 44100 -w | ./mp3rtp ff00::8 5004:2 -V2 -b128 -B256 - my_mp3file.mp3
 *   arecord -b 16 -s 44100 -w | ./mp3rtp studio.example.net -b 56 - /dev/null
 *
 */


/**
 * @internal
 * @brief Returns the largest sample magnitude of a frame, on the scale that
 *        @c levelmessage() uses.
 *
 * @param Buffer  the frame, per channel.
 * @param n       the number of samples per channel.
 * @return the magnitude, at most 32768.
 */
static unsigned int
maxvalue(int Buffer[2][FRAME_BUFFER_SAMPLES], int n)
{
    int     max = 0;
    int     i;

    for (i = 0; i < n; i++) {
        if (abs(Buffer[0][i]) > max)
            max = abs(Buffer[0][i]);
        if (abs(Buffer[1][i]) > max)
            max = abs(Buffer[1][i]);
    }
    return max >> 16;
}

/**
 * @internal
 * @brief Returns the largest sample magnitude of a frame of floating point
 *        samples, on the scale that @c levelmessage() uses.
 *
 * @param Buffer  the frame, per channel. 1.0 is full scale.
 * @param n       the number of samples per channel.
 * @return the magnitude. 32768 at or above full scale.
 */
static unsigned int
maxvalue_float(float Buffer[2][FRAME_BUFFER_SAMPLES], int n)
{
    float   max = 0;
    int     i;

    for (i = 0; i < n; i++) {
        float const l = Buffer[0][i] < 0 ? -Buffer[0][i] : Buffer[0][i];
        float const r = Buffer[1][i] < 0 ? -Buffer[1][i] : Buffer[1][i];
        if (l > max)
            max = l;
        if (r > max)
            max = r;
    }
    return max >= 1.0f ? 32768u : (unsigned int) (max * 32768.0f);
}

static void
levelmessage(unsigned int maxv, int* maxx, int* tmpx)
{
    char    buff[] = "|  .  |  .  |  .  |  .  |  .  |  .  |  .  |  .  |  .  |  .  |  \r";
    int const last_column = (int) sizeof(buff) - 3; /* the last one before "\r" */
    int     tmp = *tmpx, max = *maxx;

    buff[tmp] = '+';
    tmp = (maxv * 61 + 16384) / (32767 + 16384 / 61);
    if (tmp > last_column)
        tmp = last_column;
    if (max < tmp)
        max = tmp;
    buff[max] = 'x';
    buff[tmp] = '#';
    console_printf("%s", buff);
    console_flush();
    *maxx = max;
    *tmpx = tmp;
}


/************************************************************************
*
* main
*
* PURPOSE:  MPEG-1,2 Layer III encoder with GPSYCHO 
* psychoacoustic model.
*
************************************************************************/

int
lame_main(lame_t gf, int argc, char **argv)
{
    unsigned char mp3buffer[LAME_MAXMP3BUFFER];
    char    inPath[PATH_MAX + 1];
    char    outPath[PATH_MAX + 1];
    char    outDir[PATH_MAX + 1];
    int     Buffer[2][FRAME_BUFFER_SAMPLES];
    float   BufferF[2][FRAME_BUFFER_SAMPLES];
    int     floats;

    int     maxx = 0, tmpx = 0;
    int     ret;
    int     wavsamples;
    int     mp3bytes;
    FILE   *outf;
    audio_reader *reader;
    unsigned int port = 5004;
    unsigned int ttl = 2;
    char    dummy;
    int     arg = 0;

    if (argc <= 2) {
        console_printf("Encode (via LAME) to mp3 with RTP streaming of the output\n"
                       "\n"
                       "    mp3rtp destination [port[:ttl]] [lame encoding options] infile outfile\n"
                       "\n"
                       "    the destination is an IPv4 address, an IPv6 address or a host name\n"
                       "\n"
                       "    examples:\n"
                       "      arecord -b 16 -s 22050 -w | ./mp3rtp 224.17.23.42 5004:2 -b 56 - /dev/null\n"
                       "      arecord -b 16 -s 44100 -w | ./mp3rtp 10.1.1.42 -V2 -b128 -B256 - my_mp3file.mp3\n"
                       "      arecord -b 16 -s 44100 -w | ./mp3rtp ff00::8 5004:2 -b 56 - /dev/null\n"
                       "      arecord -b 16 -s 44100 -w | ./mp3rtp studio.example.net -b 56 - /dev/null\n"
                       "\n");
        return 1;
    }

    /* The destination is passed to the resolver as it stands: a name is as
       valid here as a literal address, and deciding that is the resolver's
       job rather than this scanner's. */
    switch(sscanf(argv[2],"%u:%u%c", &port, &ttl, &dummy)){
    case 1:
    case 2:
        arg = 1;
        break;
    case 3:
        error_printf("Illegal port selector '%s', must be port[:ttl]\n", argv[2]);
        return -1;
    default:
        arg = 0;
    }

    rtp_initialization();
    if (rtp_socket(argv[1], port, ttl)) {
        rtp_deinitialization();
        error_printf("fatal error during initialization\n");
        return 1;
    }

    frontend_attach_reporting(gf);

    /* Remove the argumets that are rtp related, and then 
     * parse the command line arguments, setting various flags in the
     * struct pointed to by 'gf'.  If you want to parse your own arguments,
     * or call libmp3lame from a program which uses a GUI to set arguments,
     * skip this call and set the values of interest in the gf struct.  
     * (see lame.h for documentation about these parameters)
     */
    {
        int     i;
        int     argc_mod = argc-arg-1; /* leaving out one or two arguments */
        char**  argv_mod = calloc(argc_mod, sizeof(char*));
        if (argv_mod == NULL) {
            rtp_deinitialization();
            error_printf("not enough memory\n");
            return 1;
        }
        argv_mod[0] = argv[0];
        for (i = 2+arg; i < argc; ++i) { /* leaving out argument number 1, parsed above */
            argv_mod[i-arg-1] = argv[i];
        }
        ret = parse_args(gf, argc_mod, argv_mod, inPath, outPath, outDir, NULL, NULL);
        free(argv_mod);
        if (ret < 0) {
            rtp_deinitialization();
            return ret == -2 ? 0 : 1;
        }
    }

    /* open the output file.  Filename parsed into gf.inPath */
    if (0 == strcmp(outPath, "-")) {
        lame_set_stream_binary_mode(outf = stdout);
    }
    else {
        if ((outf = lame_fopen(outPath, "wb+")) == NULL) {
            rtp_deinitialization();
            error_printf("Could not create \"%s\".\n", outPath);
            return 1;
        }
    }


    /* open the wav/aiff/raw pcm or mp3 input file.  This call will
     * open the file with name gf.inFile, try to parse the headers and
     * set gf.samplerate, gf.num_channels, gf.num_samples.
     * if you want to do your own file input, skip this call and set
     * these values yourself.  
     */
    if ((reader = init_infile(gf, inPath)) == NULL) {
        rtp_deinitialization();
        fclose(outf);
        error_printf("Can't init infile '%s'\n", inPath);
        return 1;
    }


    /* Now that all the options are set, lame needs to analyze them and
     * set some more options 
     */
    ret = frontend_init_params(gf);
    if (ret < 0) {
        rtp_deinitialization();
        fclose(outf);
        close_infile(reader);
        error_printf("fatal error during initialization\n");
        return -1;
    }

    lame_print_config(gf); /* print useful information about options being used */

    if (frontend_config.ui_config.update_interval < 0.)
        frontend_config.ui_config.update_interval = 2.;

    /* encode until we hit EOF */
    floats = input_is_float(reader);
    while ((wavsamples = floats ? get_audio_float(reader, gf, BufferF)
                                : get_audio(reader, gf, Buffer)) > 0) {
        if (floats) {
            levelmessage(maxvalue_float(BufferF, wavsamples), &maxx, &tmpx);
            mp3bytes = lame_encode_buffer_ieee_float(gf, BufferF[0], BufferF[1], wavsamples,
                                                     mp3buffer, sizeof(mp3buffer));
        }
        else {
            levelmessage(maxvalue(Buffer, wavsamples), &maxx, &tmpx);
            mp3bytes = lame_encode_buffer_int(gf, Buffer[0], Buffer[1], wavsamples,
                                              mp3buffer, sizeof(mp3buffer));
        }
        if (mp3bytes < 0) {
            error_printf("Error: %s (error %d)\n", frontend_encode_error_text(mp3bytes), mp3bytes);
            rtp_deinitialization();
            fclose(outf);
            close_infile(reader);
            return -1;
        }
        rtp_output(mp3buffer, mp3bytes); /* write MP3 output to RTP port */
        fwrite(mp3buffer, 1, mp3bytes, outf); /* write the MP3 output to file */
    }
    if (wavsamples < 0) {
        if (frontend_config.ui_config.silent < 10)
            error_printf("Error reading input file\n");
        rtp_deinitialization();
        fclose(outf);
        close_infile(reader);
        return 1;
    }

    mp3bytes = lame_encode_flush(gf, /* may return one or more mp3 frame */
                                 mp3buffer, sizeof(mp3buffer));
    if (mp3bytes < 0) {
        error_printf("Error: %s (error %d)\n", frontend_encode_error_text(mp3bytes), mp3bytes);
        rtp_deinitialization();
        fclose(outf);
        close_infile(reader);
        return -1;
    }
    rtp_output(mp3buffer, mp3bytes); /* write MP3 output to RTP port */
    fwrite(mp3buffer, 1, mp3bytes, outf); /* write the MP3 output to file */

    lame_mp3_tags_fid(gf, outf); /* add VBR tags to mp3 file */

    rtp_deinitialization();
    fclose(outf);
    close_infile(reader); /* close the sound input file */
    return 0;
}

/* end of mp3rtp.c */
