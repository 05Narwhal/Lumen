/*
 *	Lame time routines include file
 *
 *	Copyright (c) 2000 Mark Taylor
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.	 See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 */

#ifndef LAME_LAMETIME_H
#define LAME_LAMETIME_H

#include <sys/types.h>
#include <time.h>
#include "lame.h"

#if defined(__cplusplus)
extern "C" {
#endif

extern double GetCPUTime(void);
extern double GetRealTime(void);

extern int lame_set_stream_binary_mode(FILE * const fp);

/**
 * @internal
 * @brief The access and modification times of a file, read before anything
 *        opens it.
 */
typedef struct {
    int     valid;
    time_t  actime;
    time_t  modtime;
} lame_file_times;

extern int lame_read_file_times(char const *path, lame_file_times * times);
extern int lame_write_file_times(char const *path, lame_file_times const *times);

#if defined(__cplusplus)
}
#endif

#endif /* LAME_LAMETIME_H */
