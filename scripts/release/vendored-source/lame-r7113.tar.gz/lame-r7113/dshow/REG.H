/*
 *  LAME MP3 encoder for DirectShow
 *  Registry calls handling class
 *
 *  Copyright (c) 2000-2005 Marie Orlova, Peter Gubanov, Vitaly Ivanov, Elecard Ltd.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 */

#ifndef	LAME_DSHOW_REG_H
#define	LAME_DSHOW_REG_H

namespace Lame
{
class	CRegKey 
{
protected:
	HKEY	m_hKey;
	HKEY	m_hRootKey;
public:
	CRegKey(void);
	CRegKey(HKEY rootKey, LPCTSTR pName);
	~CRegKey(void);

	BOOL	Open(HKEY rootKey, LPCTSTR pName);
	BOOL	Create(HKEY rootKey, LPCTSTR pName);
	BOOL	Close(void);

	DWORD	getDWORD(LPCTSTR valuename, DWORD bDefault);
	void	setDWORD(LPCTSTR valuename, DWORD dwValue);
};
}
#endif // LAME_DSHOW_REG_H
